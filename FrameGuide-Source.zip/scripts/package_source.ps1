# Source-only, flat project-root ZIP. Works in Windows PowerShell 5.1 / PowerShell 7.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Add-Type -AssemblyName System.IO.Compression.FileSystem
$projectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$outputDirectory = Join-Path $projectRoot 'build'
$outputZip = Join-Path $outputDirectory 'FrameGuide-Source.zip'
$stageRoot = Join-Path ([IO.Path]::GetTempPath()) ('FrameGuide-source-' + [Guid]::NewGuid().ToString('N'))
$candidateZip = Join-Path $outputDirectory ('FrameGuide-source-' + [Guid]::NewGuid().ToString('N') + '.zip')
# Enumerated distributable trees plus specific documentation/scripts; no repo-wide glob.
$sourceTrees = @('Core', 'FrameGuide', 'FrameGuide.xcodeproj', '.github/workflows')
$sourceFiles = @('.gitignore', 'README.md', 'scripts/validate_project.py', 'scripts/package_source.ps1', 'scripts/PhotoFixture.swift',
    'docs/design.md', 'docs/implementation-plan.md', 'docs/device-checklist.md', 'docs/validation.md')
$excludedParts = @('.git', '.superpowers', 'build', 'DerivedData', '.build', '.swiftpm',
    '__pycache__', 'xcuserdata', 'node_modules', '.cache', '.pytest_cache')
$excludedExtensions = @('.ipa', '.dylib', '.p12', '.pfx', '.cer', '.pem', '.key', '.mobileprovision',
    '.provisionprofile', '.pyc', '.xcuserstate', '.xcscmblueprint', '.xccheckout', '.zip')
$required = @('README.md', '.gitignore', '.github/workflows/ios.yml', 'Core/Package.swift',
    'Core/Sources/FrameGuideCore/CompositionEngine.swift', 'Core/Tests/FrameGuideCoreTests/CompositionEngineTests.swift',
    'FrameGuide/App/FrameGuideApp.swift', 'FrameGuide/Resources/Info.plist', 'FrameGuide/Resources/PrivacyInfo.xcprivacy',
    'FrameGuide/Resources/Assets.xcassets/AppIcon.appiconset/AppIcon.png',
    'FrameGuide.xcodeproj/project.pbxproj', 'FrameGuide.xcodeproj/xcshareddata/xcschemes/FrameGuide.xcscheme',
    'scripts/validate_project.py', 'scripts/package_source.ps1', 'scripts/PhotoFixture.swift', 'docs/design.md', 'docs/implementation-plan.md',
    'docs/device-checklist.md', 'docs/validation.md')
function Test-Excluded([string] $Relative) {
    $parts = $Relative.Replace('\', '/').Split('/')
    foreach ($part in $parts) {
        if ($excludedParts -contains $part -or $part -eq '.DS_Store' -or $part -eq '.env' -or $part -like '.env.*') { return $true }
    }
    return $excludedExtensions -contains [IO.Path]::GetExtension($Relative).ToLowerInvariant()
}
function Copy-SourceFile([string] $Relative) {
    if (Test-Excluded $Relative) { return }
    $source = Join-Path $projectRoot $Relative
    $item = Get-Item -Force -LiteralPath $source
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Source link forbidden: $Relative" }
    $destination = Join-Path $stageRoot $Relative
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($destination)) | Out-Null
    Copy-Item -LiteralPath $source -Destination $destination
    (Get-Item -Force -LiteralPath $destination).Attributes = [IO.FileAttributes]::Normal
}
function Copy-SourceTree([string] $Relative) {
    if (Test-Excluded $Relative) { return }
    $directory = Get-Item -Force -LiteralPath (Join-Path $projectRoot $Relative)
    if ($directory.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Source directory link forbidden: $Relative" }
    foreach ($child in Get-ChildItem -Force -LiteralPath $directory.FullName) {
        $childRelative = Join-Path $Relative $child.Name
        if (Test-Excluded $childRelative) { continue }
        if ($child.PSIsContainer) { Copy-SourceTree $childRelative } else { Copy-SourceFile $childRelative }
    }
}
try {
    [IO.Directory]::CreateDirectory($outputDirectory) | Out-Null
    [IO.Directory]::CreateDirectory($stageRoot) | Out-Null
    foreach ($tree in $sourceTrees) { Copy-SourceTree $tree }
    foreach ($file in $sourceFiles) { Copy-SourceFile $file }
    # Hidden flags are cleared in the isolated stage so Compress-Archive includes .github/.gitignore.
    foreach ($directory in Get-ChildItem -Force -Directory -Recurse -LiteralPath $stageRoot) {
        $directory.Attributes = [IO.FileAttributes]::Directory
    }
    $inputs = @(Get-ChildItem -Force -LiteralPath $stageRoot | ForEach-Object { $_.FullName })
    Compress-Archive -LiteralPath $inputs -DestinationPath $candidateZip -CompressionLevel Optimal
    # Windows PowerShell 5.1 can emit backslash ZIP names; canonicalize for POSIX/macOS consumers.
    $canonical = [IO.Compression.ZipFile]::Open($candidateZip, [IO.Compression.ZipArchiveMode]::Update)
    try {
        foreach ($entry in @($canonical.Entries)) {
            $portableName = $entry.FullName.Replace('\', '/')
            if ($portableName -ceq $entry.FullName) { continue }
            $replacement = $canonical.CreateEntry($portableName, [IO.Compression.CompressionLevel]::Optimal)
            $replacement.LastWriteTime = $entry.LastWriteTime
            $inputStream = $entry.Open()
            $outputStream = $replacement.Open()
            try { $inputStream.CopyTo($outputStream) } finally { $inputStream.Dispose(); $outputStream.Dispose() }
            $entry.Delete()
        }
    } finally { $canonical.Dispose() }
    $archive = [IO.Compression.ZipFile]::OpenRead($candidateZip)
    try {
        $names = @{}
        $fileCount = 0
        foreach ($entry in $archive.Entries) {
            $name = $entry.FullName.Replace('\', '/')
            if ($entry.FullName -cne $name -or $name.StartsWith('/') -or $name.Contains(':') -or $name.Split('/') -contains '..' -or (Test-Excluded $name)) {
                throw "Prohibited archive member: $name"
            }
            if ($names.ContainsKey($name)) { throw "Duplicate archive member: $name" }
            $names[$name] = $true
            $entryType = if ($name.EndsWith('/')) { 'Container' } else { 'Leaf' }
            if (-not (Test-Path -LiteralPath (Join-Path $stageRoot $name) -PathType $entryType)) {
                throw "Unexpected archive member: $name"
            }
            if ($entryType -eq 'Leaf') { $fileCount++ }
        }
        foreach ($must in $required) {
            if (-not $names.ContainsKey($must)) { throw "Required archive member missing: $must" }
        }
        $stagedFiles = @(Get-ChildItem -Force -File -Recurse -LiteralPath $stageRoot)
        if ($fileCount -ne $stagedFiles.Count) { throw 'Archive does not contain every staged source file' }
        $memberCount = $fileCount
    } finally { $archive.Dispose() }
    Move-Item -Force -LiteralPath $candidateZip -Destination $outputZip
    Write-Output "PASS: source ZIP verified ($memberCount files; flat project-root layout; no prohibited members)."
    Write-Output $outputZip
    $hashAlgorithm = [Security.Cryptography.SHA256]::Create()
    $zipStream = [IO.File]::OpenRead($outputZip)
    try { $zipHash = [BitConverter]::ToString($hashAlgorithm.ComputeHash($zipStream)).Replace('-', '') }
    finally { $zipStream.Dispose(); $hashAlgorithm.Dispose() }
    Write-Output ('SHA256: ' + $zipHash)
} finally {
    # Validate the exact generated temporary target before recursive cleanup.
    $resolvedStage = [IO.Path]::GetFullPath($stageRoot)
    $tempRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\', '/') + [IO.Path]::DirectorySeparatorChar
    if (-not $resolvedStage.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase) -or
        [IO.Path]::GetFileName($resolvedStage) -notmatch '^FrameGuide-source-[a-f0-9]{32}$') { throw 'Unsafe temporary cleanup target' }
    if (Test-Path -LiteralPath $resolvedStage) { Remove-Item -Force -Recurse -LiteralPath $resolvedStage }
    if (Test-Path -LiteralPath $candidateZip) { Remove-Item -Force -LiteralPath $candidateZip }
}
