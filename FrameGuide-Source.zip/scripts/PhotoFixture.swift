import CoreImage
import Foundation
import ImageIO
import UniformTypeIdentifiers

// Run with the shipping PhotoProcessor and PhotoFilter on a macOS runner.
@main struct PhotoFixture {
    static let context = CIContext()
    static func solid(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat, in rect: CGRect) -> CIImage {
        CIImage(color: CIColor(red: r, green: g, blue: b)).cropped(to: rect)
    }
    static func input(_ w: Int, _ h: Int, visible: CGRect, mirrored: Bool) -> Data {
        let extent = CGRect(x: 0, y: 0, width: w, height: h)
        var image = solid(1, 0, 1, in: extent) // Excluded side strips.
        for (dx, dy, color) in [(0, 0, (1, 0, 0)), (1, 0, (0, 0, 1)),
                                (0, 1, (0, 1, 0)), (1, 1, (1, 1, 0))] {
            let rect = CGRect(x: visible.minX + CGFloat(dx) * visible.width / 2,
                              y: visible.minY + CGFloat(dy) * visible.height / 2,
                              width: visible.width / 2, height: visible.height / 2)
            image = solid(CGFloat(color.0), CGFloat(color.1), CGFloat(color.2), in: rect).composited(over: image)
        }
        let bytes = NSMutableData()
        let dest = CGImageDestinationCreateWithData(bytes, UTType.jpeg.identifier as CFString, 1, nil)!
        CGImageDestinationAddImage(dest, context.createCGImage(image, from: extent)!, [
            kCGImagePropertyOrientation: mirrored ? 2 : 1, kCGImageDestinationLossyCompressionQuality: 1
        ] as CFDictionary)
        precondition(CGImageDestinationFinalize(dest))
        return bytes as Data
    }
    static func check(_ bytes: Data, width: Int, height: Int, mirrored: Bool) {
        let source = CGImageSourceCreateWithData(bytes as CFData, nil)!
        let info = CGImageSourceCopyPropertiesAtIndex(source, 0, nil)! as NSDictionary
        precondition((info[kCGImagePropertyOrientation] as? NSNumber)?.intValue == 1)
        let image = CIImage(data: bytes)!
        precondition(image.extent.size == CGSize(width: width, height: height))
        for (right, top, expected) in [(false, false, [255, 0, 0]), (true, false, [0, 0, 255]),
                                       (false, true, [0, 255, 0]), (true, true, [255, 255, 0])] {
            let rect = CGRect(x: (right != mirrored) ? width - 8 : 7, y: top ? height - 8 : 7,
                              width: 1, height: 1)
            var rgba = [UInt8](repeating: 0, count: 4)
            rgba.withUnsafeMutableBytes {
                context.render(image, toBitmap: $0.baseAddress!, rowBytes: 4, bounds: rect,
                               format: .RGBA8, colorSpace: CGColorSpaceCreateDeviceRGB())
            }
            for i in 0..<3 { precondition(abs(Int(rgba[i]) - expected[i]) < 55, "Wrong edge marker") }
        }
    }
    static func main() async throws {
        let processor = PhotoProcessor()
        for (width, mirrored) in [(320, false), (320, true), (240, false)] {
            let size = CGSize(width: width, height: 320)
            let rect = CGRect(x: (width - 240) / 2, y: 0, width: 240, height: 320)
            let framing = PhotoFraming(outputRect: rect, dimensions: size, aspect: 0.75)!
            let source = CapturedPhoto(bytes: input(width, 320, visible: rect, mirrored: mirrored), framing: framing)
            let full = try await processor.render(data: source, filter: .original, maxPixelDimension: nil)
            check(full, width: 240, height: 320, mirrored: mirrored)
            let preview = try await processor.render(data: source, filter: .original, maxPixelDimension: 160)
            check(preview, width: 120, height: 160, mirrored: mirrored)
            let thumb = try await processor.thumbnail(data: source)
            check(thumb, width: 144, height: 192, mirrored: mirrored)
            for filter in [PhotoFilter.warm, .clear, .monochrome] {
                let filtered = try await processor.render(data: source, filter: filter, maxPixelDimension: 2000)
                precondition(CIImage(data: filtered)!.extent.size == rect.size)
            }
            precondition(framing.nativeCrop(in: CGRect(x: 0, y: 0, width: 640, height: 480)) == nil)
        }
        precondition(PhotoFraming(outputRect: CGRect(x: 40, y: 0, width: 240, height: 320),
                                  dimensions: CGSize(width: 640, height: 640), aspect: 0.75) == nil)
        print("PASS: native JPEG color markers, square crop, 3:4 identity, mirrored EXIF, preview, thumbnail, filters, no enlargement and aperture mismatch")
    }
}
