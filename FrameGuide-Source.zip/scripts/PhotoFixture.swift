import CoreImage
import Foundation
import ImageIO
import UniformTypeIdentifiers

// Run with the shipping PhotoProcessor and PhotoFilter on a macOS runner.
@main struct PhotoFixture {
    static let context = CIContext()
    static func require(_ condition: Bool, _ message: @autoclosure () -> String) {
        guard condition else {
            FileHandle.standardError.write(Data(("FAIL: " + message() + "\n").utf8))
            exit(1)
        }
    }
    static func solid(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat, in rect: CGRect) -> CIImage {
        CIImage(color: CIColor(red: r, green: g, blue: b)).cropped(to: rect)
    }
    static func input(_ w: Int, _ h: Int, visible: CGRect, mirrored: Bool) -> Data {
        let extent = CGRect(x: 0, y: 0, width: w, height: h)
        var image = solid(1, 0, 1, in: extent) // Excluded side strips.
        for (dx, dy, color) in [(0, 0, (1, 0, 0)), (1, 0, (0, 0, 1)),
                                (0, 1, (0, 1, 0)), (1, 1, (1, 1, 0))] {
            let rect = CGRect(x: visible.minX + CGFloat(dx) * visible.width / 2,
                              y: visible.minY + CGFloat(dy) * visible.height / 2,
                              width: visible.width / 2, height: visible.height / 2)
            image = solid(CGFloat(color.0), CGFloat(color.1), CGFloat(color.2), in: rect).composited(over: image)
        }
        let bytes = NSMutableData()
        let dest = CGImageDestinationCreateWithData(bytes, UTType.jpeg.identifier as CFString, 1, nil)!
        CGImageDestinationAddImage(dest, context.createCGImage(image, from: extent)!, [
            kCGImagePropertyOrientation: mirrored ? 2 : 1,
            kCGImagePropertyTIFFDictionary: [kCGImagePropertyTIFFOrientation: mirrored ? 2 : 1],
            kCGImageDestinationLossyCompressionQuality: 1
        ] as CFDictionary)
        require(CGImageDestinationFinalize(dest), "failed to encode input JPEG")
        return bytes as Data
    }
    static func check(_ bytes: Data, width: Int, height: Int, mirrored: Bool, stage: String) {
        let source = CGImageSourceCreateWithData(bytes as CFData, nil)!
        let info = CGImageSourceCopyPropertiesAtIndex(source, 0, nil)! as NSDictionary
        let tag = info[kCGImagePropertyOrientation]
        // ImageIO may omit the default up tag. Reject any other explicit value or type,
        // and check BOTH raw and EXIF-aware decodes against all four asymmetric markers.
        require(tag == nil || (tag as? NSNumber)?.intValue == 1,
                "\(stage) expected default/up EXIF, got \(String(describing: tag)); properties \(info)")
        print("\(stage): orientation=\(String(describing: tag)), expected \(width)x\(height)")
        for honorEXIF in [false, true] {
            let image = CIImage(data: bytes, options: [.applyOrientationProperty: honorEXIF])!
            require(image.extent.size == CGSize(width: width, height: height),
                    "\(stage) honorEXIF=\(honorEXIF) expected \(width)x\(height), got \(image.extent)")
            for (right, top, expected) in [(false, false, [255, 0, 0]), (true, false, [0, 0, 255]),
                                           (false, true, [0, 255, 0]), (true, true, [255, 255, 0])] {
                let rect = CGRect(x: (right != mirrored) ? width - 8 : 7, y: top ? height - 8 : 7,
                                  width: 1, height: 1)
                var rgba = [UInt8](repeating: 0, count: 4)
                rgba.withUnsafeMutableBytes {
                    context.render(image, toBitmap: $0.baseAddress!, rowBytes: 4, bounds: rect,
                                   format: .RGBA8, colorSpace: CGColorSpaceCreateDeviceRGB())
                }
                require((0..<3).allSatisfy { abs(Int(rgba[$0]) - expected[$0]) < 55 },
                        "\(stage) honorEXIF=\(honorEXIF) sample=\(rect) expected RGB \(expected), got RGBA \(rgba)")
            }
        }
    }
    static func main() async throws {
        let processor = PhotoProcessor()
        // Calibrate the shutter against either the delivered or a larger supported
        // maximum raster. Draw markers independently in the smaller native JPEG.
        for (width, mirrored, factor) in [(320, false, 1), (320, true, 1), (240, false, 1),
                                          (320, true, 2), (240, false, 2)] {
            let resolved = CGSize(width: width, height: 320)
            let size = CGSize(width: width * factor, height: 320 * factor)
            let rect = CGRect(x: (width - 240) / 2, y: 0, width: 240, height: 320)
            let calibrated = CGRect(x: (width - 240) * factor / 2, y: 0, width: 240 * factor, height: 320 * factor)
            let framing = PhotoFraming(outputRect: calibrated, dimensions: size, aspect: 0.75)!
            let source = CapturedPhoto(bytes: input(width, 320, visible: rect, mirrored: mirrored), framing: framing, resolvedUprightSize: resolved)
            let label = "calibrated=\(size) input=\(width)x320 mirrored=\(mirrored)"
            if mirrored {
                let jpg = CGImageSourceCreateWithData(source.bytes as CFData, nil)!
                let properties = CGImageSourceCopyPropertiesAtIndex(jpg, 0, nil)! as NSDictionary
                require((properties[kCGImagePropertyOrientation] as? NSNumber)?.intValue == 2,
                        "\(label) fixture requires real EXIF 2; got \(properties)")
            }
            let full = try await processor.render(data: source, filter: .original, maxPixelDimension: nil)
            check(full, width: 240, height: 320, mirrored: mirrored, stage: label + " full")
            let preview = try await processor.render(data: source, filter: .original, maxPixelDimension: 160)
            check(preview, width: 120, height: 160, mirrored: mirrored, stage: label + " preview")
            let thumb = try await processor.thumbnail(data: source)
            check(thumb, width: 144, height: 192, mirrored: mirrored, stage: label + " thumb")
            for filter in [PhotoFilter.warm, .clear, .monochrome] {
                let filtered = try await processor.render(data: source, filter: filter, maxPixelDimension: 2000)
                let actual = CIImage(data: filtered)!.extent.size
                require(actual == rect.size, "\(label) \(filter) expected \(rect.size), got \(actual)")
            }
            let decoded = CGRect(origin: .zero, size: resolved)
            require(framing.nativeCrop(in: decoded, resolved: .zero) == nil, "\(label) accepted absent resolved metadata")
            let smaller = CGSize(width: resolved.width / 2, height: resolved.height / 2)
            require(framing.nativeCrop(in: decoded, resolved: smaller) == nil, "\(label) accepted resolution/decoder disagreement")
            let incompatible = CGRect(x: 0, y: 0, width: 120, height: 140)
            require(framing.nativeCrop(in: incompatible, resolved: incompatible.size) == nil,
                    "\(label) accepted different aperture shape")
        }
        require(PhotoFraming(outputRect: CGRect(x: 40, y: 0, width: 240, height: 320),
                                  dimensions: CGSize(width: 640, height: 640), aspect: 0.75) == nil, "accepted mismatched aperture")
        print("PASS: native JPEG color markers, square crop, 3:4 identity, mirrored EXIF, preview, thumbnail, filters, smaller resolved identity and cropped rasters, no enlargement, aperture mismatch and invalid resolved metadata")
    }
}
