import CoreImage
import Foundation
import ImageIO
import UniformTypeIdentifiers

// Run with the shipping PhotoProcessor and PhotoFilter on a macOS runner.
@main struct PhotoFixture {
    static let context = CIContext()
    static func require(_ condition: Bool, _ message: @autoclosure () -> String) {
        guard condition else {
            FileHandle.standardError.write(Data(("FAIL: " + message() + "\n").utf8))
            exit(1)
        }
    }
    static func solid(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat, in rect: CGRect) -> CIImage {
        CIImage(color: CIColor(red: r, green: g, blue: b)).cropped(to: rect)
    }
    static func input(_ w: Int, _ h: Int, visible: CGRect, mirrored: Bool, orientation: Int? = nil) -> Data {
        let extent = CGRect(x: 0, y: 0, width: w, height: h)
        var image = solid(1, 0, 1, in: extent) // Excluded side strips.
        for (dx, dy, color) in [(0, 0, (1, 0, 0)), (1, 0, (0, 0, 1)),
                                (0, 1, (0, 1, 0)), (1, 1, (1, 1, 0))] {
            let rect = CGRect(x: visible.minX + CGFloat(dx) * visible.width / 2,
                              y: visible.minY + CGFloat(dy) * visible.height / 2,
                              width: visible.width / 2, height: visible.height / 2)
            image = solid(CGFloat(color.0), CGFloat(color.1), CGFloat(color.2), in: rect).composited(over: image)
        }
        let bytes = NSMutableData()
        let dest = CGImageDestinationCreateWithData(bytes, UTType.jpeg.identifier as CFString, 1, nil)!
        let tag = orientation ?? (mirrored ? 2 : 1)
        CGImageDestinationAddImage(dest, context.createCGImage(image, from: extent)!, [
            kCGImagePropertyOrientation: tag,
            kCGImagePropertyTIFFDictionary: [kCGImagePropertyTIFFOrientation: tag],
            kCGImageDestinationLossyCompressionQuality: 1
        ] as CFDictionary)
        require(CGImageDestinationFinalize(dest), "failed to encode input JPEG")
        return bytes as Data
    }
    static func check(_ bytes: Data, width: Int, height: Int, mirrored: Bool, stage: String, rotation: Int = 1) {
        let source = CGImageSourceCreateWithData(bytes as CFData, nil)!
        let info = CGImageSourceCopyPropertiesAtIndex(source, 0, nil)! as NSDictionary
        let tag = info[kCGImagePropertyOrientation]
        // ImageIO may omit the default up tag. Reject any other explicit value or type,
        // and check BOTH raw and EXIF-aware decodes against all four asymmetric markers.
        require(tag == nil || (tag as? NSNumber)?.intValue == 1,
                "\(stage) expected default/up EXIF, got \(String(describing: tag)); properties \(info)")
        print("\(stage): orientation=\(String(describing: tag)), expected \(width)x\(height)")
        for honorEXIF in [false, true] {
            let image = CIImage(data: bytes, options: [.applyOrientationProperty: honorEXIF])!
            require(image.extent.size == CGSize(width: width, height: height),
                    "\(stage) honorEXIF=\(honorEXIF) expected \(width)x\(height), got \(image.extent)")
            for (right, top, expected) in [(false, false, [255, 0, 0]), (true, false, [0, 0, 255]),
                                           (false, true, [0, 255, 0]), (true, true, [255, 255, 0])] {
                let outputRight = rotation == 6 ? top : rotation == 8 ? !top : (right != mirrored)
                let outputTop = rotation == 6 ? !right : rotation == 8 ? right : top
                let rect = CGRect(x: outputRight ? width - 8 : 7, y: outputTop ? height - 8 : 7,
                                  width: 1, height: 1)
                var rgba = [UInt8](repeating: 0, count: 4)
                rgba.withUnsafeMutableBytes {
                    context.render(image, toBitmap: $0.baseAddress!, rowBytes: 4, bounds: rect,
                                   format: .RGBA8, colorSpace: CGColorSpaceCreateDeviceRGB())
                }
                require((0..<3).allSatisfy { abs(Int(rgba[$0]) - expected[$0]) < 55 },
                        "\(stage) honorEXIF=\(honorEXIF) sample=\(rect) expected RGB \(expected), got RGBA \(rgba)")
            }
        }
    }
    static func main() async throws {
        let processor = PhotoProcessor()
        // Calibrate the shutter against either the delivered or a larger supported
        // maximum raster. Draw markers independently in the smaller native JPEG.
        for (width, mirrored, factor) in [(320, false, 1), (320, true, 1), (240, false, 1),
                                          (320, true, 2), (240, false, 2)] {
            let resolved = CGSize(width: width, height: 320)
            let size = CGSize(width: width * factor, height: 320 * factor)
            let rect = CGRect(x: (width - 240) / 2, y: 0, width: 240, height: 320)
            let reference = CGRect(x: 7, y: 19, width: width / 2, height: 160)
            let visible = CGRect(x: 7 + (width - 240) / 4, y: 19, width: 120, height: 160)
            let plan = ShutterFraming(reference: reference, visible: visible, viewportAspect: 0.75, cleanSize: size,
                                      maximum: size, unavailable: nil, diagnostic: "fixture")
            let source = try CapturedPhoto(bytes: input(width, 320, visible: rect, mirrored: mirrored), plan: plan, resolved: resolved)
            require(!source.keepsFullFrame, "valid cross-raster mapping rejected: \(source.diagnostic)")
            let label = "calibrated=\(size) input=\(width)x320 mirrored=\(mirrored)"
            if mirrored {
                let jpg = CGImageSourceCreateWithData(source.bytes as CFData, nil)!
                let properties = CGImageSourceCopyPropertiesAtIndex(jpg, 0, nil)! as NSDictionary
                require((properties[kCGImagePropertyOrientation] as? NSNumber)?.intValue == 2,
                        "\(label) fixture requires real EXIF 2; got \(properties)")
            }
            let full = try await processor.render(data: source, filter: .original, maxPixelDimension: nil)
            check(full, width: 240, height: 320, mirrored: mirrored, stage: label + " full")
            let preview = try await processor.render(data: source, filter: .original, maxPixelDimension: 160)
            check(preview, width: 120, height: 160, mirrored: mirrored, stage: label + " preview")
            let thumb = try await processor.thumbnail(data: source)
            check(thumb, width: 144, height: 192, mirrored: mirrored, stage: label + " thumb")
            for filter in [PhotoFilter.warm, .clear, .monochrome] {
                let filtered = try await processor.render(data: source, filter: filter, maxPixelDimension: 2000)
                let actual = CIImage(data: filtered)!.extent.size
                require(actual == rect.size, "\(label) \(filter) expected \(rect.size), got \(actual)")
            }
        }
        let square = CGSize(width: 320, height: 320)
        let bounds = CGRect(origin: .zero, size: square)
        let markers = input(320, 320, visible: bounds, mirrored: false)
        for (ref, resolved, reason) in [(CGRect.zero, square, nil as String?), (bounds, .zero, nil),
                                         (bounds, CGSize(width: 160, height: 160), nil),
                                         (bounds, square, "镜头已切换"), (CGRect(x: 0, y: 0, width: 200, height: 100), square, nil)] {
            let plan = ShutterFraming(reference: ref, visible: CGRect(x: 40, y: 0, width: 240, height: 320),
                                      viewportAspect: 0.75, cleanSize: square, maximum: square, unavailable: reason, diagnostic: "fixture")
            let photo = try CapturedPhoto(bytes: markers, plan: plan, resolved: resolved)
            require(photo.keepsFullFrame, "expected full-frame disposition: \(photo.diagnostic)")
            let full = try await processor.render(data: photo, filter: .original, maxPixelDimension: nil)
            check(full, width: 320, height: 320, mirrored: false, stage: "full-frame recovery")
            let thumb = try await processor.thumbnail(data: photo)
            check(thumb, width: 192, height: 192, mirrored: false, stage: "full-frame thumb")
        }
        // A physically offset visible ROI must preserve its offset, not be recentered.
        let shifted = CGRect(x: 8, y: 0, width: 240, height: 320)
        let shiftedPlan = ShutterFraming(reference: CGRect(x: 11, y: 13, width: 160, height: 160),
                                         visible: CGRect(x: 15, y: 13, width: 120, height: 160),
                                         viewportAspect: 0.75, cleanSize: square, maximum: square,
                                         unavailable: nil, diagnostic: "shifted")
        let shiftedPhoto = try CapturedPhoto(bytes: input(320, 320, visible: shifted, mirrored: false),
                                             plan: shiftedPlan, resolved: square)
        require(!shiftedPhoto.keepsFullFrame, "shifted ROI unexpectedly fell back")
        let shiftedJPEG = try await processor.render(data: shiftedPhoto, filter: .original, maxPixelDimension: nil)
        check(shiftedJPEG, width: 240, height: 320, mirrored: false, stage: "shifted viewport")
        for rotation in [6, 8] {
            let raw = CGRect(x: 0, y: 0, width: 320, height: 240)
            let size = CGSize(width: 240, height: 320)
            let ref = CGRect(x: 17, y: 23, width: 120, height: 160)
            let plan = ShutterFraming(reference: ref, visible: ref, viewportAspect: 0.75, cleanSize: size,
                                      maximum: size, unavailable: nil, diagnostic: "rotation fixture")
            let photo = try CapturedPhoto(bytes: input(320, 240, visible: raw, mirrored: false, orientation: rotation),
                                          plan: plan, resolved: size)
            require(!photo.keepsFullFrame, "EXIF \(rotation) upright size mismatch: \(photo.diagnostic)")
            let full = try await processor.render(data: photo, filter: .original, maxPixelDimension: nil)
            check(full, width: 240, height: 320, mirrored: false, stage: "EXIF \(rotation)", rotation: rotation)
        }
        print("PASS: native JPEG color markers, square crop, 3:4 identity, mirrored EXIF, preview, thumbnail, filters, smaller resolved identity and cropped rasters, no enlargement, cross-raster calibration, EXIF 6/8 and full-frame recovery")
    }
}
