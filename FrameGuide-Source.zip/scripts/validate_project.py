#!/usr/bin/env python3
"""Read-only, stdlib structure checks. Does not compile Swift or run the app."""
from __future__ import annotations

from collections import Counter
import json
import os
from pathlib import Path
import plistlib
import re
import struct
import xml.etree.ElementTree as ET
import zlib


IGNORED = {'.git', '.superpowers', 'build', 'DerivedData', '.build',
           '.swiftpm', '__pycache__', 'xcuserdata'}
PRIVATE_HOST_SUFFIXES = ('yindoka.com',)


def product_files(root: Path):
    """Visit distributable files only; never follow directory symlinks."""
    for directory, folders, files in os.walk(root, followlinks=False):
        folders[:] = sorted(f for f in folders if f not in IGNORED)
        for name in sorted(files):
            yield Path(directory) / name


class OpenStep:
    """Small strict parser for the dictionaries/arrays used by pbxproj files."""
    def __init__(self, text: str):
        pattern = r'\s+|/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|[{}()=;,]|[^\s{}()=;,"]+'
        self.tokens = []
        position = 0
        for match in re.finditer(pattern, text, re.S):
            if match.start() != position:
                raise ValueError(f'unrecognized project syntax at offset {position}')
            position = match.end()
            token = match.group()
            if not token.isspace() and not token.startswith(('//', '/*')):
                self.tokens.append(token)
        if position != len(text):
            raise ValueError(f'unrecognized project syntax at offset {position}')
        self.index = 0

    def take(self, expected=None):
        if self.index == len(self.tokens):
            raise ValueError('unexpected end of project')
        token = self.tokens[self.index]
        self.index += 1
        if expected is not None and token != expected:
            raise ValueError(f'expected {expected!r}, got {token!r}')
        return token

    def value(self):
        token = self.take()
        if token == '{':
            result = {}
            while self.tokens[self.index] != '}':
                key = self.value()
                self.take('=')
                if not isinstance(key, str) or key in result:
                    raise ValueError(f'duplicate or invalid project key: {key}')
                result[key] = self.value()
                self.take(';')
            self.take('}')
            return result
        if token == '(':
            result = []
            while self.tokens[self.index] != ')':
                result.append(self.value())
                if self.tokens[self.index] != ')':
                    self.take(',')
            self.take(')')
            return result
        if token in '} ) = ; ,'.split():
            raise ValueError(f'unexpected punctuation {token}')
        return json.loads(token) if token.startswith('"') else token

    def parse(self):
        result = self.value()
        if self.index != len(self.tokens):
            raise ValueError('trailing project tokens')
        return result


def validate(root: Path) -> list[str]:
    root = root.resolve()
    errors: list[str] = []

    def error(message):
        errors.append(message)

    def local(base, relative, label):
        if not isinstance(relative, str) or not relative:
            error(f'{label}: missing relative path')
            return None
        path = (base / relative).resolve()
        if not path.is_relative_to(root):
            error(f'{label}: path escapes project: {relative}')
        elif not path.exists():
            error(f'{label}: missing path: {path.relative_to(root)}')
        else:
            return path
        return None

    def read(path, loader):
        try:
            return loader(path.read_bytes())
        except (OSError, ValueError, TypeError, ET.ParseError, IndexError) as exc:
            error(f'{path.relative_to(root)}: {exc}')
            return None

    resources = root / 'FrameGuide/Resources'
    local(root, 'Core/Package.swift', 'SwiftPM manifest')
    local(root, 'Core/Sources/FrameGuideCore', 'Core sources')
    local(root, 'Core/Tests/FrameGuideCoreTests', 'Core tests')
    info = read(resources / 'Info.plist', plistlib.loads)
    if isinstance(info, dict):
        for key in ('NSCameraUsageDescription', 'NSPhotoLibraryAddUsageDescription'):
            if not isinstance(info.get(key), str) or not re.search('[\u3400-\u9fff]', info[key]):
                error(f'Info.plist: {key} must have Chinese purpose text')
        for key in info:
            if key.endswith('UsageDescription') and key not in {
                    'NSCameraUsageDescription', 'NSPhotoLibraryAddUsageDescription'}:
                error(f'Info.plist: unsupported permission {key}')
        if info.get('UISupportedInterfaceOrientations') != ['UIInterfaceOrientationPortrait']:
            error('Info.plist: iPhone orientation must be portrait only')
        if 'UILaunchStoryboardName' in info:
            error('Info.plist: launch screen must not depend on storyboard')
        if info.get('UILaunchScreen') != {'UIColorName': 'LaunchBackground'}:
            error('Info.plist: expected LaunchBackground launch color')
    elif info is not None:
        error('Info.plist: root must be a dictionary')

    privacy = read(resources / 'PrivacyInfo.xcprivacy', plistlib.loads)
    expected = {'NSPrivacyTracking': False, 'NSPrivacyTrackingDomains': [],
                'NSPrivacyCollectedDataTypes': [], 'NSPrivacyAccessedAPITypes': []}
    if privacy is not None and (not isinstance(privacy, dict) or privacy != expected or
                               type(privacy.get('NSPrivacyTracking')) is not bool):
        error('PrivacyInfo.xcprivacy: expected no tracking, collection or accessed API declarations')

    assets = resources / 'Assets.xcassets'
    for required in ('Contents.json', 'AppIcon.appiconset/Contents.json',
                     'LaunchBackground.colorset/Contents.json'):
        local(assets, required, 'asset catalog')
    for path in sorted(assets.rglob('Contents.json')):
        catalog = read(path, json.loads)
        if not isinstance(catalog, dict):
            error(f'{path.relative_to(root)}: expected JSON object')
            continue
        if not isinstance(catalog.get('info'), dict) or catalog['info'].get('version') != 1:
            error(f'{path.relative_to(root)}: invalid catalog version')
        images = catalog.get('images', [])
        if not isinstance(images, list):
            error(f'{path.relative_to(root)}: images must be an array')
            images = []
        for item in images:
            if isinstance(item, dict) and 'filename' in item:
                local(path.parent, item['filename'], 'asset image')
        if path.parent.name == 'AppIcon.appiconset':
            images = catalog.get('images', [])
            if images != [{'filename': 'AppIcon.png', 'idiom': 'universal',
                           'platform': 'ios', 'size': '1024x1024'}]:
                error('AppIcon: expected universal iOS 1024x1024 entry')
        if path.parent.name == 'LaunchBackground.colorset':
            if catalog.get('colors') != [{'idiom': 'universal', 'color': {
                    'platform': 'universal', 'reference': 'systemBackgroundColor'}}]:
                error('LaunchBackground: expected systemBackgroundColor')
    icon = resources / 'Assets.xcassets/AppIcon.appiconset/AppIcon.png'
    try:
        data = icon.read_bytes()
        if data[:8] != b'\x89PNG\r\n\x1a\n':
            raise ValueError('invalid PNG signature')
        offset, compressed, header, ended = 8, bytearray(), None, False
        while offset < len(data):
            length = struct.unpack('>I', data[offset:offset + 4])[0]
            kind = data[offset + 4:offset + 8]
            payload = data[offset + 8:offset + 8 + length]
            checksum = struct.unpack('>I', data[offset + 8 + length:offset + 12 + length])[0]
            if zlib.crc32(kind + payload) != checksum:
                raise ValueError('PNG chunk checksum mismatch')
            if kind == b'IHDR':
                header = struct.unpack('>IIBBBBB', payload)
            if kind == b'IDAT':
                compressed.extend(payload)
            if kind == b'tRNS':
                raise ValueError('AppIcon cannot have transparency')
            offset += length + 12
            if kind == b'IEND':
                ended = True
                break
        if header != (1024, 1024, 8, 2, 0, 0, 0) or not ended or offset != len(data):
            raise ValueError('expected complete opaque RGB 1024x1024 PNG')
        pixels = zlib.decompress(compressed)
        if len(pixels) != 1024 * (1 + 1024 * 3):
            raise ValueError('PNG pixel data has wrong length')
    except (OSError, ValueError, struct.error, zlib.error) as exc:
        error(f'AppIcon.png: {exc}')

    project_path = root / 'FrameGuide.xcodeproj/project.pbxproj'
    project = read(project_path, lambda data: OpenStep(data.decode('utf-8-sig')).parse())
    if isinstance(project, dict):
        try:
            validate_membership(root, project, local, error)
        except (KeyError, TypeError, ValueError, AttributeError) as exc:
            error(f'project.pbxproj: invalid project structure: {exc}')
    elif project is not None:
        error('project.pbxproj: root must be a dictionary')

    schemes = sorted((root / 'FrameGuide.xcodeproj/xcshareddata/xcschemes').glob('*.xcscheme'))
    if not schemes:
        error('scheme: missing shared scheme')
    objects = project.get('objects', {}) if isinstance(project, dict) else {}
    if not isinstance(objects, dict):
        error('project.pbxproj: objects must be a dictionary')
        objects = {}
    for scheme in schemes:
        xml = read(scheme, ET.fromstring)
        if xml is None:
            continue
        if xml.tag != 'Scheme' or xml.find('BuildAction') is None or xml.find('LaunchAction') is None:
            error(f'{scheme.name}: expected Scheme with build and launch actions')
        references = xml.findall('.//BuildableReference')
        if not references:
            error(f'{scheme.name}: no buildable target')
        for ref in references:
            container = ref.get('ReferencedContainer', '')
            if not container.startswith('container:'):
                error(f'{scheme.name}: unsupported container {container}')
            else:
                local(root, container.removeprefix('container:'), scheme.name)
                if container != 'container:FrameGuide.xcodeproj':
                    error(f'{scheme.name}: unexpected project container {container}')
            target = objects.get(ref.get('BlueprintIdentifier'), {})
            if not isinstance(target, dict) or target.get('isa') != 'PBXNativeTarget' or target.get('name') != ref.get('BlueprintName'):
                error(f'{scheme.name}: unresolved target {ref.get("BlueprintIdentifier")}')

    # Scan the product sources/resources, not local forensic scratch or documentation.
    domain = re.compile(rb'(?i)(?:[a-z0-9-]+\.)+[a-z]{2,}')
    for path in product_files(root):
        if path.suffix.lower() in {'.ipa', '.dylib'}:
            error(f'forbidden binary: {path.relative_to(root)}')
    for tree in ('FrameGuide', 'Core', 'FrameGuide.xcodeproj'):
        for path in product_files(root / tree):
            try:
                content = path.read_bytes()
                hosts = [match.group().decode('ascii').lower() for match in domain.finditer(content)]
                if any(any(host == suffix or host.endswith('.' + suffix)
                           for suffix in PRIVATE_HOST_SUFFIXES) or
                       any('doka' in label for label in host.split('.')) for host in hosts):
                    error(f'private Doka domain: {path.relative_to(root)}')
                if path.suffix == '.swift':
                    for api in ('UserDefaults', 'systemUptime', 'mach_absolute_time',
                                'mach_continuous_time', 'creationDate', 'modificationDate',
                                'contentModificationDate', 'volumeCreationDate', 'getattrlist',
                                'stat(', 'fstat(', 'lstat('):
                        if api.encode() in content:
                            error(f'undeclared persistence/time API {api}: {path.relative_to(root)}')
            except OSError as exc:
                error(f'{path.relative_to(root)}: {exc}')
    return errors


def validate_membership(root, project, local, error):
    objects = project['objects']
    pbx = objects[project['rootObject']]
    if pbx['isa'] != 'PBXProject':
        raise ValueError('rootObject is not PBXProject')
    targets = [objects[t] for t in pbx['targets'] if objects[t].get('name') == 'FrameGuide']
    if len(targets) != 1:
        raise ValueError('expected one FrameGuide target')
    target = targets[0]
    paths = {}

    def visit(identifier, base, ancestors):
        if identifier in ancestors:
            raise ValueError(f'cyclic group {identifier}')
        obj = objects[identifier]
        source_tree = obj.get('sourceTree', '<group>')
        if source_tree == 'BUILT_PRODUCTS_DIR':
            return
        if source_tree not in {'<group>', 'SOURCE_ROOT'}:
            raise ValueError(f'unsupported sourceTree {source_tree} for {identifier}')
        base = root if source_tree == 'SOURCE_ROOT' else base
        path = local(base, obj['path'], identifier) if 'path' in obj else base
        if path is None:
            return
        paths[identifier] = path
        for child in obj.get('children', []):
            visit(child, path, ancestors | {identifier})

    visit(pbx['mainGroup'], root, set())
    for identifier, obj in objects.items():
        if obj.get('isa') in {'PBXFileReference', 'PBXGroup', 'PBXFileSystemSynchronizedRootGroup'}:
            if identifier not in paths and obj.get('sourceTree') != 'BUILT_PRODUCTS_DIR':
                error(f'project reference {identifier}: missing from main group or path does not exist')
    counts = Counter()
    for phase_id in target.get('buildPhases', []):
        phase = objects[phase_id]
        if phase['isa'] != 'PBXSourcesBuildPhase':
            continue
        for build_id in phase.get('files', []):
            ref = objects[build_id]['fileRef']
            if ref not in paths:
                error(f'source build reference {ref} has no existing group path')
            else:
                counts[paths[ref]] += 1
    target_id = next(key for key, value in objects.items() if value is target)
    for group_id in target.get('fileSystemSynchronizedGroups', []):
        group = objects[group_id]
        if group['isa'] != 'PBXFileSystemSynchronizedRootGroup' or group_id not in paths:
            raise ValueError(f'invalid synchronized group {group_id}')
        excluded = set()
        for exception_id in group.get('exceptions', []):
            exception = objects[exception_id]
            if exception.get('target') == target_id:
                excluded.update(exception.get('membershipExceptions', []))
        group_path = paths[group_id]
        for relative in excluded:
            local(group_path, relative, f'synchronized membership exception {group_id}')
        for path in product_files(group_path):
            relative = path.relative_to(group_path).as_posix()
            if path.suffix == '.swift' and not any(
                    relative == exc or relative.startswith(exc.rstrip('/') + '/') for exc in excluded):
                counts[path.resolve()] += 1
        if group_path == (root / 'FrameGuide').resolve() and 'Resources/Info.plist' not in excluded:
            error('Info.plist: must be excluded from synchronized resource membership')
        for resource in ('Resources/PrivacyInfo.xcprivacy', 'Resources/Assets.xcassets'):
            if any(resource == exc or resource.startswith(exc.rstrip('/') + '/') for exc in excluded):
                error(f'resource excluded from target: {resource}')
    for folder in ('FrameGuide', 'Core/Sources'):
        for path in product_files(root / folder):
            if path.suffix == '.swift' and counts[path.resolve()] != 1:
                error(f'Swift source {path.relative_to(root)}: expected 1 target membership, got {counts[path.resolve()]}')
    config_list = objects[target['buildConfigurationList']]
    for identifier in config_list['buildConfigurations']:
        config = objects[identifier]
        settings = config['buildSettings']
        for key, value in {'IPHONEOS_DEPLOYMENT_TARGET': '17.0', 'TARGETED_DEVICE_FAMILY': '1',
                           'ASSETCATALOG_COMPILER_APPICON_NAME': 'AppIcon',
                           'INFOPLIST_FILE': 'FrameGuide/Resources/Info.plist'}.items():
            if settings.get(key) != value:
                error(f'{config["name"]}: {key} must be {value}')
        for key in ('INFOPLIST_FILE', 'CODE_SIGN_ENTITLEMENTS'):
            if key in settings:
                local(root, settings[key], f'{config["name"]} {key}')


def main():
    errors = validate(Path(__file__).resolve().parents[1])
    for error in errors:
        print(f'ERROR: {error}')
    if not errors:
        print('PASS: project structure validated (static only; Swift compilation and device behavior not tested).')
    return 1 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
