import XCTest
@testable import FrameGuideCore

final class GeometryTests: XCTestCase {
    func testVisionOriginAndSelfieMirror() {
        let rect = NormalizedRect(x: 0.1, y: 0.2, width: 0.3, height: 0.4)
        let upright = PreviewGeometry.fromVision(rect)
        XCTAssertEqual(upright.y, 0.4, accuracy: 0.0001)
        XCTAssertEqual(PreviewGeometry.mirror(upright).x, 0.6, accuracy: 0.0001)
    }

    func testWideSourceCropsSidesWithoutShrinkingBounds() {
        let result = PreviewGeometry.aspectFill(
            NormalizedRect(x: 0, y: 0.2, width: 1, height: 0.6),
            sourceAspect: 2, viewAspect: 1)
        XCTAssertEqual(result.x, -0.5, accuracy: 0.0001)
        XCTAssertEqual(result.width, 2, accuracy: 0.0001)
        XCTAssertEqual(result.y, 0.2, accuracy: 0.0001)
    }

    func testTallSourceCropsTopAndBottom() {
        let result = PreviewGeometry.aspectFill(
            NormalizedRect(x: 0.2, y: 0, width: 0.6, height: 1),
            sourceAspect: 0.5, viewAspect: 1)
        XCTAssertEqual(result.y, -0.5, accuracy: 0.0001)
        XCTAssertEqual(result.height, 2, accuracy: 0.0001)
        XCTAssertEqual(result.x, 0.2, accuracy: 0.0001)
    }

    func testEqualAspectsAreIdentity() {
        let rect = NormalizedRect(x: 0.1, y: 0.2, width: 0.3, height: 0.4)
        XCTAssertEqual(PreviewGeometry.aspectFill(rect, sourceAspect: 0.75, viewAspect: 0.75), rect)
    }

    func testIntersectionContainsAndClamping() {
        let a = NormalizedRect(x: 0, y: 0, width: 0.5, height: 0.5)
        let b = NormalizedRect(x: 0.25, y: 0, width: 0.5, height: 0.5)
        XCTAssertEqual(a.intersectionOverUnion(with: b), 1.0 / 3, accuracy: 0.0001)
        XCTAssertTrue(a.contains(NormalizedPoint(x: 0.5, y: 0.5)))
        XCTAssertFalse(a.contains(NormalizedPoint(x: 0.6, y: 0.5)))
        let clamped = NormalizedRect(x: -0.2, y: 0.8, width: 0.5, height: 0.5).clamped()
        XCTAssertEqual(clamped.x, 0)
        XCTAssertEqual(clamped.y, 0.8)
        XCTAssertEqual(clamped.width, 0.3, accuracy: 0.0001)
        XCTAssertEqual(clamped.height, 0.2, accuracy: 0.0001)
    }

    func testDegenerateAndOffscreenRectangles() {
        let zero = NormalizedRect(x: 0, y: 0, width: 0, height: 0)
        XCTAssertEqual(zero.intersectionOverUnion(with: zero), 0)
        XCTAssertFalse(zero.contains(NormalizedPoint(x: 0, y: 0)))
        let outside = NormalizedRect(x: 2, y: 2, width: 0.2, height: 0.2).clamped()
        XCTAssertEqual(outside.width, 0)
        XCTAssertEqual(outside.height, 0)
    }
}
