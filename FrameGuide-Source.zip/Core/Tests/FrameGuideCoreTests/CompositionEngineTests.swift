import XCTest
@testable import FrameGuideCore

final class CompositionEngineTests: XCTestCase {
    let center = GuidancePreferences(scene: .portrait, placement: .center)

    func candidate(_ id: String = "person", x: Double = 0.35, y: Double = 0.2,
                   width: Double = 0.3, height: Double = 0.6,
                   kind: SubjectKind = .person, confidence: Double = 0.9) -> SubjectCandidate {
        SubjectCandidate(id: id, kind: kind,
                         bounds: NormalizedRect(x: x, y: y, width: width, height: height),
                         confidence: confidence)
    }

    func update(_ engine: inout CompositionEngine, _ time: Double,
                _ subjects: [SubjectCandidate], preferences: GuidancePreferences? = nil,
                roll: Double? = 0, horizon: Double? = nil) -> GuidanceResult {
        engine.update(snapshot: AnalysisSnapshot(timestamp: time, subjects: subjects,
                                                horizonRadians: horizon),
                      rollRadians: roll, preferences: preferences ?? center)
    }

    func testReadyRequiresStableHoldAndExpires() {
        var engine = CompositionEngine()
        XCTAssertEqual(update(&engine, 1, [candidate()]).phase, .steady)
        XCTAssertEqual(update(&engine, 1.59, [candidate()]).phase, .steady)
        XCTAssertEqual(update(&engine, 1.7, [candidate()]).phase, .ready)
        XCTAssertNil(engine.expire(at: 2.4))
        let expired = engine.expire(at: 2.6)
        XCTAssertEqual(expired?.phase, .searching)
        XCTAssertNil(expired?.subject)
        XCTAssertNil(expired?.target)
        XCTAssertNil(engine.expire(at: 3))
    }

    func testWatchdogDoesNotRejectNewerDelayedFrame() {
        var engine = CompositionEngine()
        _ = update(&engine, 1.0, [candidate()])
        XCTAssertNil(engine.expire(at: 1.3))
        let moved = update(&engine, 1.2, [candidate(x: 0.1)])
        XCTAssertEqual(moved.phase, .adjusting)
        XCTAssertEqual(moved.direction, .right)
        // Freshness follows capture time, not delivery/watchdog time.
        XCTAssertNil(engine.expire(at: 1.9))
        XCTAssertEqual(engine.expire(at: 2.01)?.phase, .searching)
    }

    func testDelayedFramesStillRejectTrueOutOfOrderAndStaleCaptures() {
        var engine = CompositionEngine()
        _ = update(&engine, 1.0, [candidate()])
        _ = engine.expire(at: 1.3)
        _ = update(&engine, 1.2, [candidate(x: 0.1)])
        XCTAssertEqual(update(&engine, 1.1, [candidate()]).phase, .adjusting)
        XCTAssertEqual(engine.expire(at: 2.01)?.phase, .searching)
        XCTAssertNil(update(&engine, 1.205, [candidate()]).subject)
        XCTAssertNil(engine.expire(at: 1.9))
        XCTAssertEqual(update(&engine, 2.1, [candidate()]).phase, .steady)
    }

    func testPositionDirectionsExpressDesiredSubjectMotion() {
        for (x, y, direction) in [(0.1, 0.4, GuidanceDirection.right),
                                   (0.7, 0.4, .left), (0.4, 0.1, .down), (0.4, 0.7, .up)] {
            var engine = CompositionEngine()
            XCTAssertEqual(update(&engine, 1, [candidate(x: x, y: y, width: 0.2, height: 0.2)]).direction,
                           direction)
        }
    }

    func testAutomaticAndPortraitPreferPeopleAndLandscapePrefersSaliency() {
        for mode in SceneMode.allCases {
            var engine = CompositionEngine()
            let person = candidate(confidence: 0.5)
            let salient = candidate("object", x: 0.1, kind: .salient, confidence: 0.99)
            let result = update(&engine, 1, [salient, person],
                                preferences: GuidancePreferences(scene: mode, placement: .center))
            XCTAssertEqual(result.subject, mode == .landscape ? salient.bounds : person.bounds)
        }
    }

    func testContinuityUsesOverlapEvenWhenDetectionIDsChange() {
        var engine = CompositionEngine()
        let tracked = candidate(confidence: 0.6)
        _ = update(&engine, 1, [tracked])
        let continuation = candidate("new-id", confidence: 0.6)
        let distraction = candidate("other", x: 0.7, width: 0.2, confidence: 0.99)
        XCTAssertEqual(update(&engine, 1.7, [distraction, continuation]).phase, .ready)
    }

    func testConfidenceThenAreaBreaksInitialSelectionTies() {
        var engine = CompositionEngine()
        let small = candidate("small", x: 0.1, width: 0.1)
        let large = candidate("large", x: 0.6)
        XCTAssertEqual(update(&engine, 1, [small, large]).subject, large.bounds)
    }

    func testTapSwitchesSubjectAndResetsHold() {
        var engine = CompositionEngine()
        let a = candidate()
        let b = candidate("b", x: 0.7, width: 0.2)
        _ = update(&engine, 1, [a, b])
        XCTAssertEqual(update(&engine, 1.7, [a, b]).phase, .ready)
        XCTAssertFalse(engine.selectSubject(at: NormalizedPoint(x: 0.01, y: 0.01)))
        XCTAssertTrue(engine.selectSubject(at: NormalizedPoint(x: 0.8, y: 0.5)))
        XCTAssertEqual(update(&engine, 1.8, [a, b]).subject, b.bounds)
        XCTAssertEqual(update(&engine, 1.9, [a, b]).phase, .adjusting)
    }

    func testRejectsLowConfidenceEmptyAndInvisibleCandidates() {
        var engine = CompositionEngine()
        for subjects in [[], [candidate(confidence: 0.44)], [candidate(x: 2)],
                         [candidate(width: 0)], [candidate(x: .nan)]] {
            XCTAssertEqual(update(&engine, 1, subjects).phase, .searching)
        }
        XCTAssertEqual(update(&engine, 2, [candidate(confidence: 0.45)]).phase, .steady)
    }

    func testLossImmediatelyRevokesReadyAndReacquisitionRestartsHold() {
        var engine = CompositionEngine()
        _ = update(&engine, 1, [candidate()])
        _ = update(&engine, 1.7, [candidate()])
        XCTAssertEqual(update(&engine, 1.8, []).phase, .searching)
        XCTAssertEqual(update(&engine, 1.9, [candidate()]).phase, .steady)
        XCTAssertNil(update(&engine, 2.8, []).subject)
    }

    func testEmptyFramesDoNotExtendExpiration() {
        var engine = CompositionEngine()
        _ = update(&engine, 1, [candidate()])
        _ = update(&engine, 1.4, [])
        XCTAssertEqual(engine.expire(at: 1.81)?.phase, .searching)
    }

    func testPreferenceChangeResetsStableTimeAndTarget() {
        var engine = CompositionEngine()
        _ = update(&engine, 1, [candidate()])
        _ = update(&engine, 1.7, [candidate()])
        let automatic = GuidancePreferences(scene: .automatic, placement: .center)
        XCTAssertEqual(update(&engine, 1.8, [candidate()], preferences: automatic).phase, .steady)
        let left = GuidancePreferences(scene: .portrait, placement: .leftThird)
        let result = update(&engine, 1.9, [candidate()], preferences: left)
        XCTAssertEqual(result.target?.x, 1.0 / 3)
        XCTAssertEqual(result.direction, .left)
    }

    func testSmartTargetLocksAndLeavesRoomForWideSubjects() {
        var engine = CompositionEngine()
        let smart = GuidancePreferences(scene: .automatic, placement: .smart)
        let first = update(&engine, 1, [candidate(x: 0.18)], preferences: smart)
        XCTAssertEqual(first.target?.x, 1.0 / 3)
        XCTAssertEqual(update(&engine, 1.2, [candidate(x: 0.25)], preferences: smart).target, first.target)
        engine.reset()
        XCTAssertEqual(update(&engine, 2, [candidate(x: 0.05, width: 0.9)], preferences: smart).target?.x, 0.5)
    }

    func testTiltHasPriorityOverEdgesAndPosition() {
        var engine = CompositionEngine()
        let result = update(&engine, 1, [candidate(x: 0)], roll: 0.1)
        XCTAssertEqual(result.phase, .adjusting)
        XCTAssertEqual(result.direction, .none)
        XCTAssertEqual(result.message, "请保持画面水平")
    }

    func testLandscapeCanUseHorizonWithoutMotion() {
        var engine = CompositionEngine()
        let landscape = GuidancePreferences(scene: .landscape, placement: .center)
        XCTAssertEqual(update(&engine, 1, [candidate(kind: .salient)], preferences: landscape,
                              roll: nil, horizon: 0.1).message, "请保持画面水平")
    }

    func testLandscapeFaceOnlyRequiresExplicitTap() {
        var engine = CompositionEngine()
        let prefs = GuidancePreferences(scene: .landscape, placement: .center)
        let face = candidate(kind: .face)
        for t in [1.0, 1.7] {
            let result = update(&engine, t, [face], preferences: prefs)
            XCTAssertEqual(result.phase, .searching)
            XCTAssertNil(result.subject)
            XCTAssertNil(result.target)
        }
        XCTAssertTrue(engine.selectSubject(at: face.bounds.center))
        XCTAssertEqual(update(&engine, 1.8, [face], preferences: prefs).phase, .steady)
        XCTAssertEqual(update(&engine, 2.5, [face], preferences: prefs).phase, .ready)
    }

    func testLandscapeHorizonOnlyExpiresWithoutSubject() {
        var engine = CompositionEngine()
        let prefs = GuidancePreferences(scene: .landscape, placement: .center)
        let result = update(&engine, 1, [], preferences: prefs, roll: nil, horizon: 0.12)
        XCTAssertEqual(result.phase, .adjusting)
        XCTAssertEqual(result.message, "请保持画面水平")
        XCTAssertNil(result.target)
        XCTAssertNil(result.subject)
        XCTAssertEqual(engine.expire(at: 1.81)?.phase, .searching)
    }

    func testLandscapeTapCandidatesExpireEvenWithoutAutoSubject() {
        var engine = CompositionEngine()
        let prefs = GuidancePreferences(scene: .landscape, placement: .center)
        let face = candidate(kind: .face)
        _ = update(&engine, 1, [face], preferences: prefs)
        _ = engine.expire(at: 1.81)
        XCTAssertFalse(engine.selectSubject(at: face.bounds.center))
    }

    func testEdgeWarningPreventsReadyAndPointsInward() {
        var engine = CompositionEngine()
        let result = update(&engine, 1, [candidate(x: -0.1, width: 1.2)])
        XCTAssertEqual(result.phase, .adjusting)
        XCTAssertEqual(result.message, "请为主体留出边缘空间")
    }

    func testResetClearsCandidatesAndAllTimers() {
        var engine = CompositionEngine()
        _ = update(&engine, 1, [candidate()])
        _ = update(&engine, 1.7, [candidate()])
        engine.reset()
        XCTAssertFalse(engine.selectSubject(at: NormalizedPoint(x: 0.5, y: 0.5)))
        XCTAssertNil(engine.expire(at: 10))
        XCTAssertEqual(update(&engine, 11, [candidate()]).phase, .steady)
    }

    func testOutOfOrderTimestampsCannotAccumulateHold() {
        var engine = CompositionEngine()
        _ = update(&engine, 10, [candidate()])
        XCTAssertEqual(update(&engine, 9, [candidate()]).phase, .steady)
        XCTAssertEqual(update(&engine, 10.2, [candidate()]).phase, .steady)
        XCTAssertNil(engine.expire(at: 9))
    }

    func testFreshMotionRevokesReadyEvenWhenDisplayBoxIsSmoothed() {
        var engine = CompositionEngine()
        _ = update(&engine, 1, [candidate()])
        XCTAssertEqual(update(&engine, 1.7, [candidate()]).phase, .ready)
        let moved = update(&engine, 1.8, [candidate(x: 0.43)])
        XCTAssertEqual(moved.phase, .adjusting)
        XCTAssertEqual(moved.direction, .left)
        XCTAssertLessThan(moved.subject!.x, 0.43)
        XCTAssertEqual(update(&engine, 1.9, [candidate()]).phase, .steady)
    }

    func testTapOnNestedCandidateRestartsHoldEvenAtSamePosition() {
        var engine = CompositionEngine()
        let person = candidate()
        let face = candidate("face", x: 0.4, y: 0.4, width: 0.2, height: 0.2,
                             kind: .face, confidence: 0.5)
        _ = update(&engine, 1, [person, face])
        _ = update(&engine, 1.7, [person, face])
        XCTAssertTrue(engine.selectSubject(at: NormalizedPoint(x: 0.5, y: 0.5)))
        XCTAssertEqual(update(&engine, 1.8, [person, face]).subject, face.bounds)
        XCTAssertEqual(update(&engine, 1.9, [person, face]).phase, .steady)
    }

    func testToleranceAndRightThirdTarget() {
        var engine = CompositionEngine()
        let right = GuidancePreferences(scene: .portrait, placement: .rightThird)
        let result = update(&engine, 1, [candidate(x: 2.0 / 3 - 0.15)],
                            preferences: right, roll: 3 * Double.pi / 180)
        XCTAssertEqual(result.target?.x, 2.0 / 3)
        XCTAssertEqual(result.phase, .steady)
        engine.reset()
        XCTAssertEqual(update(&engine, 2, [candidate(x: 0.4)]).phase, .steady)
        engine.reset()
        XCTAssertEqual(update(&engine, 3, [candidate(x: 0.42)]).phase, .adjusting)
    }
}
