import XCTest
@testable import FrameGuideCore

final class CompositionEngineTests: XCTestCase {
    let center = GuidancePreferences(scene: .portrait, placement: .center)

    func candidate(_ id: String = "person", x: Double = 0.35, y: Double = 0.2,
                   width: Double = 0.3, height: Double = 0.6,
                   kind: SubjectKind = .person, confidence: Double = 0.9) -> SubjectCandidate {
        SubjectCandidate(id: id, kind: kind,
                         bounds: NormalizedRect(x: x, y: y, width: width, height: height),
                         confidence: confidence)
    }

    func update(_ engine: inout CompositionEngine, _ time: Double,
                _ subjects: [SubjectCandidate], preferences: GuidancePreferences? = nil,
                roll: Double? = 0, horizon: Double? = nil,
                goal: CompositionGoal? = nil) -> GuidanceResult {
        engine.update(snapshot: AnalysisSnapshot(timestamp: time, subjects: subjects,
                                                horizonRadians: horizon),
                      rollRadians: roll, preferences: preferences ?? center, goal: goal)
    }

    func testAIGoalFrameUsesLocalScalePlacementAndObservedAspect() throws {
        for (framing, height) in [(FramingScale.environment, 0.35), (.fullBody, 0.70), (.halfBody, 0.85)] {
            for (placement, x) in [(PlacementMode.leftThird, 1.0 / 3), (.center, 0.5), (.rightThird, 2.0 / 3)] {
                var engine = CompositionEngine()
                let goal = CompositionGoal(scene: .portrait, placement: placement, framing: framing)
                let result = update(&engine, 1, [candidate()], goal: goal)
                let target = try XCTUnwrap(result.targetBounds)
                XCTAssertEqual(target.height, height, accuracy: 0.0001)
                XCTAssertEqual(target.width, height / 2, accuracy: 0.0001)
                XCTAssertEqual(target.center.x, x, accuracy: 0.0001)
                XCTAssertEqual(target.center.y, 0.5, accuracy: 0.0001)
                XCTAssertEqual(result.target, target.center)
                XCTAssertNotEqual(result.subject, result.targetBounds)
            }
        }
    }

    func testAIWideTargetFitsPreviewAndCanBecomeReady() throws {
        var engine = CompositionEngine()
        let goal = CompositionGoal(scene: .portrait, placement: .leftThird, framing: .halfBody)
        let subject = candidate(x: 0.1, y: 0.3, width: 0.8, height: 0.4)
        let result = update(&engine, 1, [subject], goal: goal)
        let target = try XCTUnwrap(result.targetBounds)
        XCTAssertEqual(target.x, 0.025, accuracy: 0.0001)
        XCTAssertEqual(target.width / target.height, 2, accuracy: 0.0001)
        XCTAssertEqual(target.height, 0.475, accuracy: 0.0001)
        XCTAssertLessThanOrEqual(target.x + target.width, 1)
        let aligned = candidate(x: target.x, y: target.y, width: target.width, height: target.height)
        XCTAssertEqual(update(&engine, 1.2, [aligned], goal: goal).phase, .steady)
        XCTAssertEqual(update(&engine, 1.85, [aligned], goal: goal).phase, .ready)
    }

    func testAIGoalCenterToleranceAndDominantScaleError() {
        let goal = CompositionGoal(scene: .portrait, placement: .center, framing: .fullBody)
        for (x, height, direction) in [(0.40, 0.70, GuidanceDirection.none), (0.42, 0.70, .left),
                                       (0.35, 0.55, .closer), (0.35, 0.85, .farther),
                                       (0.42, 0.50, .closer), (0.50, 0.60, .left)] {
            var engine = CompositionEngine()
            let observed = candidate(x: x, y: (1 - height) / 2, height: height)
            let result = update(&engine, 1, [observed], goal: goal)
            XCTAssertEqual(result.direction, direction)
            XCTAssertEqual(result.phase, direction == .none ? .steady : .adjusting)
        }
    }

    func testAIWidthLimitedGoalUsesWidthForReadiness() throws {
        var engine = CompositionEngine()
        let goal = CompositionGoal(scene: .portrait, placement: .center, framing: .environment)
        let subject = candidate(x: 0.175, y: 0.41875, width: 0.65, height: 0.1625)
        let first = update(&engine, 1, [subject], goal: goal)
        let target = try XCTUnwrap(first.targetBounds)
        XCTAssertEqual(target.width, 0.95, accuracy: 0.0001)
        XCTAssertEqual(target.height, 0.2375, accuracy: 0.0001)
        XCTAssertEqual(first.direction, .closer)
        XCTAssertEqual(update(&engine, 1.7, [subject], goal: goal).phase, .adjusting)
        let aligned = candidate(x: target.x, y: target.y, width: target.width, height: target.height)
        XCTAssertEqual(update(&engine, 1.8, [aligned], goal: goal).phase, .steady)
        XCTAssertEqual(update(&engine, 2.45, [aligned], goal: goal).phase, .ready)
    }

    func testAIGoalPositionMessagesMatchSubjectMotionDirections() {
        let goal = CompositionGoal(scene: .portrait, placement: .center, framing: .fullBody)
        for (x, y, direction, message) in [
            (0.25, 0.15, GuidanceDirection.right, "让主体向右对齐目标框"),
            (0.45, 0.15, .left, "让主体向左对齐目标框"),
            (0.35, 0.06, .down, "让主体向下对齐目标框"),
            (0.35, 0.24, .up, "让主体向上对齐目标框")
        ] {
            var engine = CompositionEngine()
            let result = update(&engine, 1, [candidate(x: x, y: y, height: 0.7)], goal: goal)
            XCTAssertEqual(result.direction, direction)
            XCTAssertEqual(result.message, message)
        }
    }

    func testAIGoalSceneUsesItsOwnSubjectPreferenceAndHorizon() {
        var engine = CompositionEngine()
        let goal = CompositionGoal(scene: .landscape, placement: .center, framing: .fullBody)
        let person = candidate()
        let salient = candidate("object", y: 0.15, height: 0.7, kind: .salient, confidence: 0.5)
        let result = update(&engine, 1, [person, salient], roll: nil, horizon: 0.1, goal: goal)
        XCTAssertEqual(result.subject, salient.bounds)
        XCTAssertEqual(result.message, "请保持画面水平")
    }

    func testAITiltMovementAndDetectionGapsRestartHold() {
        var engine = CompositionEngine()
        let goal = CompositionGoal(scene: .portrait, placement: .center, framing: .fullBody)
        let aligned = candidate(y: 0.15, height: 0.70)
        let small = candidate(y: 0.23, height: 0.54)
        XCTAssertEqual(update(&engine, 1, [aligned], goal: goal).phase, .steady)
        XCTAssertEqual(update(&engine, 1.7, [aligned], goal: goal).phase, .ready)
        let tilted = update(&engine, 1.8, [small], roll: 0.1, goal: goal)
        XCTAssertEqual(tilted.direction, .none)
        XCTAssertEqual(tilted.message, "请保持画面水平")
        XCTAssertEqual(update(&engine, 1.9, [small], goal: goal).direction, .closer)
        XCTAssertEqual(update(&engine, 2, [aligned], goal: goal).phase, .steady)
        XCTAssertEqual(update(&engine, 2.7, [aligned], goal: goal).phase, .ready)
        XCTAssertEqual(update(&engine, 2.8, [small], goal: goal).direction, .closer)
        XCTAssertEqual(update(&engine, 2.9, [aligned], goal: goal).phase, .steady)
        XCTAssertEqual(update(&engine, 3.55, [aligned], goal: goal).phase, .ready)
        let gap = update(&engine, 3.65, [], goal: goal)
        XCTAssertEqual(gap.phase, .searching)
        XCTAssertNotNil(gap.targetBounds)
        XCTAssertEqual(update(&engine, 3.75, [aligned], goal: goal).phase, .steady)
        let expired = engine.expire(at: 4.6)
        XCTAssertEqual(expired?.phase, .searching)
        XCTAssertNil(expired?.targetBounds)
        XCTAssertNil(expired?.subject)
        let reacquired = update(&engine, 4.7, [aligned], goal: goal)
        XCTAssertEqual(reacquired.phase, .steady)
        XCTAssertEqual(reacquired.subject, aligned.bounds)
        XCTAssertNotNil(reacquired.targetBounds)
        XCTAssertEqual(update(&engine, 5.35, [aligned], goal: goal).phase, .ready)
    }

    func testChangingAIGoalOrReturningToLocalGuidanceRestartsHold() {
        var engine = CompositionEngine()
        let aligned = candidate(y: 0.11, height: 0.78)
        let full = CompositionGoal(scene: .portrait, placement: .center, framing: .fullBody)
        let half = CompositionGoal(scene: .portrait, placement: .center, framing: .halfBody)
        XCTAssertEqual(update(&engine, 1, [aligned], goal: half).phase, .steady)
        XCTAssertEqual(update(&engine, 1.7, [aligned], goal: half).phase, .ready)
        let fullAligned = candidate(y: 0.115, height: 0.77)
        XCTAssertEqual(update(&engine, 1.8, [fullAligned], goal: full).phase, .steady)
        XCTAssertEqual(update(&engine, 2.45, [fullAligned], goal: full).phase, .ready)
        let local = update(&engine, 2.5, [fullAligned])
        XCTAssertEqual(local.phase, .steady)
        XCTAssertNil(local.targetBounds)
    }

    func testApplyingAndChangingAIPlanPreservesManuallySelectedSubject() throws {
        var engine = CompositionEngine()
        let firstGoal = CompositionGoal(scene: .portrait, placement: .center, framing: .fullBody)
        let alternateGoal = CompositionGoal(scene: .landscape, placement: .rightThird, framing: .environment)
        let primary = candidate("primary", x: 0.08, y: 0.2, width: 0.28, height: 0.6,
                                kind: .person, confidence: 0.98)
        let tapped = candidate("tapped-face", x: 0.66, y: 0.28, width: 0.18, height: 0.22,
                               kind: .face, confidence: 0.6)
        _ = update(&engine, 1, [primary, tapped])
        XCTAssertTrue(engine.selectSubject(at: tapped.bounds.center))

        let firstPlan = update(&engine, 1.1, [primary, tapped], goal: firstGoal)
        XCTAssertEqual(firstPlan.subject, tapped.bounds)

        let result = update(&engine, 1.2, [primary, tapped],
                            preferences: GuidancePreferences(scene: .landscape, placement: .rightThird),
                            goal: alternateGoal)

        let target = try XCTUnwrap(result.targetBounds)
        XCTAssertEqual(result.subject, tapped.bounds)
        XCTAssertEqual(target.center.x, 2.0 / 3, accuracy: 0.0001)
        XCTAssertEqual(result.phase, .adjusting)
    }

    func testRestartingAIPlanHoldKeepsManualSubjectAndRequiresFreshStability() {
        var engine = CompositionEngine()
        let goal = CompositionGoal(scene: .portrait, placement: .center, framing: .fullBody)
        let primary = candidate("primary", x: 0.08, y: 0.2, width: 0.28, height: 0.6,
                                kind: .person, confidence: 0.98)
        let tapped = candidate("tapped-face", x: 0.35, y: 0.15, width: 0.3, height: 0.7,
                               kind: .face, confidence: 0.6)
        _ = update(&engine, 1, [primary, tapped], goal: goal)
        XCTAssertTrue(engine.selectSubject(at: tapped.bounds.center))
        XCTAssertEqual(update(&engine, 1.1, [primary, tapped], goal: goal).subject, tapped.bounds)
        XCTAssertEqual(update(&engine, 1.8, [primary, tapped], goal: goal).phase, .ready)

        engine.resetStability()

        let restarted = update(&engine, 1.9, [primary, tapped], goal: goal)
        XCTAssertEqual(restarted.subject, tapped.bounds)
        XCTAssertEqual(restarted.phase, .steady)
        XCTAssertEqual(update(&engine, 2.55, [primary, tapped], goal: goal).phase, .ready)
    }

    func testReadyRequiresStableHoldAndExpires() {
        var engine = CompositionEngine()
        XCTAssertEqual(update(&engine, 1, [candidate()]).phase, .steady)
        XCTAssertEqual(update(&engine, 1.59, [candidate()]).phase, .steady)
        XCTAssertEqual(update(&engine, 1.7, [candidate()]).phase, .ready)
        XCTAssertNil(engine.expire(at: 2.4))
        let expired = engine.expire(at: 2.6)
        XCTAssertEqual(expired?.phase, .searching)
        XCTAssertNil(expired?.subject)
        XCTAssertNil(expired?.target)
        XCTAssertNil(engine.expire(at: 3))
    }

    func testWatchdogDoesNotRejectNewerDelayedFrame() {
        var engine = CompositionEngine()
        _ = update(&engine, 1.0, [candidate()])
        XCTAssertNil(engine.expire(at: 1.3))
        let moved = update(&engine, 1.2, [candidate(x: 0.1)])
        XCTAssertEqual(moved.phase, .adjusting)
        XCTAssertEqual(moved.direction, .right)
        // Freshness follows capture time, not delivery/watchdog time.
        XCTAssertNil(engine.expire(at: 1.9))
        XCTAssertEqual(engine.expire(at: 2.01)?.phase, .searching)
    }

    func testDelayedFramesStillRejectTrueOutOfOrderAndStaleCaptures() {
        var engine = CompositionEngine()
        _ = update(&engine, 1.0, [candidate()])
        _ = engine.expire(at: 1.3)
        _ = update(&engine, 1.2, [candidate(x: 0.1)])
        XCTAssertEqual(update(&engine, 1.1, [candidate()]).phase, .adjusting)
        XCTAssertEqual(engine.expire(at: 2.01)?.phase, .searching)
        XCTAssertNil(update(&engine, 1.205, [candidate()]).subject)
        XCTAssertNil(engine.expire(at: 1.9))
        XCTAssertEqual(update(&engine, 2.1, [candidate()]).phase, .steady)
    }

    func testPositionDirectionsExpressDesiredSubjectMotion() {
        for (x, y, direction) in [(0.1, 0.4, GuidanceDirection.right),
                                   (0.7, 0.4, .left), (0.4, 0.1, .down), (0.4, 0.7, .up)] {
            var engine = CompositionEngine()
            XCTAssertEqual(update(&engine, 1, [candidate(x: x, y: y, width: 0.2, height: 0.2)]).direction,
                           direction)
        }
    }

    func testAutomaticAndPortraitPreferPeopleAndLandscapePrefersSaliency() {
        for mode in SceneMode.allCases {
            var engine = CompositionEngine()
            let person = candidate(confidence: 0.5)
            let salient = candidate("object", x: 0.1, kind: .salient, confidence: 0.99)
            let result = update(&engine, 1, [salient, person],
                                preferences: GuidancePreferences(scene: mode, placement: .center))
            XCTAssertEqual(result.subject, mode == .landscape ? salient.bounds : person.bounds)
        }
    }

    func testContinuityUsesOverlapEvenWhenDetectionIDsChange() {
        var engine = CompositionEngine()
        let tracked = candidate(confidence: 0.6)
        _ = update(&engine, 1, [tracked])
        let continuation = candidate("new-id", confidence: 0.6)
        let distraction = candidate("other", x: 0.7, width: 0.2, confidence: 0.99)
        XCTAssertEqual(update(&engine, 1.7, [distraction, continuation]).phase, .ready)
    }

    func testConfidenceThenAreaBreaksInitialSelectionTies() {
        var engine = CompositionEngine()
        let small = candidate("small", x: 0.1, width: 0.1)
        let large = candidate("large", x: 0.6)
        XCTAssertEqual(update(&engine, 1, [small, large]).subject, large.bounds)
    }

    func testTapSwitchesSubjectAndResetsHold() {
        var engine = CompositionEngine()
        let a = candidate()
        let b = candidate("b", x: 0.7, width: 0.2)
        _ = update(&engine, 1, [a, b])
        XCTAssertEqual(update(&engine, 1.7, [a, b]).phase, .ready)
        XCTAssertFalse(engine.selectSubject(at: NormalizedPoint(x: 0.01, y: 0.01)))
        XCTAssertTrue(engine.selectSubject(at: NormalizedPoint(x: 0.8, y: 0.5)))
        XCTAssertEqual(update(&engine, 1.8, [a, b]).subject, b.bounds)
        XCTAssertEqual(update(&engine, 1.9, [a, b]).phase, .adjusting)
    }

    func testRejectsLowConfidenceEmptyAndInvisibleCandidates() {
        var engine = CompositionEngine()
        for subjects in [[], [candidate(confidence: 0.44)], [candidate(x: 2)],
                         [candidate(width: 0)], [candidate(x: .nan)]] {
            XCTAssertEqual(update(&engine, 1, subjects).phase, .searching)
        }
        XCTAssertEqual(update(&engine, 2, [candidate(confidence: 0.45)]).phase, .steady)
    }

    func testLossImmediatelyRevokesReadyAndReacquisitionRestartsHold() {
        var engine = CompositionEngine()
        _ = update(&engine, 1, [candidate()])
        _ = update(&engine, 1.7, [candidate()])
        XCTAssertEqual(update(&engine, 1.8, []).phase, .searching)
        XCTAssertEqual(update(&engine, 1.9, [candidate()]).phase, .steady)
        XCTAssertNil(update(&engine, 2.8, []).subject)
    }

    func testEmptyFramesDoNotExtendExpiration() {
        var engine = CompositionEngine()
        _ = update(&engine, 1, [candidate()])
        _ = update(&engine, 1.4, [])
        XCTAssertEqual(engine.expire(at: 1.81)?.phase, .searching)
    }

    func testPreferenceChangeResetsStableTimeAndTarget() {
        var engine = CompositionEngine()
        _ = update(&engine, 1, [candidate()])
        _ = update(&engine, 1.7, [candidate()])
        let automatic = GuidancePreferences(scene: .automatic, placement: .center)
        XCTAssertEqual(update(&engine, 1.8, [candidate()], preferences: automatic).phase, .steady)
        let left = GuidancePreferences(scene: .portrait, placement: .leftThird)
        let result = update(&engine, 1.9, [candidate()], preferences: left)
        XCTAssertEqual(result.target?.x, 1.0 / 3)
        XCTAssertEqual(result.direction, .left)
    }

    func testSmartTargetLocksAndLeavesRoomForWideSubjects() {
        var engine = CompositionEngine()
        let smart = GuidancePreferences(scene: .automatic, placement: .smart)
        let first = update(&engine, 1, [candidate(x: 0.18)], preferences: smart)
        XCTAssertEqual(first.target?.x, 1.0 / 3)
        XCTAssertEqual(update(&engine, 1.2, [candidate(x: 0.25)], preferences: smart).target, first.target)
        engine.reset()
        XCTAssertEqual(update(&engine, 2, [candidate(x: 0.05, width: 0.9)], preferences: smart).target?.x, 0.5)
    }

    func testTiltHasPriorityOverEdgesAndPosition() {
        var engine = CompositionEngine()
        let result = update(&engine, 1, [candidate(x: 0)], roll: 0.1)
        XCTAssertEqual(result.phase, .adjusting)
        XCTAssertEqual(result.direction, .none)
        XCTAssertEqual(result.message, "请保持画面水平")
    }

    func testLandscapeCanUseHorizonWithoutMotion() {
        var engine = CompositionEngine()
        let landscape = GuidancePreferences(scene: .landscape, placement: .center)
        XCTAssertEqual(update(&engine, 1, [candidate(kind: .salient)], preferences: landscape,
                              roll: nil, horizon: 0.1).message, "请保持画面水平")
    }

    func testLandscapeFaceOnlyRequiresExplicitTap() {
        var engine = CompositionEngine()
        let prefs = GuidancePreferences(scene: .landscape, placement: .center)
        let face = candidate(kind: .face)
        for t in [1.0, 1.7] {
            let result = update(&engine, t, [face], preferences: prefs)
            XCTAssertEqual(result.phase, .searching)
            XCTAssertNil(result.subject)
            XCTAssertNil(result.target)
        }
        XCTAssertTrue(engine.selectSubject(at: face.bounds.center))
        XCTAssertEqual(update(&engine, 1.8, [face], preferences: prefs).phase, .steady)
        XCTAssertEqual(update(&engine, 2.5, [face], preferences: prefs).phase, .ready)
    }

    func testLandscapeHorizonOnlyExpiresWithoutSubject() {
        var engine = CompositionEngine()
        let prefs = GuidancePreferences(scene: .landscape, placement: .center)
        let result = update(&engine, 1, [], preferences: prefs, roll: nil, horizon: 0.12)
        XCTAssertEqual(result.phase, .adjusting)
        XCTAssertEqual(result.message, "请保持画面水平")
        XCTAssertNil(result.target)
        XCTAssertNil(result.subject)
        XCTAssertEqual(engine.expire(at: 1.81)?.phase, .searching)
    }

    func testLandscapeTapCandidatesExpireEvenWithoutAutoSubject() {
        var engine = CompositionEngine()
        let prefs = GuidancePreferences(scene: .landscape, placement: .center)
        let face = candidate(kind: .face)
        _ = update(&engine, 1, [face], preferences: prefs)
        _ = engine.expire(at: 1.81)
        XCTAssertFalse(engine.selectSubject(at: face.bounds.center))
    }

    func testEdgeWarningPreventsReadyAndPointsInward() {
        var engine = CompositionEngine()
        let result = update(&engine, 1, [candidate(x: -0.1, width: 1.2)])
        XCTAssertEqual(result.phase, .adjusting)
        XCTAssertEqual(result.message, "请为主体留出边缘空间")
    }

    func testResetClearsCandidatesAndAllTimers() {
        var engine = CompositionEngine()
        _ = update(&engine, 1, [candidate()])
        _ = update(&engine, 1.7, [candidate()])
        engine.reset()
        XCTAssertFalse(engine.selectSubject(at: NormalizedPoint(x: 0.5, y: 0.5)))
        XCTAssertNil(engine.expire(at: 10))
        XCTAssertEqual(update(&engine, 11, [candidate()]).phase, .steady)
    }

    func testOutOfOrderTimestampsCannotAccumulateHold() {
        var engine = CompositionEngine()
        _ = update(&engine, 10, [candidate()])
        XCTAssertEqual(update(&engine, 9, [candidate()]).phase, .steady)
        XCTAssertEqual(update(&engine, 10.2, [candidate()]).phase, .steady)
        XCTAssertNil(engine.expire(at: 9))
    }

    func testFreshMotionRevokesReadyEvenWhenDisplayBoxIsSmoothed() {
        var engine = CompositionEngine()
        _ = update(&engine, 1, [candidate()])
        XCTAssertEqual(update(&engine, 1.7, [candidate()]).phase, .ready)
        let moved = update(&engine, 1.8, [candidate(x: 0.43)])
        XCTAssertEqual(moved.phase, .adjusting)
        XCTAssertEqual(moved.direction, .left)
        XCTAssertLessThan(moved.subject!.x, 0.43)
        XCTAssertEqual(update(&engine, 1.9, [candidate()]).phase, .steady)
    }

    func testTapOnNestedCandidateRestartsHoldEvenAtSamePosition() {
        var engine = CompositionEngine()
        let person = candidate()
        let face = candidate("face", x: 0.4, y: 0.4, width: 0.2, height: 0.2,
                             kind: .face, confidence: 0.5)
        _ = update(&engine, 1, [person, face])
        _ = update(&engine, 1.7, [person, face])
        XCTAssertTrue(engine.selectSubject(at: NormalizedPoint(x: 0.5, y: 0.5)))
        XCTAssertEqual(update(&engine, 1.8, [person, face]).subject, face.bounds)
        XCTAssertEqual(update(&engine, 1.9, [person, face]).phase, .steady)
    }

    func testToleranceAndRightThirdTarget() {
        var engine = CompositionEngine()
        let right = GuidancePreferences(scene: .portrait, placement: .rightThird)
        let result = update(&engine, 1, [candidate(x: 2.0 / 3 - 0.15)],
                            preferences: right, roll: 3 * Double.pi / 180)
        XCTAssertEqual(result.target?.x, 2.0 / 3)
        XCTAssertEqual(result.phase, .steady)
        engine.reset()
        XCTAssertEqual(update(&engine, 2, [candidate(x: 0.4)]).phase, .steady)
        engine.reset()
        XCTAssertEqual(update(&engine, 3, [candidate(x: 0.42)]).phase, .adjusting)
    }
}
