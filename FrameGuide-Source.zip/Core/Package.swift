// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "FrameGuideCore",
    platforms: [.iOS(.v17), .macOS(.v13)],
    products: [.library(name: "FrameGuideCore", targets: ["FrameGuideCore"])],
    targets: [
        .target(name: "FrameGuideCore"),
        .testTarget(name: "FrameGuideCoreTests", dependencies: ["FrameGuideCore"])
    ]
)
