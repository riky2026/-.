/// Deterministic state machine. All time arguments share one monotonic clock in seconds.
/// Snapshot order is independent of watchdog evaluation order. Both clocks use
/// the same monotonic epoch; callers must not pass wall-clock dates.
public struct CompositionEngine: Sendable {
    private var candidates: [SubjectCandidate] = []
    private var selected: SubjectCandidate?
    private var manualSelection = false
    private var target: NormalizedPoint?
    private var preferences: GuidancePreferences?
    private var stableSince: Double?
    private var lastSeen: Double?
    private var lastSnapshotTime: Double?
    private var lastEvaluationTime: Double?
    private var lastResult = GuidanceResult(phase: .searching, subject: nil, target: nil,
                                            direction: .none, message: "换个角度，或点选主体")

    public init() {}

    public mutating func reset() { self = CompositionEngine() }

    public mutating func selectSubject(at point: NormalizedPoint) -> Bool {
        // Prefer the smallest hit box so a face inside a person remains selectable.
        guard let hit = candidates.filter({ $0.bounds.contains(point) })
            .min(by: { $0.bounds.area < $1.bounds.area }) else { return false }
        selected = hit
        manualSelection = true
        target = nil
        stableSince = nil
        return true
    }

    public mutating func update(snapshot: AnalysisSnapshot, rollRadians: Double?,
                                preferences newPreferences: GuidancePreferences) -> GuidanceResult {
        let time = snapshot.timestamp
        guard time.isFinite,
              lastSnapshotTime.map({ time >= $0 }) ?? true,
              lastEvaluationTime.map({ $0 - time <= 0.8 }) ?? true else { return lastResult }
        lastSnapshotTime = time
        lastEvaluationTime = max(lastEvaluationTime ?? time, time)
        if preferences != newPreferences {
            clearTracking()
            preferences = newPreferences
        }
        if let seen = lastSeen, time - seen > 0.8 { clearTracking() }
        candidates = snapshot.subjects.filter {
            $0.confidence.isFinite && $0.confidence >= 0.45 &&
                $0.bounds.isValid && $0.bounds.clamped().area > 0
        }
        let horizon = newPreferences.scene == .landscape ? snapshot.horizonRadians : nil
        let tilted = [rollRadians, horizon].compactMap { $0 }.contains {
            $0.isFinite && abs($0) > 3 * Double.pi / 180
        }
        guard let next = chooseSubject(scene: newPreferences.scene) else {
            stableSince = nil
            if newPreferences.scene == .landscape && tilted {
                lastResult = GuidanceResult(phase: .adjusting, subject: nil, target: nil,
                                            direction: .none, message: "请保持画面水平")
                return lastResult
            }
            // Briefly retain the old box, but never retain ready during a detection gap.
            lastResult = GuidanceResult(phase: .searching, subject: selected?.bounds,
                                        target: target, direction: .none,
                                        message: "换个角度，或点选主体")
            return lastResult
        }

        let continuing = selected.map { matches($0, next) } ?? false
        if !continuing {
            target = nil
            stableSince = nil
            manualSelection = false
        }
        // Light temporal smoothing applies only within the tracked subject.
        let bounds = continuing ? smooth(previous: selected!.bounds, current: next.bounds) : next.bounds
        selected = SubjectCandidate(id: next.id, kind: next.kind, bounds: bounds, confidence: next.confidence)
        lastSeen = time
        if target == nil { target = makeTarget(bounds: bounds, placement: newPreferences.placement) }
        let destination = target!
        if tilted {
            return adjusting(bounds, destination, .none, "请保持画面水平")
        }
        // Readiness uses the current observation: display smoothing must not mask motion.
        let observed = next.bounds
        if observed.x < 0.025 || observed.y < 0.025 ||
            observed.x + observed.width > 0.975 || observed.y + observed.height > 0.975 {
            let direction: GuidanceDirection
            if observed.x < 0.025 { direction = .right }
            else if observed.x + observed.width > 0.975 { direction = .left }
            else if observed.y < 0.025 { direction = .down }
            else { direction = .up }
            return adjusting(bounds, destination, direction, "请为主体留出边缘空间")
        }
        let dx = destination.x - observed.center.x
        let dy = destination.y - observed.center.y
        if abs(dx) > 0.06 || abs(dy) > 0.06 {
            let direction: GuidanceDirection
            if abs(dx) >= abs(dy) { direction = dx > 0 ? .right : .left }
            else { direction = dy > 0 ? .down : .up }
            let message: String
            switch direction {
            case .left: message = "让主体靠近左侧标记"
            case .right: message = "让主体靠近右侧标记"
            case .up: message = "让主体靠近上方标记"
            default: message = "让主体靠近下方标记"
            }
            return adjusting(bounds, destination, direction, message)
        }
        if stableSince == nil { stableSince = time }
        let ready = time - stableSince! >= 0.6
        lastResult = GuidanceResult(phase: ready ? .ready : .steady, subject: bounds,
                                    target: destination, direction: .none,
                                    message: ready ? "构图已就绪" : "保持稳定")
        return lastResult
    }

    /// Returns a clearing result once when the last detected subject is older than 0.8 s.
    public mutating func expire(at timestamp: Double) -> GuidanceResult? {
        guard timestamp.isFinite, lastEvaluationTime.map({ timestamp >= $0 }) ?? true else { return nil }
        lastEvaluationTime = timestamp
        let staleFrame = lastSnapshotTime.map { timestamp - $0 > 0.8 } ?? false
        if staleFrame { candidates = [] }
        let staleSubject = lastSeen.map { timestamp - $0 > 0.8 } ?? false
        if staleSubject { clearTracking() }
        guard (staleSubject && lastResult.subject != nil) ||
                (staleFrame && (lastResult.phase != .searching || selected != nil)) else { return nil }
        clearTracking()
        lastResult = GuidanceResult(phase: .searching, subject: nil, target: nil,
                                    direction: .none, message: "换个角度，或点选主体")
        return lastResult
    }

    private mutating func clearTracking() {
        selected = nil
        target = nil
        stableSince = nil
        lastSeen = nil
        manualSelection = false
    }

    private func matches(_ a: SubjectCandidate, _ b: SubjectCandidate) -> Bool {
        a.kind == b.kind && a.bounds.intersectionOverUnion(with: b.bounds) >= 0.2
    }

    private func chooseSubject(scene: SceneMode) -> SubjectCandidate? {
        if manualSelection, let previous = selected,
           let match = bestMatch(previous, in: candidates) { return match }
        let preferred = candidates.filter {
            scene == .landscape ? $0.kind == .salient : $0.kind != .salient
        }
        let pool = scene != .landscape && preferred.isEmpty ? candidates : preferred
        if let previous = selected, let match = bestMatch(previous, in: pool) { return match }
        return pool.sorted {
            if $0.confidence != $1.confidence { return $0.confidence > $1.confidence }
            if $0.bounds.area != $1.bounds.area { return $0.bounds.area > $1.bounds.area }
            return $0.id < $1.id
        }.first
    }

    private func bestMatch(_ previous: SubjectCandidate, in pool: [SubjectCandidate]) -> SubjectCandidate? {
        pool.filter { matches(previous, $0) }.max {
            previous.bounds.intersectionOverUnion(with: $0.bounds) <
                previous.bounds.intersectionOverUnion(with: $1.bounds)
        }
    }

    private func makeTarget(bounds: NormalizedRect, placement: PlacementMode) -> NormalizedPoint {
        let x: Double
        switch placement {
        case .center: x = 0.5
        case .leftThird: x = 1.0 / 3
        case .rightThird: x = 2.0 / 3
        case .smart:
            let choices = [1.0 / 3, 0.5, 2.0 / 3].filter {
                $0 - bounds.width / 2 >= 0.025 && $0 + bounds.width / 2 <= 0.975
            }
            x = choices.min(by: { abs($0 - bounds.center.x) < abs($1 - bounds.center.x) }) ?? 0.5
        }
        return NormalizedPoint(x: x, y: 0.5)
    }

    private func smooth(previous: NormalizedRect, current: NormalizedRect) -> NormalizedRect {
        let alpha = 0.35
        return NormalizedRect(x: previous.x + alpha * (current.x - previous.x),
                              y: previous.y + alpha * (current.y - previous.y),
                              width: previous.width + alpha * (current.width - previous.width),
                              height: previous.height + alpha * (current.height - previous.height))
    }

    private mutating func adjusting(_ bounds: NormalizedRect, _ target: NormalizedPoint,
                                    _ direction: GuidanceDirection, _ message: String) -> GuidanceResult {
        stableSince = nil
        lastResult = GuidanceResult(phase: .adjusting, subject: bounds, target: target,
                                    direction: direction, message: message)
        return lastResult
    }
}
