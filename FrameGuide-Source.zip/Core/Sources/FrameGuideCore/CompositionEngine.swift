import Foundation

/// Deterministic state machine. All time arguments share one monotonic clock in seconds.
/// Snapshot order is independent of watchdog evaluation order. Both clocks use
/// the same monotonic epoch; callers must not pass wall-clock dates.
public struct CompositionEngine: Sendable {
    private var candidates: [SubjectCandidate] = []
    private var selected: SubjectCandidate?
    private var manualSelection = false
    private var subjectLocked = false
    private var target: NormalizedPoint?
    private var targetBounds: NormalizedRect?
    private var preferences: GuidancePreferences?
    private var goal: CompositionGoal?
    private var stableSince: Double?
    private var lastSeen: Double?
    private var lastSnapshotTime: Double?
    private var lastEvaluationTime: Double?
    private var motionWarningActive = false
    private var lastResult = GuidanceResult(phase: .searching, subject: nil, target: nil,
                                            direction: .none, message: "换个角度，或点选主体")

    public init() {}

    public mutating func reset() { self = CompositionEngine() }

    /// Starts a new ready hold without discarding the selected subject or current goal.
    public mutating func resetStability() { stableSince = nil }

    public mutating func selectSubject(at point: NormalizedPoint) -> Bool {
        // Prefer the smallest hit box so a face inside a person remains selectable.
        guard let hit = candidates.filter({ $0.bounds.contains(point) })
            .min(by: { $0.bounds.area < $1.bounds.area }) else { return false }
        selected = hit
        manualSelection = true
        target = nil
        targetBounds = nil
        stableSince = nil
        return true
    }

    /// A long press explicitly locks the selected candidate. Long pressing it
    /// again unlocks it so automatic subject selection can take over.
    public mutating func toggleSubjectLock(at point: NormalizedPoint) -> Bool {
        guard let hit = candidates.filter({ $0.bounds.contains(point) })
            .min(by: { $0.bounds.area < $1.bounds.area }) else { return false }
        if subjectLocked, let selected, matches(selected, hit) {
            self.selected = hit
            manualSelection = false
            subjectLocked = false
        } else {
            selected = hit
            manualSelection = true
            subjectLocked = true
        }
        target = nil
        targetBounds = nil
        stableSince = nil
        return true
    }

    public mutating func update(snapshot: AnalysisSnapshot, rollRadians: Double?,
                                preferences newPreferences: GuidancePreferences,
                                goal newGoal: CompositionGoal? = nil,
                                cameraRotationRate: Double? = nil) -> GuidanceResult {
        let time = snapshot.timestamp
        guard time.isFinite,
              lastSnapshotTime.map({ time >= $0 }) ?? true,
              lastEvaluationTime.map({ $0 - time <= 0.8 }) ?? true else { return lastResult }
        lastSnapshotTime = time
        lastEvaluationTime = max(lastEvaluationTime ?? time, time)
        updateMotionWarning(cameraRotationRate)
        let scene = newGoal?.scene ?? newPreferences.scene
        let selectedAIPlanChanged = newGoal != nil && goal != newGoal
        if selectedAIPlanChanged {
            // A new AI plan changes its target, not the subject the user tapped.
            target = nil
            targetBounds = nil
            stableSince = nil
            preferences = newPreferences
        } else if preferences != newPreferences || (goal?.scene ?? preferences?.scene) != scene {
            clearTracking()
            preferences = newPreferences
        } else if goal != newGoal {
            target = nil
            targetBounds = nil
            stableSince = nil
        }
        goal = newGoal
        if let seen = lastSeen, time - seen > (subjectLocked ? 1.5 : 0.8) { clearTracking() }
        candidates = snapshot.subjects.filter {
            $0.confidence.isFinite && $0.confidence >= 0.45 &&
                $0.bounds.isValid && $0.bounds.clamped().area > 0
        }
        let horizon = scene == .landscape ? snapshot.horizonRadians : nil
        let angles = [rollRadians, horizon].compactMap { $0 }.filter { $0.isFinite }
        let tilted = angles.contains {
            $0.isFinite && abs($0) > 3 * Double.pi / 180
        }
        let stronglyTilted = angles.contains { abs($0) > 8 * Double.pi / 180 }
        guard let next = chooseSubject(scene: scene) else {
            stableSince = nil
            if newGoal == nil && scene == .landscape && tilted {
                lastResult = GuidanceResult(phase: .adjusting, subject: nil, target: nil,
                                            direction: .none, message: "请保持画面水平")
                return lastResult
            }
            // Briefly retain the old box, but never retain ready during a detection gap.
            lastResult = GuidanceResult(phase: .searching, subject: selected?.bounds,
                                        target: newGoal == nil ? target : targetBounds?.center, direction: .none,
                                        message: subjectLocked ? "正在重新寻找已锁定主体" : "换个角度，或点选主体",
                                        targetBounds: targetBounds, subjectLocked: subjectLocked)
            return lastResult
        }

        let continuing = selected.map { matches($0, next) } ?? false
        if !continuing {
            target = nil
            stableSince = nil
            manualSelection = false
            subjectLocked = false
        }
        // Light temporal smoothing applies only within the tracked subject.
        let bounds = continuing ? smooth(previous: selected!.bounds, current: next.bounds) : next.bounds
        selected = SubjectCandidate(id: next.id, kind: next.kind, bounds: bounds, confidence: next.confidence)
        lastSeen = time
        if let newGoal {
            return guideFraming(newGoal, displayed: bounds, observed: next.bounds,
                                tilted: tilted, stronglyTilted: stronglyTilted,
                                cameraMoving: motionWarningActive, time: time)
        }
        if target == nil { target = makeTarget(bounds: bounds, placement: newPreferences.placement) }
        let destination = target!
        if stronglyTilted {
            return adjusting(bounds, destination, .none, "请保持画面水平")
        }
        if motionWarningActive {
            return adjusting(bounds, destination, .none, "请稳住手机")
        }
        // Readiness uses the current observation: display smoothing must not mask motion.
        let observed = next.bounds
        if let direction = inwardDirection(observed, margin: 0.025) {
            return adjusting(bounds, destination, direction, "请为主体留出边缘空间")
        }
        let dx = destination.x - observed.center.x
        let dy = destination.y - observed.center.y
        if abs(dx) > 0.06 || abs(dy) > 0.06 {
            let direction: GuidanceDirection
            if abs(dx) >= abs(dy) { direction = dx > 0 ? .right : .left }
            else { direction = dy > 0 ? .down : .up }
            let message: String
            switch direction {
            case .left: message = "让主体靠近左侧标记"
            case .right: message = "让主体靠近右侧标记"
            case .up: message = "让主体靠近上方标记"
            default: message = "让主体靠近下方标记"
            }
            return adjusting(bounds, destination, direction, message)
        }
        if tilted { return adjusting(bounds, destination, .none, "请保持画面水平") }
        return holding(bounds, destination, at: time)
    }

    /// Returns a clearing result once when the last detected subject is older than 0.8 s.
    public mutating func expire(at timestamp: Double) -> GuidanceResult? {
        guard timestamp.isFinite, lastEvaluationTime.map({ timestamp >= $0 }) ?? true else { return nil }
        lastEvaluationTime = timestamp
        let staleFrame = lastSnapshotTime.map { timestamp - $0 > 0.8 } ?? false
        if staleFrame { candidates = [] }
        let staleSubject = lastSeen.map { timestamp - $0 > 0.8 } ?? false
        let lockExpired = subjectLocked && (lastSeen.map { timestamp - $0 > 1.5 } ?? false)
        if staleSubject && (!subjectLocked || lockExpired) { clearTracking() }
        let shouldPublish = (staleSubject && lastResult.phase != .searching) ||
            (staleFrame && lastResult.phase != .searching) || lockExpired
        guard shouldPublish else { return nil }
        lastResult = GuidanceResult(phase: .searching, subject: nil, target: nil,
                                    direction: .none,
                                    message: subjectLocked ? "已锁定主体暂时不可见，重新对准" : "换个角度，或点选主体",
                                    subjectLocked: subjectLocked)
        return lastResult
    }

    private mutating func clearTracking() {
        selected = nil
        target = nil
        targetBounds = nil
        stableSince = nil
        lastSeen = nil
        manualSelection = false
        subjectLocked = false
    }

    private func matches(_ a: SubjectCandidate, _ b: SubjectCandidate) -> Bool {
        guard a.kind == b.kind else { return false }
        if a.bounds.intersectionOverUnion(with: b.bounds) >= 0.2 { return true }
        let distance = hypot(a.bounds.center.x - b.bounds.center.x, a.bounds.center.y - b.bounds.center.y)
        let size = max(max(a.bounds.width, a.bounds.height), max(b.bounds.width, b.bounds.height))
        return distance <= max(0.04, min(0.14, size * 0.45))
    }

    private func chooseSubject(scene: SceneMode) -> SubjectCandidate? {
        if manualSelection, let previous = selected,
           let match = bestMatch(previous, in: candidates) { return match }
        let preferred = candidates.filter {
            scene == .landscape ? $0.kind == .salient : $0.kind != .salient
        }
        let pool = scene != .landscape && preferred.isEmpty ? candidates : preferred
        if let previous = selected, let match = bestMatch(previous, in: pool) { return match }
        return pool.sorted {
            if $0.confidence != $1.confidence { return $0.confidence > $1.confidence }
            if $0.bounds.area != $1.bounds.area { return $0.bounds.area > $1.bounds.area }
            return $0.id < $1.id
        }.first
    }

    private func bestMatch(_ previous: SubjectCandidate, in pool: [SubjectCandidate]) -> SubjectCandidate? {
        pool.filter { matches(previous, $0) }.max {
            trackingScore(previous, $0) < trackingScore(previous, $1)
        }
    }

    private func trackingScore(_ previous: SubjectCandidate, _ candidate: SubjectCandidate) -> Double {
        let overlap = previous.bounds.intersectionOverUnion(with: candidate.bounds)
        let distance = hypot(previous.bounds.center.x - candidate.bounds.center.x,
                             previous.bounds.center.y - candidate.bounds.center.y)
        let size = max(max(previous.bounds.width, previous.bounds.height),
                       max(candidate.bounds.width, candidate.bounds.height))
        let scale = max(0.04, min(0.14, size * 0.45))
        return overlap * 2 - distance / scale
    }

    private mutating func updateMotionWarning(_ rotationRate: Double?) {
        guard let rotationRate, rotationRate.isFinite, rotationRate >= 0 else {
            motionWarningActive = false
            return
        }
        if rotationRate >= 0.9 { motionWarningActive = true }
        else if rotationRate <= 0.45 { motionWarningActive = false }
    }

    private func makeTarget(bounds: NormalizedRect, placement: PlacementMode) -> NormalizedPoint {
        let x: Double
        switch placement {
        case .center: x = 0.5
        case .leftThird: x = 1.0 / 3
        case .rightThird: x = 2.0 / 3
        case .smart:
            let choices = [1.0 / 3, 0.5, 2.0 / 3].filter {
                $0 - bounds.width / 2 >= 0.025 && $0 + bounds.width / 2 <= 0.975
            }
            x = choices.min(by: { abs($0 - bounds.center.x) < abs($1 - bounds.center.x) }) ?? 0.5
        }
        return NormalizedPoint(x: x, y: 0.5)
    }

    private mutating func guideFraming(_ goal: CompositionGoal, displayed: NormalizedRect,
                                       observed: NormalizedRect, tilted: Bool,
                                       stronglyTilted: Bool, cameraMoving: Bool,
                                       time: Double) -> GuidanceResult {
        if target == nil { target = makeTarget(bounds: observed, placement: goal.placement) }
        // Height is a fraction of the preview: leave context, show the full subject, or frame tightly.
        let preferredHeight: Double
        switch goal.framing {
        case .environment: preferredHeight = 0.35
        case .fullBody: preferredHeight = 0.70
        case .halfBody: preferredHeight = 0.85
        }
        // Both boxes already use the same normalized 3:4 preview axes. Scale both dimensions together.
        let margin = 0.025
        let availableWidth = 1 - 2 * margin
        let heightScale = preferredHeight / observed.height
        let widthScale = availableWidth / observed.width
        let scale = min(heightScale, widthScale)
        let width = min(availableWidth, scale * observed.width)
        let height = min(preferredHeight, scale * observed.height)
        let x = min(max(margin, target!.x - width / 2), 1 - margin - width)
        let frame = NormalizedRect(x: x, y: (1 - height) / 2, width: width, height: height)
        targetBounds = frame
        let destination = frame.center
        if stronglyTilted { return adjusting(displayed, destination, .none, "请保持画面水平") }
        if cameraMoving { return adjusting(displayed, destination, .none, "请稳住手机") }

        // Compare errors in tolerance units. The least-aligned dimension leads the instruction.
        let horizontal = (destination.x - observed.center.x) / 0.06
        let vertical = (destination.y - observed.center.y) / 0.06
        // Measure size on the limiting axis so a wide, short subject cannot pass on height alone.
        let sizeDelta = widthScale <= heightScale ? frame.width - observed.width : frame.height - observed.height
        let size = sizeDelta / 0.08
        if abs(size) > 1 && abs(size) > max(abs(horizontal), abs(vertical)) {
            return size > 0 ? adjusting(displayed, destination, .closer, "请靠近主体")
                : adjusting(displayed, destination, .farther, "请远离主体")
        }
        // Direction and text describe the desired subject motion in preview coordinates.
        if abs(horizontal) > 1 && abs(horizontal) >= abs(vertical) {
            return horizontal > 0 ? adjusting(displayed, destination, .right, "让主体向右对齐目标框")
                : adjusting(displayed, destination, .left, "让主体向左对齐目标框")
        }
        if abs(vertical) > 1 {
            return vertical > 0 ? adjusting(displayed, destination, .down, "让主体向下对齐目标框")
                : adjusting(displayed, destination, .up, "让主体向上对齐目标框")
        }
        if let direction = inwardDirection(observed, margin: 0) {
            return adjusting(displayed, destination, direction, "请为主体留出边缘空间")
        }
        if tilted { return adjusting(displayed, destination, .none, "请保持画面水平") }
        return holding(displayed, destination, at: time)
    }

    private func inwardDirection(_ bounds: NormalizedRect, margin: Double) -> GuidanceDirection? {
        if bounds.x < margin { return .right }
        if bounds.x + bounds.width > 1 - margin { return .left }
        if bounds.y < margin { return .down }
        if bounds.y + bounds.height > 1 - margin { return .up }
        return nil
    }

    private mutating func holding(_ bounds: NormalizedRect, _ target: NormalizedPoint,
                                  at time: Double) -> GuidanceResult {
        if stableSince == nil { stableSince = time }
        let ready = time - stableSince! >= 0.6
        lastResult = GuidanceResult(phase: ready ? .ready : .steady, subject: bounds,
                                    target: target, direction: .none,
                                    message: ready ? "构图已就绪" : "保持稳定", targetBounds: targetBounds,
                                    stabilityProgress: min(1, max(0, (time - stableSince!) / 0.6)),
                                    subjectLocked: subjectLocked)
        return lastResult
    }

    private func smooth(previous: NormalizedRect, current: NormalizedRect) -> NormalizedRect {
        let alpha = 0.35
        return NormalizedRect(x: previous.x + alpha * (current.x - previous.x),
                              y: previous.y + alpha * (current.y - previous.y),
                              width: previous.width + alpha * (current.width - previous.width),
                              height: previous.height + alpha * (current.height - previous.height))
    }

    private mutating func adjusting(_ bounds: NormalizedRect, _ target: NormalizedPoint,
                                    _ direction: GuidanceDirection, _ message: String) -> GuidanceResult {
        stableSince = nil
        lastResult = GuidanceResult(phase: .adjusting, subject: bounds, target: target,
                                    direction: direction, message: message, targetBounds: targetBounds,
                                    subjectLocked: subjectLocked)
        return lastResult
    }
}
