// Coordinates use a top-left origin in the upright, mirrored-as-displayed preview.
public struct NormalizedPoint: Equatable, Sendable {
    public var x: Double
    public var y: Double
    public init(x: Double, y: Double) { self.x = x; self.y = y }
}

public struct NormalizedRect: Equatable, Sendable {
    public var x: Double
    public var y: Double
    public var width: Double
    public var height: Double
    public init(x: Double, y: Double, width: Double, height: Double) {
        self.x = x
        self.y = y
        self.width = width
        self.height = height
    }
}

public enum SubjectKind: String, Sendable { case face, person, salient }
public struct SubjectCandidate: Equatable, Sendable {
    public var id: String
    public var kind: SubjectKind
    public var bounds: NormalizedRect
    public var confidence: Double
    public init(id: String, kind: SubjectKind, bounds: NormalizedRect, confidence: Double) {
        self.id = id
        self.kind = kind
        self.bounds = bounds
        self.confidence = confidence
    }
}

public enum SceneMode: String, CaseIterable, Sendable { case automatic, portrait, landscape }
public enum PlacementMode: String, CaseIterable, Sendable { case smart, center, leftThird, rightThird }
public enum FramingScale: String, Equatable, Sendable { case environment, fullBody, halfBody }
public struct CompositionGoal: Equatable, Sendable {
    public let scene: SceneMode
    public let placement: PlacementMode
    public let framing: FramingScale

    public init(scene: SceneMode, placement: PlacementMode, framing: FramingScale) {
        self.scene = scene
        self.placement = placement
        self.framing = framing
    }
}

public struct GuidancePreferences: Equatable, Sendable {
    public var scene: SceneMode
    public var placement: PlacementMode
    public init(scene: SceneMode, placement: PlacementMode) {
        self.scene = scene
        self.placement = placement
    }
}

public struct AnalysisSnapshot: Equatable, Sendable {
    /// Seconds from a monotonic clock, for example system uptime; never wall-clock time.
    public var timestamp: Double
    public var subjects: [SubjectCandidate]
    public var horizonRadians: Double?
    public init(timestamp: Double, subjects: [SubjectCandidate], horizonRadians: Double?) {
        self.timestamp = timestamp
        self.subjects = subjects
        self.horizonRadians = horizonRadians
    }
}

public enum GuidancePhase: String, Sendable { case searching, adjusting, steady, ready }
public enum GuidanceDirection: String, Sendable { case none, left, right, up, down, closer, farther }
public struct GuidanceResult: Equatable, Sendable {
    public var phase: GuidancePhase
    public var subject: NormalizedRect?
    public var target: NormalizedPoint?
    public var targetBounds: NormalizedRect?
    public var direction: GuidanceDirection
    public var message: String
    public var stabilityProgress: Double
    public init(phase: GuidancePhase, subject: NormalizedRect?, target: NormalizedPoint?,
                direction: GuidanceDirection, message: String, targetBounds: NormalizedRect? = nil,
                stabilityProgress: Double = 0) {
        self.phase = phase
        self.subject = subject
        self.target = target
        self.targetBounds = targetBounds
        self.direction = direction
        self.message = message
        self.stabilityProgress = stabilityProgress
    }

    /// The engine describes subject motion. Camera aiming goes in the opposite
    /// direction, except horizontally in a mirrored front-camera preview.
    public func cameraDirection(isFrontCamera: Bool) -> GuidanceDirection {
        switch direction {
        case .left: return isFrontCamera ? .left : .right
        case .right: return isFrontCamera ? .right : .left
        case .up: return .down
        case .down: return .up
        default: return direction
        }
    }

    /// A screen-space aiming cue around a fixed central reticle, not an AR
    /// world anchor. The cue converges as the subject reaches its desired position.
    public func cameraAim(isFrontCamera: Bool) -> NormalizedPoint? {
        guard phase != .searching, let subject, subject.isValid, let target,
              target.x.isFinite, target.y.isFinite else { return nil }
        if phase == .steady || phase == .ready { return NormalizedPoint(x: 0.5, y: 0.5) }
        let dx = subject.center.x - target.x
        let dy = subject.center.y - target.y
        let horizontal = abs(dx) <= 0.06 ? 0 : dx * (isFrontCamera ? -1 : 1)
        let vertical = abs(dy) <= 0.06 ? 0 : dy
        return NormalizedPoint(x: min(0.86, max(0.14, 0.5 + horizontal)),
                               y: min(0.82, max(0.18, 0.5 + vertical)))
    }

    public func cameraInstruction(isFrontCamera: Bool) -> String {
        switch phase {
        case .searching: return "对准要拍的主体，也可轻点选择"
        case .steady: return "保持一下"
        case .ready: return "构图已对齐，可以拍摄"
        case .adjusting: break
        }
        switch cameraDirection(isFrontCamera: isFrontCamera) {
        case .left: return "镜头向左转一点"
        case .right: return "镜头向右转一点"
        case .up: return "镜头抬高一点"
        case .down: return "镜头压低一点"
        case .closer: return "向前靠近一点"
        case .farther: return "向后退一点"
        case .none: return message
        }
    }
}
