// Coordinates use a top-left origin in the upright, mirrored-as-displayed preview.
public struct NormalizedPoint: Equatable, Sendable {
    public var x: Double
    public var y: Double
    public init(x: Double, y: Double) { self.x = x; self.y = y }
}

public struct NormalizedRect: Equatable, Sendable {
    public var x: Double
    public var y: Double
    public var width: Double
    public var height: Double
    public init(x: Double, y: Double, width: Double, height: Double) {
        self.x = x
        self.y = y
        self.width = width
        self.height = height
    }
}

public enum SubjectKind: String, Sendable { case face, person, salient }
public struct SubjectCandidate: Equatable, Sendable {
    public var id: String
    public var kind: SubjectKind
    public var bounds: NormalizedRect
    public var confidence: Double
    public init(id: String, kind: SubjectKind, bounds: NormalizedRect, confidence: Double) {
        self.id = id
        self.kind = kind
        self.bounds = bounds
        self.confidence = confidence
    }
}

public enum SceneMode: String, CaseIterable, Sendable { case automatic, portrait, landscape }
public enum PlacementMode: String, CaseIterable, Sendable { case smart, center, leftThird, rightThird }
public enum FramingScale: String, Equatable, Sendable { case environment, fullBody, halfBody }
public struct CompositionGoal: Equatable, Sendable {
    public let scene: SceneMode
    public let placement: PlacementMode
    public let framing: FramingScale

    public init(scene: SceneMode, placement: PlacementMode, framing: FramingScale) {
        self.scene = scene
        self.placement = placement
        self.framing = framing
    }
}

public struct GuidancePreferences: Equatable, Sendable {
    public var scene: SceneMode
    public var placement: PlacementMode
    public init(scene: SceneMode, placement: PlacementMode) {
        self.scene = scene
        self.placement = placement
    }
}

public struct AnalysisSnapshot: Equatable, Sendable {
    /// Seconds from a monotonic clock, for example system uptime; never wall-clock time.
    public var timestamp: Double
    public var subjects: [SubjectCandidate]
    public var horizonRadians: Double?
    public init(timestamp: Double, subjects: [SubjectCandidate], horizonRadians: Double?) {
        self.timestamp = timestamp
        self.subjects = subjects
        self.horizonRadians = horizonRadians
    }
}

public enum GuidancePhase: String, Sendable { case searching, adjusting, steady, ready }
public enum GuidanceDirection: String, Sendable { case none, left, right, up, down, closer, farther }
public struct GuidanceResult: Equatable, Sendable {
    public var phase: GuidancePhase
    public var subject: NormalizedRect?
    public var target: NormalizedPoint?
    public var targetBounds: NormalizedRect?
    public var direction: GuidanceDirection
    public var message: String
    public init(phase: GuidancePhase, subject: NormalizedRect?, target: NormalizedPoint?,
                direction: GuidanceDirection, message: String, targetBounds: NormalizedRect? = nil) {
        self.phase = phase
        self.subject = subject
        self.target = target
        self.targetBounds = targetBounds
        self.direction = direction
        self.message = message
    }
}
