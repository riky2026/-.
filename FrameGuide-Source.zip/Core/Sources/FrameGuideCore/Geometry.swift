extension NormalizedRect {
    public var center: NormalizedPoint {
        NormalizedPoint(x: x + width / 2, y: y + height / 2)
    }

    var isValid: Bool {
        x.isFinite && y.isFinite && width.isFinite && height.isFinite &&
        width > 0 && height > 0 && (x + width).isFinite && (y + height).isFinite
    }

    var area: Double { isValid ? width * height : 0 }

    public func intersectionOverUnion(with other: NormalizedRect) -> Double {
        guard isValid, other.isValid else { return 0 }
        let intersection = max(0, min(x + width, other.x + other.width) - max(x, other.x)) *
            max(0, min(y + height, other.y + other.height) - max(y, other.y))
        let union = area + other.area - intersection
        return union > 0 && union.isFinite ? intersection / union : 0
    }

    public func contains(_ point: NormalizedPoint) -> Bool {
        isValid && point.x >= x && point.x <= x + width &&
            point.y >= y && point.y <= y + height
    }

    public func clamped() -> NormalizedRect {
        guard isValid else { return NormalizedRect(x: 0, y: 0, width: 0, height: 0) }
        let left = min(1, max(0, x))
        let top = min(1, max(0, y))
        return NormalizedRect(x: left, y: top,
                              width: max(0, min(1, x + width) - left),
                              height: max(0, min(1, y + height) - top))
    }
}

public enum PreviewGeometry {
    public static func fromVision(_ rect: NormalizedRect) -> NormalizedRect {
        NormalizedRect(x: rect.x, y: 1 - rect.y - rect.height,
                       width: rect.width, height: rect.height)
    }

    public static func mirror(_ rect: NormalizedRect) -> NormalizedRect {
        NormalizedRect(x: 1 - rect.x - rect.width, y: rect.y,
                       width: rect.width, height: rect.height)
    }

    /// Inverse-maps the central aspect-fill crop; deliberately preserves offscreen edges.
    public static func aspectFill(_ rect: NormalizedRect, sourceAspect: Double,
                                  viewAspect: Double) -> NormalizedRect {
        guard sourceAspect.isFinite, viewAspect.isFinite,
              sourceAspect > 0, viewAspect > 0 else { return rect }
        if sourceAspect > viewAspect {
            let scale = sourceAspect / viewAspect
            return NormalizedRect(x: (rect.x - 0.5) * scale + 0.5, y: rect.y,
                                  width: rect.width * scale, height: rect.height)
        }
        let scale = viewAspect / sourceAspect
        return NormalizedRect(x: rect.x, y: (rect.y - 0.5) * scale + 0.5,
                              width: rect.width, height: rect.height * scale)
    }
}
