# FrameGuide iOS Implementation Plan


> 2026-11-19 实时引导更新。以下 DeepSeek 扩展说明适用于当前源码，其余章节记录首版本地相机基线。

> 2026-11-21 用户确认增加 Qwen4-Max。DeepSeek 与 Qwen 的 Key、图片分析同意分别存储；Qwen 通过用户选择的百炼地域与 Workspace ID 构造受限 HTTPS 域名。

## 可选图像构图扩展

- 设置用 SecureField 输入自有 Key，仅保存到本机不跨设备同步的 Keychain；无项目服务器或共享 Key。本地构图不限次数，AI 使用用户的 API 配额与余额。
- 首次选择「启用并分析」时保存本机同意记录，并立即启动分析。此后每次主动开启 AI 分析，截取一张当前 3:4 取景图，编码为最长边不超过 1280 像素的 JPEG，去除位置和原始照片元数据，把图像和提示发送至 DeepSeek chat/completions，模型为 deepseek-flash。其余预览帧和拍摄的照片均在设备上处理。
- 同一时间仅有一个分析请求。取消、切换镜头、进入后台、离开相机、拍摄、重新分析或实际取景尺寸变化都会使旧请求和结果失效。最多返回三套方案，自动应用首选方案，也可手动切换。设备结合检测到的主体，按选中方案的场景、位置和取景尺度实时计算目标框。
- 移动相机、调整主体大小或重新检测到主体时，引导由设备上的分析更新，无需再次请求。无 Key、网络故障或 AI 分析失败时仍可使用本地引导和快门。工程同步组纳入 `FrameGuide/AIComposition` 的生产源码，离线 fixture 单独编译。
- DeepSeek 按其现行政策处理请求，调用使用用户自己的 API 配额和余额。删除 Key 会清除本机凭据，已发送请求仍由 DeepSeek 处理。隐私清单申报照片/视频用于 App 功能、linked=true、tracking=false，accessed APIs 为空。完整商店申报须另行复核。
- 新 CI 在 Core 与照片 fixture 后加入真实生产客户端/快照/协调器离线 fixture，再静态校验及构建两种 iOS 目标。包内外 workflow 必须字节相同，失败保留日志并停止打包。Windows 只提供静态与 ZIP 证据；新原生 CI、真实 API 调用、签名安装及真机验收均待执行，详见 validation.md 与 device-checklist.md。


> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 交付一个用户自用的原生 iPhone 构图相机：本地分析不限次数、构图引导、原生拍照、基础滤镜、保存和分享。

**Architecture:** AVFoundation 管理相机和照片采集，Vision 在后台串行分析节流后的取景帧。独立 Swift 核心模块负责坐标、主体选择、目标与稳定状态，SwiftUI 展示结果；Core Image 和 PhotoKit 分别负责拍后处理和相册写入。首版无服务器与第三方 SDK。

**Tech Stack:** Swift 5 语言模式、SwiftUI、AVFoundation、Vision、Core Motion、Core Image、PhotoKit、Swift Package Manager 单元测试、Xcode 工程、macOS GitHub Actions。

**Spec:** `design.md`，用户已经审阅确认。

## Global Constraints

- 最低系统：iOS 17.0；面向 iPhone，首版拍摄界面固定竖屏。
- 原生技术：Swift、SwiftUI、AVFoundation、Vision、Core Motion、Core Image、PhotoKit。
- 本地相机功能无需 API Key。可选 DeepSeek 分析使用系统网络接口及用户自己的 API Key。
- 用户自己使用，设备为 iPhone，目前只有 Windows 电脑。
- 首版采用设备本地分析，应用不设置构图次数上限；没有账号、购买或远端授权依赖。
- 模式固定为自动、人像、风景；构图位置固定为智能、居中、左侧三分、右侧三分。
- 竖向 3:4 取景；原生照片输出；原片、暖调、清透、黑白四种拍后效果。
- 引导在容差内稳定至少 0.6 秒才就绪；主体丢失超过 0.8 秒移除旧引导。
- 只申请相机与相册仅添加权限；图片在设备内处理。
- 不复用原 IPA 中的二进制、注入库、模型资源或私有接口。
- Windows 静态检查、macOS 编译、模拟器验证、iPhone 真机验证必须分别记录结果。
- 未签名 IPA 不能直接安装到正常 iPhone；不得把源码包或未签名产物描述为可直接安装的成品。

## File Structure

所有实现放入新的 `frameguide-ios/` 目录，保留现有工作区其他项目。

```text
frameguide-ios/
  FrameGuide.xcodeproj/project.pbxproj
  FrameGuide.xcodeproj/xcshareddata/xcschemes/FrameGuide.xcscheme
  FrameGuide/
    App/FrameGuideApp.swift
    App/Theme.swift
    Camera/CameraTypes.swift
    Camera/CameraSession.swift
    Camera/CameraPreview.swift
    Camera/CameraViewModel.swift
    Camera/VisionAnalyzer.swift
    Camera/MotionService.swift
    Camera/CameraScreen.swift
    Camera/GuidanceOverlay.swift
    Camera/CameraSettingsView.swift
    Photo/PhotoTypes.swift
    Photo/PhotoProcessor.swift
    Photo/PhotoLibrary.swift
    Photo/PhotoReviewViewModel.swift
    Photo/PhotoReviewScreen.swift
    Photo/ShareSheet.swift
    Resources/Info.plist
    Resources/PrivacyInfo.xcprivacy
    Resources/Assets.xcassets/Contents.json
    Resources/Assets.xcassets/AppIcon.appiconset/Contents.json
    Resources/Assets.xcassets/AppIcon.appiconset/AppIcon.png
  Core/
    Package.swift
    Sources/FrameGuideCore/Geometry.swift
    Sources/FrameGuideCore/CompositionTypes.swift
    Sources/FrameGuideCore/CompositionEngine.swift
    Tests/FrameGuideCoreTests/GeometryTests.swift
    Tests/FrameGuideCoreTests/CompositionEngineTests.swift
  scripts/validate_project.py
  scripts/package_source.ps1
  .github/workflows/ios.yml
  docs/design.md
  docs/device-checklist.md
  docs/validation.md
  README.md
  .gitignore
```

`Core` 中三个实现文件同时被 Xcode App target 编译；App 不再额外链接同名 Swift Package product。Swift Package 只负责独立算法测试，避免重复符号或本地 package 路径引用错误。

## Task 1: 可独立验证的几何与构图核心

**Files:** `Core/Package.swift`、三个 `Core/Sources/FrameGuideCore/*.swift` 和两个 `Core/Tests/FrameGuideCoreTests/*.swift`；`docs/design.md` 复制已批准设计。

**Interfaces:** 此任务产出后续使用的以下公开类型。结构体均遵循 `Equatable, Sendable`。

```swift
public struct NormalizedPoint { public var x: Double; public var y: Double }
public struct NormalizedRect {
    public var x: Double; public var y: Double
    public var width: Double; public var height: Double
    public var center: NormalizedPoint { NormalizedPoint(x: x + width / 2, y: y + height / 2) }
}
public enum SubjectKind: String, Sendable { case face, person, salient }
public struct SubjectCandidate {
    public var id: String
    public var kind: SubjectKind
    public var bounds: NormalizedRect
    public var confidence: Double
}
public enum SceneMode: String, CaseIterable, Sendable { case automatic, portrait, landscape }
public enum PlacementMode: String, CaseIterable, Sendable { case smart, center, leftThird, rightThird }
public struct GuidancePreferences {
    public var scene: SceneMode
    public var placement: PlacementMode
}
public struct AnalysisSnapshot {
    public var timestamp: Double
    public var subjects: [SubjectCandidate]
    public var horizonRadians: Double?
}
public enum GuidancePhase: String, Sendable { case searching, adjusting, steady, ready }
public enum GuidanceDirection: String, Sendable { case none, left, right, up, down }
public struct GuidanceResult {
    public var phase: GuidancePhase
    public var subject: NormalizedRect?
    public var target: NormalizedPoint?
    public var direction: GuidanceDirection
    public var message: String
}
```

实现文件为各结构体提供参数同名的 `public init`。`Geometry.swift` 产出：

```swift
public enum PreviewGeometry {
    public static func fromVision(_ rect: NormalizedRect) -> NormalizedRect {
        NormalizedRect(x: rect.x, y: 1 - rect.y - rect.height,
                       width: rect.width, height: rect.height)
    }
    public static func mirror(_ rect: NormalizedRect) -> NormalizedRect {
        NormalizedRect(x: 1 - rect.x - rect.width, y: rect.y,
                       width: rect.width, height: rect.height)
    }
}
```

还需实现 `NormalizedRect.intersectionOverUnion(with:) -> Double`、`contains(_:) -> Bool`、`clamped() -> NormalizedRect`，以及 `PreviewGeometry.aspectFill(_:sourceAspect:viewAspect:) -> NormalizedRect`。aspect-fill 算法在源图更宽时裁左右、更高时裁上下，对裁剪偏移做逆映射，不把超出视野的大框压缩成虚假小框。

`CompositionEngine` 为可变结构体，接口固定为：

```swift
public init()
public mutating func reset()
public mutating func selectSubject(at point: NormalizedPoint) -> Bool
public mutating func update(snapshot: AnalysisSnapshot, rollRadians: Double?,
                           preferences: GuidancePreferences) -> GuidanceResult
public mutating func expire(at timestamp: Double) -> GuidanceResult?
```

- [ ] **Step 1: 建立项目隔离目录与核心测试包，写真实行为测试。** 工作区不是 Git 仓库，在新项目内建立独立仓库，不初始化工作区根目录。Swift package tools 版本为 5.9，库 target 名称为 `FrameGuideCore`，测试使用 XCTest。先写坐标与稳定状态测试，例如：

```swift
func testVisionOriginAndSelfieMirror() {
    let rect = NormalizedRect(x: 0.1, y: 0.2, width: 0.3, height: 0.4)
    let upright = PreviewGeometry.fromVision(rect)
    XCTAssertEqual(upright.y, 0.4, accuracy: 0.0001)
    XCTAssertEqual(PreviewGeometry.mirror(upright).x, 0.6, accuracy: 0.0001)
}

func testReadyRequiresStableHold() {
    var engine = CompositionEngine()
    let subject = SubjectCandidate(id: "person", kind: .person,
        bounds: NormalizedRect(x: 0.35, y: 0.2, width: 0.3, height: 0.6), confidence: 0.9)
    let preferences = GuidancePreferences(scene: .portrait, placement: .center)
    let first = engine.update(snapshot: AnalysisSnapshot(timestamp: 1, subjects: [subject],
        horizonRadians: nil), rollRadians: 0, preferences: preferences)
    XCTAssertEqual(first.phase, .steady)
    let later = engine.update(snapshot: AnalysisSnapshot(timestamp: 1.7, subjects: [subject],
        horizonRadians: nil), rollRadians: 0, preferences: preferences)
    XCTAssertEqual(later.phase, .ready)
    XCTAssertEqual(engine.expire(at: 2.6)?.phase, .searching)
}
```

增加有含义的用例：宽源图与高源图裁剪、偏差方向正负、人物优先、同目标连续帧保持、点击切换、置信度不足、空检测、配置变化和过期计时。不要用仅检查属性存在的测试充数。

- [ ] **Step 2: 在 Swift 可用环境运行失败测试。** 命令 `swift test --package-path Core`。如果当前 Windows 没有 Swift，准确记录无法运行；不要用 Python 重写算法并将其当作 Swift 测试通过。
- [ ] **Step 3: 实现核心策略。** 候选置信度阈值 0.45，过滤视野外及零面积框。人像优先人物/人脸；风景优先显著区域；自动优先人物。使用上一主体 IoU 保持目标，再按置信度和面积选择；人工点选优先。智能横向目标在 `1/3, 1/2, 2/3` 中选择移动代价较小且有留白的一项，纵向目标为 0.5，单次引导锁定目标。位置容差为画面宽/高的 0.06，水平容差为 3 度，靠边阈值为 0.025。就绪保持 0.6 秒、丢失清除 0.8 秒；时间必须使用单调时间源。`reset()` 清除主体、目标和所有计时。
- [ ] **Step 4: 再运行核心测试并审查边界。** 核心不导入 UIKit、AVFoundation、Vision 或 CoreGraphics；只有 `Double` 几何与确定性状态。检查失去主体后不会继续返回就绪、配置变化不会沿用上一次稳定时间。
- [ ] **Step 5: 提交核心与设计。** 命令 `git add Core docs/design.md`，`git commit -m "feat: add local composition geometry and guidance engine"`。如沙箱限制 Git 写入，保留文件并记录限制，不改写其他仓库。

## Task 2: 原生相机采集与工程

**Files:** `FrameGuide.xcodeproj`、`FrameGuide/App/FrameGuideApp.swift`、`FrameGuide/Camera/CameraTypes.swift`、`CameraSession.swift`、`CameraPreview.swift`、`FrameGuide/Resources/Info.plist`。

**Interfaces:** 消费 Task 1 的坐标类型；产出如下 Camera API。`CameraSession` 是 `NSObject`，内部持有串行 session 队列和视频帧回调队列。所有回调的线程约定写入源码注释，UI 接收端显式切换主线程。

```swift
enum FlashSetting: String, CaseIterable { case off, auto, on }
enum CameraState: Equatable {
    case idle, configuring, running, interrupted, denied
    case unavailable(String)
}

final class CameraSession: NSObject {
    let captureSession = AVCaptureSession()
    var onState: ((CameraState) -> Void)?
    var onFrame: ((CVPixelBuffer, CGSize, CGImagePropertyOrientation, Double) -> Void)?
    var onPhoto: ((Result<Data, Error>) -> Void)?
    var onPositionChanged: ((Bool) -> Void)?
}
```

为此类实现 `start()`、`stop()`、`switchCamera()`、`capture(flash: FlashSetting)`、`focus(at: CGPoint)`。`CameraPreview: UIViewRepresentable` 使用 `AVCaptureVideoPreviewLayer`，输入 `session: AVCaptureSession`、`isFrontCamera: Bool`、`onTap: (NormalizedPoint, CGPoint) -> Void`；回调同时提供界面归一化点和 layer 转换后的对焦设备点。

- [ ] **Step 1: 写最小可编译 App 与共享 scheme。** Xcode target 名称 `FrameGuide`，bundle ID `app.frameguide.personal`，Swift 5 模式，`IPHONEOS_DEPLOYMENT_TARGET=17.0`，设备族仅 iPhone，自动生成签名关闭与否由构建参数决定。App 入口先显示相机预览与启动状态，编译目标包括 Core 三个源文件。Info.plist 包含中文相机、相册仅添加用途说明、竖屏方向和显示名“取景”。
- [ ] **Step 2: 实现授权和会话配置。** 首次拍摄前通过 `AVCaptureDevice.requestAccess(for: .video)` 获取权限；拒绝发出 `.denied`。在 session 队列用 `beginConfiguration/commitConfiguration` 配置后置广角输入、照片输出和视频数据输出，使用 `.photo` preset。任何输入/输出不可添加时发出明确错误，禁止强制解包相机设备。
- [ ] **Step 3: 接入原生照片与前后相机切换。** 每次快门创建新 settings：

```swift
let settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
if photoOutput.supportedFlashModes.contains(NSNumber(value: requestedMode.rawValue)) {
    settings.flashMode = requestedMode
}
photoOutput.capturePhoto(with: settings, delegate: self)
```

`photoOutput` 是类持有的 `AVCapturePhotoOutput`；`requestedMode` 是从 `FlashSetting` 映射的 `AVCaptureDevice.FlashMode`。拍摄处理通过 `AVCapturePhotoCaptureDelegate` 获取 `fileDataRepresentation()`；捕获中拒绝重复请求，最终完成回调无论成功失败都复位。切换失败恢复旧输入，不留下无输入会话；前置设备无闪光灯时禁用对应控件。视频缓冲采用已明确的竖向方向，镜像只在预览/照片输出适当层应用一次。

- [ ] **Step 4: 验证工程与采集限制。** macOS 命令 `xcodebuild -project FrameGuide.xcodeproj -scheme FrameGuide -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' CODE_SIGNING_ALLOWED=NO build`。Windows 仅验证工程引用和 plist；不把没有相机的模拟器视为相机通过。会话启停必须离开主线程，切后台停止输出。
- [ ] **Step 5: 提交。** `git add FrameGuide.xcodeproj FrameGuide/App FrameGuide/Camera FrameGuide/Resources/Info.plist`，`git commit -m "feat: add native camera capture and Xcode project"`。

## Task 3: Vision 分析与水平仪

**Files:** `FrameGuide/Camera/VisionAnalyzer.swift`、`MotionService.swift`。

**Interfaces:** 消费 `AnalysisSnapshot`、`SubjectCandidate` 与 Task 2 帧回调，产出：

```swift
final class VisionAnalyzer {
    var onAnalysis: ((AnalysisSnapshot, Double) -> Void)?
    var onFailure: ((String) -> Void)?
    func submit(pixelBuffer: CVPixelBuffer, size: CGSize,
                orientation: CGImagePropertyOrientation, timestamp: Double)
    func reset()
}
final class MotionService {
    func start(onRoll: @escaping (Double?) -> Void)
    func stop()
}
```

`onAnalysis` 第二个参数为方向归一化后的源图宽高比；输出检测框统一为竖向、左上角原点、未镜像坐标。`reset` 的代次标识使旧镜头正在完成的分析结果不被新界面采用。

- [ ] **Step 1: 添加 Vision 请求并规范化输出。** 复用请求对象，使用人物矩形、人脸矩形、物体显著性和地平线请求。Vision 处理使用真实帧：

```swift
let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: orientation)
try handler.perform([humanRequest, faceRequest, saliencyRequest, horizonRequest])
```

四个 request 均为分析器的私有属性，类型分别为 `VNDetectHumanRectanglesRequest`、`VNDetectFaceRectanglesRequest`、`VNGenerateObjectnessBasedSaliencyImageRequest`、`VNDetectHorizonRequest`。将 observations 的 CGRect 分量转 Double，用 `PreviewGeometry.fromVision` 统一原点；只有地平线置信度大于等于 0.6 时输出其角度。

- [ ] **Step 2: 加入节流与单任务在途限制。** 最短分析间隔 0.2 秒。使用锁保护在途标记及代次，每次任务在 `defer` 中释放标记；不得在主线程调用 `perform`。没有结果输出空候选而不是沿用旧帧，失败通过 `onFailure` 返回并允许下一帧重试。
- [ ] **Step 3: 实现重力水平仪。** 用 `CMMotionManager` 在独立队列以约 15Hz 更新 deviceMotion。竖屏横滚角取 `atan2(gravity.x, -gravity.y)`；重力在屏幕平面投影长度低于 0.15 时输出 nil。`stop()` 停止更新，硬件不可用也输出 nil；不伪造地平线。
- [ ] **Step 4: 审查和编译。** 检查源图方向只修正一次、前置检测保持未镜像、代次重置可丢弃旧任务、节流没有创建无限队列。运行 Task 2 的模拟器构建命令；真实检测效果留到设备验收。
- [ ] **Step 5: 提交。** `git add FrameGuide/Camera/VisionAnalyzer.swift FrameGuide/Camera/MotionService.swift`，`git commit -m "feat: analyze subjects and horizon on device"`。

## Task 4: 构图相机界面与生命周期整合

**Files:** `FrameGuide/App/Theme.swift`、`FrameGuide/Camera/CameraViewModel.swift`、`CameraScreen.swift`、`GuidanceOverlay.swift`、`CameraSettingsView.swift`；修改 App 入口。

**Interfaces:** `@MainActor final class CameraViewModel: ObservableObject` 负责 UI 状态，公开：

```swift
@Published private(set) var state: CameraState = .idle
@Published private(set) var guidance: GuidanceResult?
@Published private(set) var capturedPhotoData: Data?
@Published private(set) var recentPhotoData: Data?
@Published private(set) var rollRadians: Double?
@Published private(set) var isFrontCamera = false
@Published private(set) var isCapturing = false
@Published var scene: SceneMode = .automatic
@Published var placement: PlacementMode = .smart
@Published var flash: FlashSetting = .off
@Published var showsGrid = true
@Published var guidanceEnabled = false
@Published var hapticsEnabled = true
```

再公开 `captureSession: AVCaptureSession` 和方法 `start()`、`stop()`、`switchCamera()`、`capture()`、`selectSubject(at: NormalizedPoint, focusPoint: CGPoint)`、`clearCapturedPhoto()`。构图引擎仅由主线程的 ViewModel 修改。`clearCapturedPhoto` 只关闭当前展示，保留 `recentPhotoData` 供缩略图重新打开。首版设置在本次会话内保留，不使用 UserDefaults；所有分析和 watchdog 时间来自同一 `CACurrentMediaTime()` 单调时钟。

- [ ] **Step 1: 连接服务、统一坐标和状态。** CameraSession 的回调通过 `Task { @MainActor in ... }` 更新 UI；Vision 输出先 aspect-fill 映射到取景区域，再按前置预览镜像，最后交给核心。在 0.2 秒 watchdog 中调用 `engine.expire(at:)`，不是仅在有检测回调时清理旧主体。场景、构图位置、镜头、辅助开关改变均复位引擎；退出相机或切后台取消 watchdog 和 motion 更新。
- [ ] **Step 2: 实现取景覆盖层。** `GuidanceOverlay` 输入 `result: GuidanceResult?`、`showsGrid: Bool`、`rollRadians: Double?`。通过 `GeometryReader` 将规范化框投影为 pt，绘制三分线、主体圆角框、目标点和水平仪。颜色变化同时搭配状态文字；辅助线不进入 CameraSession 照片回调。
- [ ] **Step 3: 构建完整相机屏幕。** 顶栏显示名称、闪光灯、辅助线、设置，取景区比例 3:4，底部显示模式、提示、构图开关、快门、最近照片与镜头切换。权限被拒绝显示说明和 `UIApplication.openSettingsURLString`；无设备显示“当前设备无法使用相机”，不用静态图片冒充实时画面。支持 VoiceOver、44pt 点击区域与减弱动态效果。相机就绪才允许拍摄，相机本身可用时 Vision 失败不禁用快门。
- [ ] **Step 4: 接入场景生命周期与提示反馈。**

```swift
.onChange(of: scenePhase) { _, phase in
    if phase == .active { model.start() } else { model.stop() }
}
```

相机服务监听 session 中断/恢复与运行时错误，通知 ViewModel 复位引导。就绪反馈只在从非 ready 进入 ready 时触发一次，重新离开 ready 后才能再次触发。

- [ ] **Step 5: 编译、检查交互并提交。** 使用模拟器构建；检查小屏、动态字体、权限状态及横竖屏配置。`git add FrameGuide/App FrameGuide/Camera`，`git commit -m "feat: add guided camera interface and session recovery"`。

## Task 5: 照片处理、保存与分享

**Files:** 六个 `FrameGuide/Photo/*.swift` 文件；连接 `CameraScreen.swift` 的照片展示。

**Interfaces:**

```swift
enum PhotoFilter: String, CaseIterable, Identifiable, Sendable {
    case original, warm, clear, monochrome
    var id: String { rawValue }
}
actor PhotoProcessor {
    func render(data: Data, filter: PhotoFilter, maxPixelDimension: Int?) throws -> Data
}
enum PhotoLibrary {
    static func saveJPEG(_ data: Data) async throws
}
```

`@MainActor final class PhotoReviewViewModel: ObservableObject` 用 `init(originalData: Data)` 初始化，产出 `selectedFilter: PhotoFilter`、`previewImage: UIImage?`、`exportData: Data?`、`isProcessing: Bool`、`isSaving: Bool`、`message: String?`，以及 `select(_:)`、`save()`。`ShareSheet: UIViewControllerRepresentable` 包装 `UIActivityViewController`，接收 `[Any]`。

- [ ] **Step 1: 实现照片方向归一化与滤镜。** 从原始 JPEG 解码 `CIImage` 并应用 EXIF 方向，仅输出正确方向一次。暖调用 `CITemperatureAndTint`，清透用 `CIColorControls` 的 saturation 0.95、contrast 1.08、brightness 0.02，黑白用 `CIPhotoEffectMono`。所有效果都从 `originalData` 重新计算，预览最长边 1600px，导出不主动放大。使用同一个 actor 内 CIContext，JPEG quality 为 0.94；源图无法解码、滤镜无输出或编码失败均抛出明确错误。
- [ ] **Step 2: 防止滤镜切换竞态。** 每次选择生成递增请求代次，最新代次才可以写回预览/导出结果；处理中禁用保存和分享，旧任务完成不能覆盖新选择。保留原片直到退出预览。`PhotoReviewScreen` 显示原片、暖调、清透、黑白，使用中文名称，不出现技术字段。
- [ ] **Step 3: 实现相册仅添加。**

```swift
let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
guard status == .authorized else { throw PhotoSaveError.permissionDenied }
try await PHPhotoLibrary.shared().performChanges {
    PHAssetCreationRequest.forAsset().addResource(with: .photo, data: data, options: nil)
}
```

定义 `PhotoSaveError: LocalizedError` 并提供中文说明。只有保存请求成功返回才显示“已保存到相册”；拒绝后继续允许系统分享，保存中的重复点击被忽略。

- [ ] **Step 4: 连接照片预览和分享。** CameraViewModel 收到真实照片数据后展示 `PhotoReviewScreen(originalData:onDismiss:)`。分享把当前 `exportData` 写为应用临时目录中的 `.jpg`，系统分享面板接收文件 URL；关闭后清理过期临时分享文件。最近照片使用本次会话保存的原片重新打开，不请求相册读取权限。
- [ ] **Step 5: 构建并提交。** 检查所有失败路径会解除 busy 状态；模拟器构建通过后，真机验证照片方向、滤镜效果、保存和分享。`git add FrameGuide/Photo FrameGuide/Camera/CameraScreen.swift`，`git commit -m "feat: process photos and add save and share flows"`。

## Task 6: 原创资源、隐私清单与静态验证

**Files:** `FrameGuide/Resources/Assets.xcassets`、`PrivacyInfo.xcprivacy`、`scripts/validate_project.py`、`.gitignore`。

**Interfaces:** 验证脚本只读检查项目，成功退出 0，失败退出非 0，并输出明确错误项目；不运行 App，不上传源码或图片。

- [ ] **Step 1: 生成原创图标与完整资产目录。** 用本地绘图生成深色底、青绿色取景角框的 1024x1024 PNG，创建 AppIcon catalog；不从 Doka 提取图片。Info.plist 用系统启动背景颜色，避免依赖缺失的 storyboard。
- [ ] **Step 2: 添加准确的隐私声明。** 首版设置只在会话内保留，不使用 UserDefaults，不读取设备开机时间或文件时间戳。首版本地隐私清单示例如下。当前隐私清单以文首扩展和工程文件为准。相机用途和相册仅添加用途均为中文，首版没有麦克风/定位权限字段。保存分享文件只清理本次创建的明确 URL，不通过时间戳遍历设备文件。

```xml
<dict>
  <key>NSPrivacyTracking</key><false/>
  <key>NSPrivacyTrackingDomains</key><array/>
  <key>NSPrivacyCollectedDataTypes</key><array/>
  <key>NSPrivacyAccessedAPITypes</key><array/>
</dict>
```
- [ ] **Step 3: 实现结构检查。** Python 标准库解析 Info.plist、隐私 plist、资源 JSON 和共享 scheme XML；检查每个 Swift 文件有 Xcode source reference、所有相对路径存在、Core 文件没有重复链接，以及没有 `.ipa`、`.dylib` 或 Doka 私有域名混入。示例脚本入口行为：

```python
def main():
    errors = validate(Path(__file__).resolve().parents[1])
    for error in errors:
        print(error)
    return 1 if errors else 0

if __name__ == "__main__":
    raise SystemExit(main())
```

实现 `validate(root: Path) -> list[str]` 的全部检查；`.gitignore` 忽略 DerivedData、build、个人 Xcode 状态、证书和签名材料，保留共享 scheme 与原创图标。

- [ ] **Step 4: 运行静态检查。** `python scripts/validate_project.py`，预期退出 0。使用当前环境可用的完整 Python 路径；检查只证明结构完整，不计入 Swift 编译或相机测试。
- [ ] **Step 5: 提交。** `git add FrameGuide/Resources scripts/validate_project.py .gitignore`，`git commit -m "chore: add original assets privacy manifest and structure checks"`。

## Task 7: macOS 构建配置和源码交付

**Files:** `.github/workflows/ios.yml`、`scripts/package_source.ps1`、`README.md`、`docs/device-checklist.md`、`docs/validation.md`。

**Interfaces:** 工作流只授予 `contents: read`；手动运行及代码推送触发，不上传 Apple 凭据。输出构建日志和命名明确的未签名设备产物。

- [ ] **Step 1: 添加 macOS CI。** 使用 `runs-on: macos-15`、`actions/checkout@v7`（`persist-credentials: false`）和 `actions/upload-artifact@v7`。这些版本及 Xcode 16.4 路径已在 2026-11-16 查阅 GitHub 官方仓库核对。先选择 Xcode 并记录版本，再依次执行下列真实命令；任一失败立即停止设备打包：

```bash
sudo xcode-select -s /Applications/Xcode_16.4.app/Contents/Developer
xcodebuild -version
swift test --package-path Core
python3 scripts/validate_project.py
xcodebuild -project FrameGuide.xcodeproj -scheme FrameGuide -configuration Debug -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' -derivedDataPath build/simulator CODE_SIGNING_ALLOWED=NO build
xcodebuild -project FrameGuide.xcodeproj -scheme FrameGuide -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/device CODE_SIGNING_ALLOWED=NO build
mkdir -p build/package/Payload
cp -R build/device/Build/Products/Release-iphoneos/FrameGuide.app build/package/Payload/
cd build/package
zip -qr ../FrameGuide-UNSIGNED.ipa Payload
```

设备产物 `FrameGuide-UNSIGNED.ipa` 的 artifact 描述必须注明未签名，不能把生成 ZIP 等同于已通过安装验证。禁止以关闭失败检查的方式让 workflow 变绿。

- [ ] **Step 2: 写中文运行与安装说明。** README 写明 iOS 17+、无服务端配置、功能入口、Windows 的真实能力边界、如何在 macOS Xcode 选择自己的 Team 和 Bundle ID。说明需要用户自己的有效签名；只有在用户选择构建仓库后才发布或触发远端构建。解释未签名包、开发签名和 App Store 分发之间的差别，不承诺永不过期。
- [ ] **Step 3: 写设备验收清单和结果记录。** 清单覆盖设计第 10 节七类真机行为，以及相机中断、权限拒绝、前后镜像、照片分辨率和多次拍照。`docs/validation.md` 分别记录静态检查、核心测试、Apple 平台构建、模拟器和真机；没有执行的项目明确写“未执行”，不留模糊占位。
- [ ] **Step 4: 打包源码并验证。** PowerShell 使用 `Compress-Archive -LiteralPath` 打包明确枚举的源码/工程/文档目录；排除 `.git`、build、缓存与所有个人签名材料。对压缩包读取目录并验证必需文件存在、原始 IPA 未混入；运行静态检查，已取得 macOS 构建环境时执行真实构建并处理失败。
- [ ] **Step 5: 提交与交付。** `git add .github scripts/package_source.ps1 README.md docs`，`git commit -m "ci: add macOS builds and native app delivery guide"`。提供源码 ZIP 和 README 的绝对路径链接；报告实际通过的检查。若缺少可用 macOS 构建仓库或设备签名，把完成的工程交付给用户审阅，再请求这一步所必需的外部信息，不伪造构建结果。

## Dependency Order and Execution Method

顺序为 Task 1 → 2 → 3 → 4 → 5 → 6 → 7。Task 4 和 Task 5 的实现可以独立审查，但合并后仍需重新检查照片展示、生命周期及分享流程。

计划采用一个项目和一套共享接口，不拆成互相独立的产品。执行方式由用户在“本聊天顺序实现”与“分任务子代理实现”之间选择；未选择前不启动代理或写产品源码。

## Self-Review

- [x] 设计第 1–3 节：Task 1、2、7 覆盖自用、本地、原生和 Windows/macOS 交付路径。
- [x] 设计第 4–5 节：Task 2、4、5 覆盖拍摄流程、主屏、设置、照片预览和可访问性。
- [x] 设计第 6 节：Task 1、3、4 覆盖主体、目标、稳定时间、失去主体和性能边界。
- [x] 设计第 7 节：Task 2、5 覆盖原生照片、方向、滤镜、相册和分享。
- [x] 设计第 8–9 节：Task 2–5 覆盖模块接口、线程、生命周期、权限和错误恢复。
- [x] 设计第 10 节：Task 1、6、7 覆盖真实核心测试、结构检查、CI 与真机清单。
- [x] 接口统一：核心 `Double` 坐标、帧方向、源图比例、UI 主线程、照片 Data 和模块方法名称一致。
- [x] 计划无未说明的产品范围；构建与安装限制、未执行检查的报告方式明确。
