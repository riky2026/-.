# 验证记录

记录日期：2026-11-16。本文件区分已获得的证据和未执行的项目；源码交付或 ZIP/IPA 生成本身不是设备运行验证。

首次真实 CI：[run 43866474402](https://github.com/riky2026/-./actions/runs/43866474402)。runner 为 macOS 15.8.2 arm64，Xcode 16.4 (16F6)，Apple Swift 6.1.2；日志记录的源码 ZIP SHA-256 为 `e46f51ca1a9ce3cad78d910afdd3a53fb7f2a4c2a7a945dad6642a01693c51ef`。SwiftPM 及结构检查通过，模拟器目标编译失败。设备构建与打包按失败检查正确跳过，失败日志已保留。

第二次真实 CI：[run 43868115917](https://github.com/riky2026/-./actions/runs/43868115917)，远端提交 `b3798cf56f531ae29c08823767d044bcc6c63074`，相同 Xcode 16.4 工具链。实际源码 ZIP SHA-256 为 `84a2dd12f421504f756514af02efeda49c0208037c0d166f598f584ba58de6cd`，包含本地修复提交 `af656ce7236a715ab6c98252572ce567ae65374f` 的产品源码。所有步骤成功：SwiftPM 27/27、结构检查、模拟器 Debug 编译、设备 Release 无签名编译、IPA 打包及产物上传。本次交付随后仅更新 README 和此验证文档；构建证据对应上述经 CI 校验的源码包。

| 层级 | 实际结果 | 边界 |
| --- | --- | --- |
| Windows 静态结构检查 | `python scripts/validate_project.py` 通过；Task 6 结构检查的 20 个负例及只读检查通过 | 只解析项目、资源、声明和源码，不调用 Swift 编译器或 Apple SDK |
| Windows Swift 语法检查 | 前序任务已完成 Swift grammar 检查 | 不是 Apple SDK 类型检查、链接或运行 |
| Core 逻辑测试 | Core 源码与测试生成的独立 harness 在公共 Compiler Explorer 的 Swift 6.1/Linux 编译执行，最新 27/27 通过（含 Task 4 回归修复） | 不是 `swift test`/SwiftPM，不涉及 SwiftUI、AVFoundation、Vision 或 iOS SDK |
| 本次 Windows 源码交付 | `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/package_source.ps1` 生成并校验源码 ZIP；解压后静态结构检查通过 | 包结构/完整性验证，不能替代编译；SHA-256 见交付报告及构建日志 |
| macOS Core SwiftPM | **通过：27/27，0 failures** | 两次 CI 均实际执行 `swift test --package-path Core`；不覆盖相机行为 |
| Apple SDK / Xcode / actool | **第二次 CI 通过，有警告** | Xcode 16.4 下两种目标均构建成功，警告见下文；未验证运行时显示或相机能力 |
| iOS 模拟器目标编译 | **第二次 CI 通过** | 首次因 NSNumber 与 AVCaptureDevice.FlashMode 类型不匹配失败；改用 requestedMode 后真实编译通过，无模拟器启动 |
| iOS 模拟器运行 | **未执行** | 工作流不启动模拟器；需另行启动、操作并记录 |
| iPhone 设备 Release 编译与未签名 IPA | **第二次 CI 通过，产物已下载检查** | 无签名 Release 编译、打包和上传成功；归档/配置检查不等于安装或真机验收 |
| 个人签名、安装及真机行为 | **未执行** | 用户 iOS 26、机型未知；需有效签名，按 `device-checklist.md` 实测 |

## 产物检查与构建警告

[未签名设备 artifact 14226059197](https://github.com/riky2026/-./actions/runs/43868115917/artifacts/14226059197) 和 [日志 artifact 14226204031](https://github.com/riky2026/-./actions/runs/43868115917/artifacts/14226204031) 已上传。下载外层 artifact ZIP 后，提取的 `FrameGuide-UNSIGNED.ipa` 为 296100 字节，SHA-256 `c54353b7bd11025e30b11a6f9c924f5c5f85235ea21ff31a43d16654638cbfb2`。检查确认 arm64 Mach-O，Bundle ID `app.frameguide.personal`，MinimumOSVersion 17.0，iPhoneOS/竖屏配置，相机和相册仅添加用途说明、隐私清单及资产存在；没有 `_CodeSignature` 或嵌入描述文件。结论仅为归档、二进制与配置检查通过，尚未签名安装或操作相机。

两种构建都保留以下警告，未为了消除警告而修改资源或构建设置：

- `LaunchBackground` 的 systemBackgroundColor 使用 Universal 平台声明，而目录正在为 iOS 构建；Xcode 提示运行时颜色可能不同。启动背景颜色仍需真机检查。
- AppIntents 元数据提取跳过，原因为没有 AppIntents.framework 依赖。本应用未引入该框架；这是构建工具的元数据步骤提示，整体编译与打包已成功。

## 可复现命令

Windows 在工程根目录：

```powershell
python scripts/validate_project.py
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/package_source.ps1
```

macOS 在工程根目录（完整 checkout 或安全解压后的源码根目录）：

```bash
sudo xcode-select -s /Applications/Xcode_16.4.app/Contents/Developer
xcodebuild -version
swift test --package-path Core
python3 scripts/validate_project.py
xcodebuild -project FrameGuide.xcodeproj -scheme FrameGuide -configuration Debug -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' -derivedDataPath build/simulator CODE_SIGNING_ALLOWED=NO build
xcodebuild -project FrameGuide.xcodeproj -scheme FrameGuide -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/device CODE_SIGNING_ALLOWED=NO build
mkdir -p build/package/Payload
cp -R build/device/Build/Products/Release-iphoneos/FrameGuide.app build/package/Payload/
cd build/package
zip -qr ../FrameGuide-UNSIGNED.ipa Payload
```

CI 的每步均启用 `set -euo pipefail`，测试或编译失败即停止后续打包；日志 artifact 使用 `always()` 保存失败证据。未签名 artifact 的名称与说明明确要求用户自己的签名。工作流只有 `contents: read`，不收集签名、不推送仓库、不掩盖失败。源码包模式在解压前记录 ZIP SHA-256；完整源码模式记录 checkout commit。

## 尚存验证工作

真实 macOS CI 已确认工具链、Core SwiftPM、结构检查、Apple SDK/资源编译、模拟器与设备目标构建、未签名打包和上传。仍需实际启动并操作模拟器，再使用自己的有效签名在目标 iPhone 安装并逐项执行设备清单，包括启动颜色、方向/镜像、像素尺寸、权限、保存/分享、生命周期和离线行为。运行验收尚未完成，不能据编译和归档检查宣称 iOS 26 兼容或可正常安装运行。
