# 验证记录

记录日期：2026-11-16。本文件区分已获得的证据和未执行的项目；源码交付或 ZIP/IPA 生成本身不是设备运行验证。远端 CI 执行后应追加实际运行链接、提交与日志结论，不能预填成功。

| 层级 | 实际结果 | 边界 |
| --- | --- | --- |
| Windows 静态结构检查 | `python scripts/validate_project.py` 通过；Task 6 结构检查的 20 个负例及只读检查通过 | 只解析项目、资源、声明和源码，不调用 Swift 编译器或 Apple SDK |
| Windows Swift 语法检查 | 前序任务已完成 Swift grammar 检查 | 不是 Apple SDK 类型检查、链接或运行 |
| Core 逻辑测试 | Core 源码与测试生成的独立 harness 在公共 Compiler Explorer 的 Swift 6.1/Linux 编译执行，最新 27/27 通过（含 Task 4 回归修复） | 不是 `swift test`/SwiftPM，不涉及 SwiftUI、AVFoundation、Vision 或 iOS SDK |
| 本次 Windows 源码交付 | `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/package_source.ps1` 生成并校验源码 ZIP；解压后静态结构检查通过 | 包结构/完整性验证，不能替代编译；SHA-256 见交付报告及构建日志 |
| macOS Core SwiftPM | **未执行** | 待 CI 执行 `swift test --package-path Core` |
| Apple SDK / Xcode / actool | **未执行** | Xcode 16.4/macOS runner 配置已提供，需真实 CI 通过才能确认 |
| iOS 模拟器目标编译 | **未执行** | CI 设置 Debug 无签名编译，编译成功也不代表启动过模拟器 |
| iOS 模拟器运行 | **未执行** | 工作流不启动模拟器；需另行启动、操作并记录 |
| iPhone 设备 Release 编译与未签名 IPA | **未执行** | 工作流设置无签名编译；不能直接安装到正常 iPhone |
| 个人签名、安装及真机行为 | **未执行** | 用户 iOS 26、机型未知；需有效签名，按 `device-checklist.md` 实测 |

## 可复现命令

Windows 在工程根目录：

```powershell
python scripts/validate_project.py
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/package_source.ps1
```

macOS 在工程根目录（完整 checkout 或安全解压后的源码根目录）：

```bash
sudo xcode-select -s /Applications/Xcode_16.4.app/Contents/Developer
xcodebuild -version
swift test --package-path Core
python3 scripts/validate_project.py
xcodebuild -project FrameGuide.xcodeproj -scheme FrameGuide -configuration Debug -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' -derivedDataPath build/simulator CODE_SIGNING_ALLOWED=NO build
xcodebuild -project FrameGuide.xcodeproj -scheme FrameGuide -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/device CODE_SIGNING_ALLOWED=NO build
mkdir -p build/package/Payload
cp -R build/device/Build/Products/Release-iphoneos/FrameGuide.app build/package/Payload/
cd build/package
zip -qr ../FrameGuide-UNSIGNED.ipa Payload
```

CI 的每步均启用 `set -euo pipefail`，测试或编译失败即停止后续打包；日志 artifact 使用 `always()` 保存失败证据。未签名 artifact 的名称与说明明确要求用户自己的签名。工作流只有 `contents: read`，不收集签名、不推送仓库、不掩盖失败。源码包模式在解压前记录 ZIP SHA-256；完整源码模式记录 checkout commit。

## 尚存验证工作

需实际 macOS CI 确认工具链、SwiftPM、Apple API 类型检查、资源编译和两种目标构建；如有错误，保留日志后修复重跑。随后再验证模拟器运行，并使用自己的签名在目标 iPhone 逐项执行设备清单。以上工作尚未完成，不能据当前静态证据宣称 iOS 26 兼容或可正常安装运行。
