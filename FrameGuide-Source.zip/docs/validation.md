# 验证记录

记录日期：2026-11-16。本文件区分已获得的证据和未执行的项目；源码交付或 ZIP/IPA 生成本身不是设备运行验证。

首次真实 CI：[run 43866474402](https://github.com/riky2026/-./actions/runs/43866474402)。runner 为 macOS 15.8.2 arm64，Xcode 16.4 (16F6)，Apple Swift 6.1.2；日志记录的源码 ZIP SHA-256 为 `e46f51ca1a9ce3cad78d910afdd3a53fb7f2a4c2a7a945dad6642a01693c51ef`。SwiftPM 及结构检查通过，模拟器目标编译失败。设备构建与打包按失败检查正确跳过，失败日志已保留。

| 层级 | 实际结果 | 边界 |
| --- | --- | --- |
| Windows 静态结构检查 | `python scripts/validate_project.py` 通过；Task 6 结构检查的 20 个负例及只读检查通过 | 只解析项目、资源、声明和源码，不调用 Swift 编译器或 Apple SDK |
| Windows Swift 语法检查 | 前序任务已完成 Swift grammar 检查 | 不是 Apple SDK 类型检查、链接或运行 |
| Core 逻辑测试 | Core 源码与测试生成的独立 harness 在公共 Compiler Explorer 的 Swift 6.1/Linux 编译执行，最新 27/27 通过（含 Task 4 回归修复） | 不是 `swift test`/SwiftPM，不涉及 SwiftUI、AVFoundation、Vision 或 iOS SDK |
| 本次 Windows 源码交付 | `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/package_source.ps1` 生成并校验源码 ZIP；解压后静态结构检查通过 | 包结构/完整性验证，不能替代编译；SHA-256 见交付报告及构建日志 |
| macOS Core SwiftPM | **通过：27/27，0 failures** | 首次 CI 实际执行 `swift test --package-path Core`；不覆盖 iOS API 或相机行为 |
| Apple SDK / Xcode / actool | **已执行构建流程，整体失败** | Xcode 16.4 已选定；SDK 类型检查发现闪光灯模式错误，资源与工程整体成功仍待修复重跑确认 |
| iOS 模拟器目标编译 | **失败；已修复诊断处，待重跑** | `CameraSession.swift:233:62` 把 NSNumber 传给期望 AVCaptureDevice.FlashMode 的 contains；改为直接比较 requestedMode，仍需真实 Xcode 验证 |
| iOS 模拟器运行 | **未执行** | 工作流不启动模拟器；需另行启动、操作并记录 |
| iPhone 设备 Release 编译与未签名 IPA | **未执行（前序编译失败后跳过）** | 工作流设置无签名编译；不能直接安装到正常 iPhone |
| 个人签名、安装及真机行为 | **未执行** | 用户 iOS 26、机型未知；需有效签名，按 `device-checklist.md` 实测 |

## 可复现命令

Windows 在工程根目录：

```powershell
python scripts/validate_project.py
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/package_source.ps1
```

macOS 在工程根目录（完整 checkout 或安全解压后的源码根目录）：

```bash
sudo xcode-select -s /Applications/Xcode_16.4.app/Contents/Developer
xcodebuild -version
swift test --package-path Core
python3 scripts/validate_project.py
xcodebuild -project FrameGuide.xcodeproj -scheme FrameGuide -configuration Debug -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' -derivedDataPath build/simulator CODE_SIGNING_ALLOWED=NO build
xcodebuild -project FrameGuide.xcodeproj -scheme FrameGuide -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/device CODE_SIGNING_ALLOWED=NO build
mkdir -p build/package/Payload
cp -R build/device/Build/Products/Release-iphoneos/FrameGuide.app build/package/Payload/
cd build/package
zip -qr ../FrameGuide-UNSIGNED.ipa Payload
```

CI 的每步均启用 `set -euo pipefail`，测试或编译失败即停止后续打包；日志 artifact 使用 `always()` 保存失败证据。未签名 artifact 的名称与说明明确要求用户自己的签名。工作流只有 `contents: read`，不收集签名、不推送仓库、不掩盖失败。源码包模式在解压前记录 ZIP SHA-256；完整源码模式记录 checkout commit。

## 尚存验证工作

真实 macOS CI 已确认工具链、Core SwiftPM 和结构检查。需以修复后的源码包重跑，确认 Apple API 类型检查、资源编译、模拟器目标及设备目标构建与未签名打包；如有错误，继续保留日志并修复。随后再验证模拟器运行，并使用自己的签名在目标 iPhone 逐项执行设备清单。完整原生构建及运行验收尚未完成，不能据当前证据宣称 iOS 26 兼容或可正常安装运行。
