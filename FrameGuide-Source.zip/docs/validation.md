# 验证记录

记录更新于 2026-11-21。

## 取景准星引导改进（Build 3）

智能构图入口合并为一个开关，启动本地引导后，已配置的 DeepSeek 会自动分析当前预览。默认方案直接生效，取景中可一键切换下一方案。预览增加中央准星、彩色目标圆环及连接线，方向文案转换为镜头操作，包含前置镜像映射。稳定进度由真实检测时间更新，主体丢失即隐藏瞄准提示。轻微倾斜先引导主体位置，明显倾斜优先提示水平，构图就绪仍要求水平达标。回归检查覆盖方向映射、圆环收敛、稳定计时与丢失重置。

Windows 工程结构检查通过。本轮 macOS 编译与回归结论以新构建为准。真机触觉、取景布局及转动手机时的实际反馈仍需 iPhone 15 / iOS 18.7 验证。圆环为预览坐标内的方向提示。

## 主体锁定与手持稳定提醒（Build 4）

在 Build 3 的实时准星上增加长按主体锁定、再次长按解锁、锁定状态标记、检测漏失后的短时重捕，以及基于 Core Motion 陀螺仪角速度的抖动提醒。主体匹配结合框重叠和中心距离；抖动提醒会暂停就绪计时。Core 回归用例覆盖锁定主体优先级、漏检恢复、解锁及抖动对就绪状态的影响。

[GitHub Actions 运行 44860751038](https://github.com/riky2026/-./actions/runs/44860751038) 全部通过：Core 45/45、原生照片 fixture、AI 离线 fixture、工程静态校验、模拟器 Debug 编译、iPhoneOS Release 编译、未签名 IPA 打包和上传。被测源码包 SHA-256 为 `F9D4933E8A244DA8379001969D5DA137456E34295C02428D0BEA139855C561F4`。外层 artifact SHA-256 为 `CA40A27CC473D2AC8A30455EDB2C6C1E2327C370C311CC1A0D3B31919F6E0541`；内部 IPA 为 462181 字节，SHA-256 为 `C78DD056DDD4FF0E7D093E34C8883C7708FCCC17F02CE5DBD123B7125B34C4AA`。核对 Bundle ID `app.frameguide.personal`、版本 `1.0`、构建号 `4`、最低 iOS `17.0`。签名任务按用户当前的易签方式跳过；IPA 未签名、未安装。

设备运动提醒阈值、相机布局与前后镜头手势仍须 iPhone 15 / iOS 18.7 真机核对。此次未调用真实 DeepSeek API、未启动模拟器交互、未签名安装。

## 当前一键分析与实时引导

Windows 校验覆盖工程结构和源码 ZIP。macOS 离线 fixture 使用合成帧、内存凭据和拦截请求，检查首次同意前零次请求、同意后单次请求、后续一键发起、默认计划选择以及取消与失效。Core 测试和几何 fixture 覆盖居中、三分目标、大小、主体丢失和重新获取以及稳定计时。

当前版本的原生 CI、真实服务调用和真实 iPhone 验收仍待完成。签名安装后按 `device-checklist.md` 验证首次同意后立即发送、默认应用第一套方案、移动及主体重新获取期间请求数保持不变、位置与尺度提示、API 失败时的本地引导，以及相机就绪时快门持续可用。

## 历史 DeepSeek 扩展构建 3

GitHub Actions [运行 `44294336217`](https://github.com/riky2026/-./actions/runs/44294336217) 对提交 `b6b348de6d652b75d7f1fc72666582f249937887` 执行完整原生 CI。工作流记录源码 ZIP SHA-256：`b9c01b0b3675a0f51b63e6a6a1da107b99175f3675f135ba48b25bb9f64a6d00`。Core SwiftPM 30/30、原生 JPEG fixture、AI 离线 fixture、静态工程校验、iOS 模拟器目标编译、iPhoneOS 设备目标编译、未签名 IPA 打包与上传均通过。工作流不会启动模拟器，也没有运行真实 DeepSeek API。

外层 artifact ZIP 摘要为 `3dbb285dbfed55ff1361f768de56d5762393374d8b7c78874c04793b79c94dc1`；内部未签名 IPA 为 455253 字节，SHA-256 为 `5d4b021241413adbc3b13fb607621557347a381ed66cf8d5a821d1c8f17a0f87`。[未签名设备 artifact 14422194063](https://github.com/riky2026/-./actions/runs/44294336217/artifacts/14422194063) · [构建日志 artifact 14421819873](https://github.com/riky2026/-./actions/runs/44294336217/artifacts/14421819873)。IPA 尚未签名安装。

AI fixture 用 URLProtocol 拦截网络、合成 JPEG/像素和内存 Key 替身，直接编译生产类型、客户端、APIKeyStore、快照编解码、提供器和协调器；链接 Foundation、CoreImage、CoreVideo、ImageIO、Combine、Security。它不访问真实 Keychain；生产 SwiftUI 面板和 iOS Keychain 的编译由同一 CI 的两个 iOS build 覆盖，运行行为仍待设备验证。已有拍摄修复和 PhotoFixture 命令完整保留。

CI 在 bundle 模式校验七个 AI 生产源文件与 fixture 必须存在，外层 workflow 与源码内副本必须逐字节一致，并记录两者 SHA-256。新的构建结论绑定实际 run、artifact 和被测源码 ZIP 哈希；不能复用构建 2 绿灯来声明 AI 功能通过。

## 手动签名路径：已编写，待用户配置并执行

现有 `ios.yml` 增加 `signed_ipa` 手动输入，默认 `false`。只有在 `main` 手动选中该选项时，独立签名 job 才读取 `ios-signing` 环境 secrets；普通 push 与 PR 构建不读取签名凭据。该仓库为公开仓库，环境 secrets 可用；建议把环境部署分支限制为 `main`。证书、密码、描述文件不会进入源码 ZIP。签名 workflow 尚未运行，因为用户尚未创建环境并配置材料；构建是否能匹配用户证书及设备、生成 IPA 并安装仍待验证。

输入材料为 Base64 `.p12`、其密码及匹配 `app.frameguide.personal` 的 `.mobileprovision`。CI 验证 profile 有效期、Bundle ID、登记设备列表和 development/ad-hoc 类型；它无法从 CI 确认列表中是否包含用户手上的具体 iPhone，必须由用户在 Apple Developer profile 中选入 iPhone 15 UDID。详细步骤见 `README.md` 的“签名与安装”。

本轮 manifest 采用保守照片/视频 App 功能、linked=true、tracking=false，且不声明新增 required-reason API。未来 App Store 申报需重新核查供应商当时政策和全部数据类型；本文件不是已完成的商店隐私申报。

## 构建 2：iPhone 15 / iOS 18.7 两个镜头无法拍摄

2026-11-17 真机反馈和截图定位到拍摄前的几何校验：它将输出坐标中的取景矩形与最大照片尺寸直接比较。Swift 6.1 Linux 在旧生产初始化代码上重现了同一 3:4 画幅不同采样尺寸的拒绝；这是构造输入，不是设备坐标日志。构建 2 去除这处快门阻断，只在取景 ROI 与同一输出的完整参考矩形、实际照片及方向可对应时裁剪；无法确定时保留整张照片并在预览标明。iPhone 15 / iOS 18.7 前后镜头的拍摄、预览、保存和分享仍待真机复测。

构建 2 的验证运行对应远端提交 `a293ef2311e06fa8ecac00a74c8ad72aff6a1cbc`，被测源码对应本地提交 `526b77d12c85b069196eb5c2978810f85f64ca46`。实测源码 ZIP SHA-256 为 `3c0dff937ca2dd204aab070bf601ae2dd924d1462fee586eb178466bb239a0ad`。随后交付仅更新 README 和本文。[CI 运行 44065811434](https://github.com/riky2026/-./actions/runs/44065811434)

- Apple SwiftPM 30/30 通过。原生 JPEG 像素样图覆盖不同采样尺寸下的取景映射、偏移裁剪、较小原生照片、EXIF 镜像和方向 6/8、保留完整画面、预览、缩略图以及滤镜输出。工程结构检查、模拟器 Debug、iPhoneOS Release、未签名打包和上传全部通过。
- 下载外层 ZIP 的 SHA-256 为 `101ac4b86b4eab582f96f9eac5c4dc12645f03ac25ebd69c302336bf619b988d`，与 GitHub artifact 摘要一致。内部 IPA 为 314064 字节，SHA-256 为 `397d887ebfe32d4c3ca1d040a35f0f71602be9855f5fa13b0a4dcc2e2362e3fd`。归档核验确认构建号 2、arm64、最低系统 17.0、iPhone 竖屏和权限用途声明。IPA 未签名，无嵌入描述文件。[IPA artifact 14320083542](https://github.com/riky2026/-./actions/runs/44065811434/artifacts/14320083542) · [日志 artifact 14320233227](https://github.com/riky2026/-./actions/runs/44065811434/artifacts/14320233227)

## 历史：构建 1 原生验证

[构建 43899558161](https://github.com/riky2026/-./actions/runs/43899558161) 在远端提交 `c680e42ba490f3ee68315d8c260bf501911e70d2` 上测试的源码 ZIP SHA-256 为 `df5625e5ded5c4028ece8880d15ef7271d35dbef5c98b641097cce9ca7c43c23`，对应本地提交 `884200f52f90158548bb45945f5a64bb4ada2011`。构建 1 当时的交付仅在该版本上更新 README 和本文两份说明；源码包哈希不同，应用、测试、资源和构建工作流一致。

- Intel macOS 15.7.9（x86_64）、Xcode 16.4（16F6）、Apple Swift 6.1.2：SwiftPM 30/30，0 失败；工程静态结构检查通过。
- 原生 JPEG 测试直接运行生产 PhotoProcessor。标定画幅为 640×640 而实际交付镜像 320×320 时，按快门范围裁出 240×320；标定为 480×640 而实际交付 240×320 时，完整保留这张 3:4 原片。原始及按 EXIF 解码的四角标记、预览和缩略图、滤镜输出尺寸、不放大、拒绝无效尺寸元数据与不兼容画幅均通过。该测试验证已知对应关系的样图；实际摄像头的取景对应关系待真机检查。
- 模拟器 Debug、iPhoneOS Release 均 BUILD SUCCEEDED，未签名打包和上传成功。LaunchBackground 的 actool 警告已消失；为保持固定竖屏保留 videoOrientation / isVideoOrientationSupported 弃用提示。AppIntents 仍因无框架依赖而跳过元数据提取。
- [未签名设备 artifact 14240743719](https://github.com/riky2026/-./actions/runs/43899558161/artifacts/14240743719) · [日志 artifact 14240687800](https://github.com/riky2026/-./actions/runs/43899558161/artifacts/14240687800)。下载外层 ZIP SHA-256 为 `eaa109ce0f0eb762649b2c3d72b88f84cdb4d47209b6869ccc483cea80dc6650`，与 GitHub 摘要一致。内部 IPA 为 306629 字节，SHA-256 为 `a110ce87538e795424de9e3c0ae72ddc514882eb1bb52fbdc01c1896b788a925`。核对 arm64 Mach-O、最低系统 17.0、iPhoneOS/竖屏、权限用途、隐私清单及资产；没有代码签名或描述文件。
- 未启动模拟器、操作权限界面、签名安装，也未验证 iOS 26 真机相机、前后摄方向与取景范围。

## 历史 CI 记录

此前修复首批问题的[构建 43885558553](https://github.com/riky2026/-./actions/runs/43885558553) 对应源码 ZIP `3669eb6322fc84c8f675e2b60d54eb52e3c54c0a031ae32f76a86f96a54fe34b`、本地提交 `a871e335e2b0dd42670ba89530070f0eb6952f68`，已通过当时的 30 项 Core 测试、原生样图测试及两种目标构建。当时的 IPA 为 305844 字节，SHA-256 为 `e890037fff6b727d97252b53064cc1b67c357b0bc7872f40ae726b1b4cfec2f6`。它未覆盖上限以下的原生 JPEG。该补丁的[首次验证尝试](https://github.com/riky2026/-./actions/runs/43891360271/attempts/1) 因 ARM runner 容量不足未开始执行；文首记录是同一产品源码在 Intel runner 上完成的实际验证。

首次真实 CI：[run 43866474402](https://github.com/riky2026/-./actions/runs/43866474402)。runner 为 macOS 15.8.2 arm64，Xcode 16.4 (16F6)，Apple Swift 6.1.2；日志记录的源码 ZIP SHA-256 为 `e46f51ca1a9ce3cad78d910afdd3a53fb7f2a4c2a7a945dad6642a01693c51ef`。SwiftPM 及结构检查通过，模拟器目标编译失败。设备构建与打包按失败检查正确跳过，失败日志已保留。

第二次真实 CI：[run 43868115917](https://github.com/riky2026/-./actions/runs/43868115917)，远端提交 `b3798cf56f531ae29c08823767d044bcc6c63074`，相同 Xcode 16.4 工具链。实际源码 ZIP SHA-256 为 `84a2dd12f421504f756514af02efeda49c0208037c0d166f598f584ba58de6cd`，包含本地修复提交 `af656ce7236a715ab6c98252572ce567ae65374f` 的产品源码。所有步骤成功：SwiftPM 27/27、结构检查、模拟器 Debug 编译、设备 Release 无签名编译、IPA 打包及产物上传。当时的交付随后仅更新 README 和此验证文档；构建证据对应上述经 CI 校验的源码包。

| 层级 | 实际结果 | 边界 |
| --- | --- | --- |
| Windows 静态结构检查 | `python scripts/validate_project.py` 通过；Task 6 结构检查的 20 个负例及只读检查通过 | 只解析项目、资源、声明和源码，不调用 Swift 编译器或 Apple SDK |
| Windows Swift 语法检查 | 前序任务已完成 Swift grammar 检查 | 不是 Apple SDK 类型检查、链接或运行 |
| Core 逻辑测试 | Core 源码与测试生成的独立 harness 在公共 Compiler Explorer 的 Swift 6.1/Linux 编译执行，最新 27/27 通过（含 Task 4 回归修复） | 不是 `swift test`/SwiftPM，不涉及 SwiftUI、AVFoundation、Vision 或 iOS SDK |
| 本次 Windows 源码交付 | `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/package_source.ps1` 生成并校验源码 ZIP；解压后静态结构检查通过 | 包结构/完整性验证，不能替代编译；SHA-256 见交付报告及构建日志 |
| macOS Core SwiftPM | **通过：27/27，0 failures** | 两次 CI 均实际执行 `swift test --package-path Core`；不覆盖相机行为 |
| Apple SDK / Xcode / actool | **第二次 CI 通过，有警告** | Xcode 16.4 下两种目标均构建成功，警告见下文；未验证运行时显示或相机能力 |
| iOS 模拟器目标编译 | **第二次 CI 通过** | 首次因 NSNumber 与 AVCaptureDevice.FlashMode 类型不匹配失败；改用 requestedMode 后真实编译通过，无模拟器启动 |
| iOS 模拟器运行 | **未执行** | 工作流不启动模拟器；需另行启动、操作并记录 |
| iPhone 设备 Release 编译与未签名 IPA | **第二次 CI 通过，产物已下载检查** | 无签名 Release 编译、打包和上传成功；归档/配置检查不等于安装或真机验收 |
| 个人签名、安装及真机行为 | **未执行** | 当时尚未确认机型和版本；需有效签名，按 `device-checklist.md` 实测 |

## 本轮修复的验证边界

以上表格记录 CI2 及此前结果。新版风景逻辑的真实 Swift 6.1 Linux 合并 harness 为 30/30（改前 9 条断言失败、改后通过），不是 Apple SwiftPM。CI 新增 scripts/PhotoFixture.swift，直接编译生产 PhotoProcessor，检查方形照片排除边条、3:4 原样保留、镜像 EXIF、四角颜色、预览/缩略图/原生导出和尺寸不匹配。首轮修复验证 [CI3](https://github.com/riky2026/-./actions/runs/43883095013) 的 Apple SwiftPM 30/30 通过，原生 JPEG harness 编译成功、首次执行在输出 EXIF 断言处中止（未验证四角像素）；后续 iOS 构建与打包跳过。断言现按显示语义同时核对原始及按 EXIF 解码的四角像素，允许省略默认向上标记，显式非向上标记仍失败。修正后的像素验证、iOS 构建与 actool 警告复核结果见文首最新记录。模拟器交互及 iPhone 真机验收另行记录。

## CI2 产物检查与构建警告

[未签名设备 artifact 14226059197](https://github.com/riky2026/-./actions/runs/43868115917/artifacts/14226059197) 和 [日志 artifact 14226204031](https://github.com/riky2026/-./actions/runs/43868115917/artifacts/14226204031) 已上传。下载外层 artifact ZIP 后，提取的 `FrameGuide-UNSIGNED.ipa` 为 296100 字节，SHA-256 `c54353b7bd11025e30b11a6f9c924f5c5f85235ea21ff31a43d16654638cbfb2`。检查确认 arm64 Mach-O，Bundle ID `app.frameguide.personal`，MinimumOSVersion 17.0，iPhoneOS/竖屏配置，相机和相册仅添加用途说明、隐私清单及资产存在；没有 `_CodeSignature` 或嵌入描述文件。结论仅为归档、二进制与配置检查通过，尚未签名安装或操作相机。

两种构建都保留以下警告，未为了消除警告而修改资源或构建设置：

- `LaunchBackground` 的 systemBackgroundColor 使用 Universal 平台声明，而目录正在为 iOS 构建；Xcode 提示运行时颜色可能不同。启动背景颜色仍需真机检查。
- AppIntents 元数据提取跳过，原因为没有 AppIntents.framework 依赖。本应用未引入该框架；这是构建工具的元数据步骤提示，整体编译与打包已成功。

## 可复现命令

Windows 在工程根目录：

```powershell
python scripts/validate_project.py
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/package_source.ps1
```

macOS 在工程根目录（完整 checkout 或安全解压后的源码根目录）：

```bash
sudo xcode-select -s /Applications/Xcode_16.4.app/Contents/Developer
xcodebuild -version
swift test --package-path Core
fixture="$(mktemp -d)/photo-fixture"
swiftc FrameGuide/Photo/PhotoFilter.swift FrameGuide/Photo/PhotoProcessor.swift scripts/PhotoFixture.swift -o "$fixture"
"$fixture"
swiftc -parse-as-library -swift-version 5 \
  Core/Sources/FrameGuideCore/Geometry.swift \
  Core/Sources/FrameGuideCore/CompositionTypes.swift \
  Core/Sources/FrameGuideCore/CompositionEngine.swift \
  FrameGuide/AIComposition/AICompositionTypes.swift \
  FrameGuide/AIComposition/DeepSeekCompositionClient.swift \
  FrameGuide/AIComposition/APIKeyStore.swift \
  FrameGuide/AIComposition/AIUsageConsentStore.swift \
  FrameGuide/AIComposition/SnapshotJPEGCodec.swift \
  FrameGuide/AIComposition/PreviewSnapshotProvider.swift \
  FrameGuide/AIComposition/AICompositionCoordinator.swift \
  scripts/AICompositionFixture.swift \
  -framework Foundation -framework CoreImage -framework CoreVideo \
  -framework ImageIO -framework Combine -framework Security \
  -o "/tmp/ai-composition-fixture"
"/tmp/ai-composition-fixture"
python3 scripts/validate_project.py
xcodebuild -project FrameGuide.xcodeproj -scheme FrameGuide -configuration Debug -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' -derivedDataPath build/simulator CODE_SIGNING_ALLOWED=NO build
xcodebuild -project FrameGuide.xcodeproj -scheme FrameGuide -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/device CODE_SIGNING_ALLOWED=NO build
mkdir -p build/package/Payload
cp -R build/device/Build/Products/Release-iphoneos/FrameGuide.app build/package/Payload/
cd build/package
zip -qr ../FrameGuide-UNSIGNED.ipa Payload
```

CI 的每步均启用 `set -euo pipefail`，测试或编译失败即停止后续打包；日志 artifact 使用 `always()` 保存失败证据。未签名 artifact 的名称与说明明确要求用户自己的签名。工作流只有 `contents: read`，不收集签名、不推送仓库、不掩盖失败。源码包模式在解压前记录 ZIP SHA-256；完整源码模式记录 checkout commit。

## 尚存验证工作

历史版本的真实 macOS CI 已确认工具链、Core SwiftPM、结构检查、Apple SDK/资源编译、模拟器与设备目标构建、未签名打包和上传。仍需实际启动并操作模拟器，再使用自己的有效签名在目标 iPhone 安装并逐项执行设备清单，包括启动颜色、方向/镜像、像素尺寸、权限、保存/分享、生命周期和离线行为。运行验收尚未完成，不能据编译和归档检查宣称 iOS 26 兼容或可正常安装运行。
