import Combine
import UIKit

struct PhotoShareFile: Identifiable {
    let url: URL
    var id: URL { url }
}

@MainActor
final class PhotoReviewViewModel: ObservableObject {
    @Published private(set) var selectedFilter: PhotoFilter = .original
    @Published private(set) var previewImage: UIImage?
    @Published private(set) var exportData: Data?
    @Published private(set) var isProcessing = false
    @Published private(set) var isSaving = false
    @Published private(set) var isPreparingShare = false
    @Published private(set) var message: String?
    @Published private(set) var shareFile: PhotoShareFile?

    private let originalData: CapturedPhoto
    private let processor = PhotoProcessor()
    private var generation: UInt64 = 0
    private var renderTask: Task<Void, Never>?
    private var shareURL: URL?
    var canExport: Bool { exportData != nil && !isProcessing && !isSaving && !isPreparingShare && shareURL == nil }

    init(originalData: CapturedPhoto) {
        self.originalData = originalData
        select(.original)
    }

    func select(_ filter: PhotoFilter) {
        guard !isSaving, !isPreparingShare, shareURL == nil else { return }
        generation &+= 1
        let ticket = generation
        renderTask?.cancel()
        selectedFilter = filter
        previewImage = nil
        exportData = nil
        message = nil
        isProcessing = true
        let source = originalData
        let processor = self.processor
        renderTask = Task { [weak self] in
            do {
                let preview = try await processor.render(data: source, filter: filter, maxPixelDimension: 1600)
                try Task.checkCancellation()
                let output = try await processor.render(data: source, filter: filter, maxPixelDimension: nil)
                try Task.checkCancellation()
                guard let self, self.generation == ticket else { return }
                guard let image = UIImage(data: preview) else { throw PhotoProcessingError.decode }
                self.previewImage = image
                self.exportData = output
                self.isProcessing = false
            } catch {
                guard let self, self.generation == ticket else { return }
                self.isProcessing = false
                self.message = error is CancellationError ? nil : error.localizedDescription
            }
        }
    }

    func save() {
        guard canExport, let data = exportData else { return }
        isSaving = true
        message = nil
        Task {
            defer { isSaving = false }
            do {
                try await PhotoLibrary.saveJPEG(data)
                message = "已保存到相册"
            } catch { message = error.localizedDescription }
        }
    }

    func share() {
        guard canExport, let data = exportData else { return }
        isPreparingShare = true
        message = nil
        let ticket = generation
        Task {
            defer { isPreparingShare = false }
            do {
                let url = try await processor.makeShareFile(data: data)
                guard generation == ticket else {
                    await processor.removeShareFile(url)
                    return
                }
                shareURL = url
                shareFile = PhotoShareFile(url: url)
            } catch { message = "无法准备分享文件，请重试。" }
        }
    }

    func dismissShareSheet() { shareFile = nil }

    func finishSharing() {
        guard let url = shareURL else { return }
        shareFile = nil
        shareURL = nil
        Task { await processor.removeShareFile(url) }
    }

    func close() {
        generation &+= 1
        renderTask?.cancel()
        isProcessing = false
        finishSharing()
    }
}
