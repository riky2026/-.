import SwiftUI

@MainActor
struct PhotoReviewScreen: View {
    @StateObject private var model: PhotoReviewViewModel
    let onDismiss: () -> Void

    init(originalData: CapturedPhoto, onDismiss: @escaping () -> Void) {
        _model = StateObject(wrappedValue: PhotoReviewViewModel(originalData: originalData))
        self.onDismiss = onDismiss
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 20).fill(Theme.panel)
                        if let image = model.previewImage {
                            Image(uiImage: image).resizable().scaledToFit()
                                .accessibilityLabel("照片预览，\(model.selectedFilter.title)效果")
                        } else if model.isProcessing { ProgressView("正在处理照片…") }
                        else { Label("照片暂时无法显示", systemImage: "photo") }
                    }
                    .aspectRatio(3.0 / 4.0, contentMode: .fit)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 100))], spacing: 12) {
                        ForEach(PhotoFilter.allCases) { filter in
                            Button { model.select(filter) } label: {
                                Text(filter.title).font(.body.weight(.medium))
                                    .frame(maxWidth: .infinity, minHeight: 44)
                                    .background(model.selectedFilter == filter ? Theme.accent : Theme.panel,
                                                in: RoundedRectangle(cornerRadius: 12))
                                    .foregroundStyle(model.selectedFilter == filter ? Theme.background : Theme.ink)
                            }
                            .accessibilityAddTraits(model.selectedFilter == filter ? .isSelected : [])
                            .disabled(model.isSaving || model.isPreparingShare)
                        }
                    }
                    if let message = model.message {
                        Text(message).font(.callout).multilineTextAlignment(.center)
                            .accessibilityAddTraits(.updatesFrequently)
                    }
                    Button { model.save() } label: {
                        Label(model.isSaving ? "正在保存…" : "保存到相册", systemImage: "square.and.arrow.down")
                            .frame(maxWidth: .infinity, minHeight: 44)
                    }.buttonStyle(.borderedProminent).disabled(!model.canExport)
                    Button { model.share() } label: {
                        Label(model.isPreparingShare ? "正在准备分享…" : "分享照片", systemImage: "square.and.arrow.up")
                            .frame(maxWidth: .infinity, minHeight: 44)
                    }.buttonStyle(.bordered).disabled(!model.canExport)
                }.padding(16)
            }
            .background(Theme.background).foregroundStyle(Theme.ink)
            .navigationTitle("照片预览").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("返回相机") { model.close(); onDismiss() }
                        .frame(minHeight: 44).disabled(model.isSaving || model.isPreparingShare)
                }
            }
        }
        .tint(Theme.accent).preferredColorScheme(.dark)
        .sheet(item: Binding(get: { model.shareFile }, set: { if $0 == nil { model.dismissShareSheet() } }),
               onDismiss: { model.finishSharing() }) { file in
            ShareSheet(items: [file.url], onComplete: { model.dismissShareSheet() })
        }
        .onDisappear {
            // A system share presentation may cover this view. Keep its file
            // alive until the sheet actually finishes dismissing.
            if model.shareFile == nil && !model.isPreparingShare { model.close() }
        }
    }
}
