import Foundation

enum PhotoFilter: String, CaseIterable, Identifiable, Sendable {
    case original, warm, clear, monochrome
    var id: String { rawValue }
    var title: String {
        switch self {
        case .original: return "原片"
        case .warm: return "暖调"
        case .clear: return "清透"
        case .monochrome: return "黑白"
        }
    }
}
