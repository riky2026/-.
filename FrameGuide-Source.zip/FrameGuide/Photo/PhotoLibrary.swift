import Foundation
import Photos

enum PhotoSaveError: LocalizedError {
    case permissionDenied
    case failed
    var errorDescription: String? {
        switch self {
        case .permissionDenied: return "未获准添加到相册。你仍可分享照片，或在系统设置中允许添加照片。"
        case .failed: return "照片未能保存到相册，请重试。"
        }
    }
}

enum PhotoLibrary {
    static func saveJPEG(_ data: Data) async throws {
        let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard status == .authorized else { throw PhotoSaveError.permissionDenied }
        do {
            try await PHPhotoLibrary.shared().performChanges {
                PHAssetCreationRequest.forAsset().addResource(with: .photo, data: data, options: nil)
            }
        } catch { throw PhotoSaveError.failed }
    }
}
