import SwiftUI
import UIKit

@MainActor
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    var onComplete: @MainActor () -> Void = {}

    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: items, applicationActivities: nil)
        controller.completionWithItemsHandler = { [onComplete] _, _, _, _ in
            Task { @MainActor in onComplete() }
        }
        return controller
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
