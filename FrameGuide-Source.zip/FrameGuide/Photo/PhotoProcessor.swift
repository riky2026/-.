import CoreImage
import Foundation
import ImageIO
import UniformTypeIdentifiers

struct CapturedPhoto: Sendable {
    let bytes: Data
    let framing: PhotoFraming
    let resolvedUprightSize: CGSize
}

/// Captured in already oriented/mirrored photo-output pixels (top-left origin).
/// The centered preview has no pan or zoom. Its midpoint identifies the native
/// aperture; reject a mismatched output raster rather than export unseen pixels.
struct PhotoFraming: Sendable {
    let dimensions: CGSize
    let topLeftRect: CGRect

    init?(outputRect r: CGRect, dimensions s: CGSize, aspect: CGFloat) {
        guard [s.width, s.height, r.origin.x, r.origin.y, r.width, r.height, aspect].allSatisfy({ $0.isFinite }),
              s.width > 0, s.height > 0, r.width > 0, r.height > 0, aspect > 0,
              abs(aspect - 0.75) < 0.002,
              abs(r.width - r.height * aspect) <= 2,
              abs(r.midX - s.width / 2) <= 1, abs(r.midY - s.height / 2) <= 1,
              r.minX >= -1, r.minY >= -1, r.maxX <= s.width + 1, r.maxY <= s.height + 1
        else { return nil }
        dimensions = s
        topLeftRect = r.intersection(CGRect(origin: .zero, size: s))
    }

    func nativeCrop(in extent: CGRect, resolved: CGSize) -> CGRect? {
        // The shutter conversion fixes the field of view for this specific photo
        // request. A matching resolved capture ID pairs it with the actual still
        // dimensions. Only accept a uniform native sampling of this aperture.
        guard resolved.width > 0, resolved.height > 0, extent.size == resolved,
              resolved.width <= dimensions.width, resolved.height <= dimensions.height,
              resolved.width * dimensions.height == resolved.height * dimensions.width else { return nil }
        // Round INWARD so no outside pixel is sampled, convert top-left to CI's bottom-left.
        let left = ceil(topLeftRect.minX * resolved.width / dimensions.width)
        let right = floor(topLeftRect.maxX * resolved.width / dimensions.width)
        let top = ceil(topLeftRect.minY * resolved.height / dimensions.height)
        let bottom = floor(topLeftRect.maxY * resolved.height / dimensions.height)
        guard right > left, bottom > top else { return nil }
        return CGRect(x: extent.minX + left, y: extent.maxY - bottom,
                      width: right - left, height: bottom - top)
    }
}

enum PhotoProcessingError: LocalizedError {
    case decode, filter, encode, framing
    var errorDescription: String? {
        switch self {
        case .framing: return "照片与拍摄时的取景范围不一致，请返回相机重新拍摄。"
        case .decode: return "无法读取这张照片，请返回相机重新拍摄。"
        case .filter: return "照片效果处理失败，请重新选择效果。"
        case .encode: return "无法生成照片文件，请重试。"
        }
    }
}

/// All decode, filter, resize, JPEG encoding and share-file IO run off the main actor.
actor PhotoProcessor {
    private lazy var context = CIContext()

    func render(data: CapturedPhoto, filter: PhotoFilter, maxPixelDimension: Int?) throws -> Data {
        try Task.checkCancellation()
        // Capture has already decided front-camera mirroring. Honor its EXIF once;
        // never apply a second lens-dependent mirror here.
        guard var image = CIImage(data: data.bytes, options: [.applyOrientationProperty: true]),
              !image.extent.isEmpty, !image.extent.isInfinite else { throw PhotoProcessingError.decode }
        guard let crop = data.framing.nativeCrop(in: image.extent, resolved: data.resolvedUprightSize) else { throw PhotoProcessingError.framing }
        image = image.cropped(to: crop).transformed(by: CGAffineTransform(translationX: -crop.minX, y: -crop.minY))
        let name: String?
        switch filter {
        case .original: name = nil
        case .warm: name = "CITemperatureAndTint"
        case .clear: name = "CIColorControls"
        case .monochrome: name = "CIPhotoEffectMono"
        }
        if let name {
            guard let effect = CIFilter(name: name) else { throw PhotoProcessingError.filter }
            effect.setValue(image, forKey: kCIInputImageKey)
            if filter == .warm {
                effect.setValue(CIVector(x: 6500, y: 0), forKey: "inputNeutral")
                effect.setValue(CIVector(x: 7500, y: 0), forKey: "inputTargetNeutral")
            } else if filter == .clear {
                effect.setValue(0.95, forKey: kCIInputSaturationKey)
                effect.setValue(1.08, forKey: kCIInputContrastKey)
                effect.setValue(0.02, forKey: kCIInputBrightnessKey)
            }
            guard let output = effect.outputImage else { throw PhotoProcessingError.filter }
            image = output
        }
        if let limit = maxPixelDimension, limit > 0 {
            let scale = min(1, CGFloat(limit) / max(image.extent.width, image.extent.height))
            image = image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        }
        try Task.checkCancellation()
        guard let pixels = context.createCGImage(image, from: image.extent) else { throw PhotoProcessingError.encode }
        return try jpeg(pixels)
    }

    func thumbnail(data: CapturedPhoto) throws -> Data {
        try render(data: data, filter: .original, maxPixelDimension: 192)
    }

    func makeShareFile(data: Data) throws -> URL {
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("FrameGuide-\(UUID().uuidString).jpg")
        do { try data.write(to: url, options: .atomic) }
        catch {
            try? FileManager.default.removeItem(at: url)
            throw error
        }
        return url
    }

    func removeShareFile(_ url: URL) { try? FileManager.default.removeItem(at: url) }

    private func jpeg(_ pixels: CGImage) throws -> Data {
        let output = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(output, UTType.jpeg.identifier as CFString, 1, nil)
        else { throw PhotoProcessingError.encode }
        // The pixels are upright now. Do not copy the source EXIF orientation.
        CGImageDestinationAddImage(destination, pixels, [
            kCGImageDestinationLossyCompressionQuality: 0.94,
            kCGImagePropertyOrientation: 1
        ] as CFDictionary)
        guard CGImageDestinationFinalize(destination) else { throw PhotoProcessingError.encode }
        return output as Data
    }
}
