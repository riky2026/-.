import CoreImage
import Foundation
import ImageIO
import UniformTypeIdentifiers

/// Both rectangles come from the same photo output, connection and instant.
struct ShutterFraming: Sendable {
    let reference: CGRect
    let visible: CGRect
    let viewportAspect: CGFloat
    let cleanSize: CGSize   // upright active-format clean aperture
    let maximum: CGSize     // requested upright still ceiling, not the converter's raster
    let unavailable: String?
    let diagnostic: String

    func nativeCrop(resolved: CGSize, decoded: CGSize) -> (CGRect?, String) {
        if let unavailable { return (nil, unavailable) }
        let a = reference, v = visible
        guard [a.origin.x, a.origin.y, a.width, a.height, v.origin.x, v.origin.y, v.width, v.height].allSatisfy({ $0.isFinite }),
              a.width >= 2, a.height >= 2, !v.isEmpty, a.contains(v) else { return (nil, "转换范围无效") }
        guard resolved == decoded, decoded.width > 0, decoded.height > 0,
              decoded.width <= maximum.width, decoded.height <= maximum.height else { return (nil, "实拍尺寸未确认") }
        let aspect = decoded.width / decoded.height
        guard abs(viewportAspect - 0.75) < 0.002, abs(v.width - v.height * viewportAspect) <= 2,
              abs(a.width - a.height * aspect) <= 1, cleanSize.height > 0,
              abs(cleanSize.width - cleanSize.height * aspect) <= 1,
              maximum.width * decoded.height == maximum.height * decoded.width
        else { return (nil, "画幅或方向不一致") }
        // Convert to native pixels relative to the calibrated reference, including
        // nonzero origin. Keep the actual visible offset and round INWARD.
        let left = ceil((v.minX - a.minX) * decoded.width / a.width)
        let right = floor((v.maxX - a.minX) * decoded.width / a.width)
        let top = ceil((v.minY - a.minY) * decoded.height / a.height)
        let bottom = floor((v.maxY - a.minY) * decoded.height / a.height)
        guard right > left, bottom > top else { return (nil, "范围小于一个像素") }
        return (CGRect(x: left, y: decoded.height - bottom, width: right - left, height: bottom - top), "取景范围已确认")
    }
}

struct CapturedPhoto: Sendable {
    let bytes: Data
    let uprightSize: CGSize
    let crop: CGRect?       // in upright CI pixels relative to extent.origin
    let diagnostic: String
    var keepsFullFrame: Bool { crop == nil }

    // Called once on the camera queue. Inspect JPEG metadata without decoding the full raster.
    init(bytes: Data, plan: ShutterFraming, resolved: CGSize) throws {
        guard let src = CGImageSourceCreateWithData(bytes as CFData, nil),
              let info = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any],
              let w = info[kCGImagePropertyPixelWidth] as? NSNumber,
              let h = info[kCGImagePropertyPixelHeight] as? NSNumber,
              w.intValue > 0, h.intValue > 0 else { throw PhotoProcessingError.decode }
        let exif = (info[kCGImagePropertyOrientation] as? NSNumber)?.intValue ?? 1
        let swapped = (5...8).contains(exif)
        let size = CGSize(width: swapped ? h.intValue : w.intValue, height: swapped ? w.intValue : h.intValue)
        let result = (1...8).contains(exif) ? plan.nativeCrop(resolved: resolved, decoded: size) : (nil, "未知 EXIF 方向")
        self.bytes = bytes
        uprightSize = size
        crop = result.0
        diagnostic = "\(plan.diagnostic) ref=\(plan.reference) roi=\(plan.visible) clean=\(plan.cleanSize) max=\(plan.maximum) resolved=\(resolved) jpeg=\(size) exif=\(exif) result=\(result.1)"
    }
}

enum PhotoProcessingError: LocalizedError {
    case decode, filter, encode, framing
    var errorDescription: String? {
        switch self {
        case .framing: return "照片与拍摄时的取景范围不一致，请返回相机重新拍摄。"
        case .decode: return "无法读取这张照片，请返回相机重新拍摄。"
        case .filter: return "照片效果处理失败，请重新选择效果。"
        case .encode: return "无法生成照片文件，请重试。"
        }
    }
}

/// All decode, filter, resize, JPEG encoding and share-file IO run off the main actor.
actor PhotoProcessor {
    private lazy var context = CIContext()

    func render(data: CapturedPhoto, filter: PhotoFilter, maxPixelDimension: Int?) throws -> Data {
        try Task.checkCancellation()
        // Capture has already decided front-camera mirroring. Honor its EXIF once;
        // never apply a second lens-dependent mirror here.
        guard var image = CIImage(data: data.bytes, options: [.applyOrientationProperty: true]),
              !image.extent.isEmpty, !image.extent.isInfinite else { throw PhotoProcessingError.decode }
        if let native = data.crop {
            guard image.extent.size == data.uprightSize else { throw PhotoProcessingError.framing }
            let crop = native.offsetBy(dx: image.extent.minX, dy: image.extent.minY)
            image = image.cropped(to: crop).transformed(by: CGAffineTransform(translationX: -crop.minX, y: -crop.minY))
        }
        let name: String?
        switch filter {
        case .original: name = nil
        case .warm: name = "CITemperatureAndTint"
        case .clear: name = "CIColorControls"
        case .monochrome: name = "CIPhotoEffectMono"
        }
        if let name {
            guard let effect = CIFilter(name: name) else { throw PhotoProcessingError.filter }
            effect.setValue(image, forKey: kCIInputImageKey)
            if filter == .warm {
                effect.setValue(CIVector(x: 6500, y: 0), forKey: "inputNeutral")
                effect.setValue(CIVector(x: 7500, y: 0), forKey: "inputTargetNeutral")
            } else if filter == .clear {
                effect.setValue(0.95, forKey: kCIInputSaturationKey)
                effect.setValue(1.08, forKey: kCIInputContrastKey)
                effect.setValue(0.02, forKey: kCIInputBrightnessKey)
            }
            guard let output = effect.outputImage else { throw PhotoProcessingError.filter }
            image = output
        }
        if let limit = maxPixelDimension, limit > 0 {
            let scale = min(1, CGFloat(limit) / max(image.extent.width, image.extent.height))
            image = image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        }
        try Task.checkCancellation()
        guard let pixels = context.createCGImage(image, from: image.extent) else { throw PhotoProcessingError.encode }
        return try jpeg(pixels)
    }

    func thumbnail(data: CapturedPhoto) throws -> Data {
        try render(data: data, filter: .original, maxPixelDimension: 192)
    }

    func makeShareFile(data: Data) throws -> URL {
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("FrameGuide-\(UUID().uuidString).jpg")
        do { try data.write(to: url, options: .atomic) }
        catch {
            try? FileManager.default.removeItem(at: url)
            throw error
        }
        return url
    }

    func removeShareFile(_ url: URL) { try? FileManager.default.removeItem(at: url) }

    private func jpeg(_ pixels: CGImage) throws -> Data {
        let output = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(output, UTType.jpeg.identifier as CFString, 1, nil)
        else { throw PhotoProcessingError.encode }
        // The pixels are upright now. Do not copy the source EXIF orientation.
        CGImageDestinationAddImage(destination, pixels, [
            kCGImageDestinationLossyCompressionQuality: 0.94,
            kCGImagePropertyOrientation: 1
        ] as CFDictionary)
        guard CGImageDestinationFinalize(destination) else { throw PhotoProcessingError.encode }
        return output as Data
    }
}
