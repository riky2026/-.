import CoreImage
import Foundation
import ImageIO
import UniformTypeIdentifiers

enum PhotoProcessingError: LocalizedError {
    case decode, filter, encode
    var errorDescription: String? {
        switch self {
        case .decode: return "无法读取这张照片，请返回相机重新拍摄。"
        case .filter: return "照片效果处理失败，请重新选择效果。"
        case .encode: return "无法生成照片文件，请重试。"
        }
    }
}

/// All decode, filter, resize, JPEG encoding and share-file IO run off the main actor.
actor PhotoProcessor {
    private lazy var context = CIContext()

    func render(data: Data, filter: PhotoFilter, maxPixelDimension: Int?) throws -> Data {
        try Task.checkCancellation()
        // Capture has already decided front-camera mirroring. Honor its EXIF once;
        // never apply a second lens-dependent mirror here.
        guard var image = CIImage(data: data, options: [.applyOrientationProperty: true]),
              !image.extent.isEmpty, !image.extent.isInfinite else { throw PhotoProcessingError.decode }
        let name: String?
        switch filter {
        case .original: name = nil
        case .warm: name = "CITemperatureAndTint"
        case .clear: name = "CIColorControls"
        case .monochrome: name = "CIPhotoEffectMono"
        }
        if let name {
            guard let effect = CIFilter(name: name) else { throw PhotoProcessingError.filter }
            effect.setValue(image, forKey: kCIInputImageKey)
            if filter == .warm {
                effect.setValue(CIVector(x: 6500, y: 0), forKey: "inputNeutral")
                effect.setValue(CIVector(x: 7500, y: 0), forKey: "inputTargetNeutral")
            } else if filter == .clear {
                effect.setValue(0.95, forKey: kCIInputSaturationKey)
                effect.setValue(1.08, forKey: kCIInputContrastKey)
                effect.setValue(0.02, forKey: kCIInputBrightnessKey)
            }
            guard let output = effect.outputImage else { throw PhotoProcessingError.filter }
            image = output
        }
        if let limit = maxPixelDimension, limit > 0 {
            let scale = min(1, CGFloat(limit) / max(image.extent.width, image.extent.height))
            image = image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        }
        try Task.checkCancellation()
        guard let pixels = context.createCGImage(image, from: image.extent) else { throw PhotoProcessingError.encode }
        return try jpeg(pixels)
    }

    func thumbnail(data: Data) throws -> Data {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let pixels = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: 192,
                kCGImageSourceShouldCacheImmediately: true
              ] as CFDictionary) else { throw PhotoProcessingError.decode }
        return try jpeg(pixels)
    }

    func makeShareFile(data: Data) throws -> URL {
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("FrameGuide-\(UUID().uuidString).jpg")
        do { try data.write(to: url, options: .atomic) }
        catch {
            try? FileManager.default.removeItem(at: url)
            throw error
        }
        return url
    }

    func removeShareFile(_ url: URL) { try? FileManager.default.removeItem(at: url) }

    private func jpeg(_ pixels: CGImage) throws -> Data {
        let output = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(output, UTType.jpeg.identifier as CFString, 1, nil)
        else { throw PhotoProcessingError.encode }
        // The pixels are upright now. Do not copy the source EXIF orientation.
        CGImageDestinationAddImage(destination, pixels, [
            kCGImageDestinationLossyCompressionQuality: 0.94,
            kCGImagePropertyOrientation: 1
        ] as CFDictionary)
        guard CGImageDestinationFinalize(destination) else { throw PhotoProcessingError.encode }
        return output as Data
    }
}
