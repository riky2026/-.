import SwiftUI

enum Theme {
    static let background = Color(red: 0.055, green: 0.065, blue: 0.065)
    static let panel = Color(red: 0.11, green: 0.13, blue: 0.13)
    static let ink = Color(red: 0.96, green: 0.95, blue: 0.90)
    static let accent = Color(red: 0.40, green: 0.88, blue: 0.76)
}

extension SceneMode {
    var title: String {
        switch self { case .automatic: return "自动"; case .portrait: return "人像"; case .landscape: return "风景" }
    }
}
extension PlacementMode {
    var title: String {
        switch self {
        case .smart: return "智能"
        case .center: return "居中"
        case .leftThird: return "左侧三分"
        case .rightThird: return "右侧三分"
        }
    }
}
extension FlashSetting {
    var title: String {
        switch self { case .off: return "关闭"; case .auto: return "自动"; case .on: return "开启" }
    }
    var symbol: String { self == .off ? "bolt.slash" : (self == .auto ? "bolt.badge.a" : "bolt.fill") }
}
