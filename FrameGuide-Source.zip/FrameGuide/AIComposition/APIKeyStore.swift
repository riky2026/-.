import Foundation
import Security

protocol APIKeyStoring {
    func load(for provider: AIProvider) throws -> String?
    func save(_ value: String, for provider: AIProvider) throws
    func delete(for provider: AIProvider) throws
}

final class APIKeyStore: APIKeyStoring {
    private let account: String

    init(account: String = "api-key") {
        self.account = account
    }

    private func query(for provider: AIProvider) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: provider.keychainService,
         kSecAttrAccount as String: account,
         kSecAttrSynchronizable as String: false]
    }

    func load(for provider: AIProvider) throws -> String? {
        var lookup = query(for: provider)
        lookup[kSecReturnData as String] = true
        lookup[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(lookup as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data,
              let value = String(data: data, encoding: .utf8) else { throw AICompositionError.keyStorage }
        return value
    }

    func save(_ value: String, for provider: AIProvider) throws {
        let key = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { throw AICompositionError.keyMissing }
        // Keep the exact same input rules as the request builder; never include input in errors.
        guard !value.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }),
              !key.unicodeScalars.contains(where: { CharacterSet.whitespacesAndNewlines.contains($0) }) else {
            throw AICompositionError.keyInvalid
        }
        let attributes: [String: Any] = [
            kSecValueData as String: Data(key.utf8),
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
            kSecAttrSynchronizable as String: false
        ]
        let keyQuery = query(for: provider)
        let status = SecItemUpdate(keyQuery as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            var insertion = keyQuery
            insertion.merge(attributes) { _, new in new }
            guard SecItemAdd(insertion as CFDictionary, nil) == errSecSuccess else {
                throw AICompositionError.keyStorage
            }
        } else if status != errSecSuccess {
            throw AICompositionError.keyStorage
        }
    }

    func delete(for provider: AIProvider) throws {
        let status = SecItemDelete(query(for: provider) as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else { throw AICompositionError.keyStorage }
    }
}

protocol AICompositionConfigurationStoring {
    func load() throws -> AICompositionServiceSettings?
    func save(_ settings: AICompositionServiceSettings) throws
}

/// Persists only provider selection and Qwen endpoint configuration on this device.
final class AICompositionConfigurationStore: AICompositionConfigurationStoring {
    private let service = "com.frameguide.ai-settings"
    private let account = "composition-provider"

    private var query: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: account,
         kSecAttrSynchronizable as String: false]
    }

    func load() throws -> AICompositionServiceSettings? {
        var lookup = query
        lookup[kSecReturnData as String] = true
        lookup[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(lookup as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data,
              let settings = try? JSONDecoder().decode(AICompositionServiceSettings.self, from: data) else {
            throw AICompositionError.configurationStorage
        }
        return settings
    }

    func save(_ settings: AICompositionServiceSettings) throws {
        guard let data = try? JSONEncoder().encode(settings) else {
            throw AICompositionError.configurationStorage
        }
        let attributes: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
            kSecAttrSynchronizable as String: false
        ]
        let status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            var insertion = query
            insertion.merge(attributes) { _, new in new }
            guard SecItemAdd(insertion as CFDictionary, nil) == errSecSuccess else {
                throw AICompositionError.configurationStorage
            }
        } else if status != errSecSuccess {
            throw AICompositionError.configurationStorage
        }
    }
}
