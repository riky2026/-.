import CoreImage
import Foundation
import ImageIO
import UniformTypeIdentifiers

enum SnapshotJPEGCodec {
    // Reused for the video callback. No CIImage or pixel buffer is stored here.
    private static let context = CIContext(options: [.cacheIntermediates: false])
    private static let colorSpace = CGColorSpaceCreateDeviceRGB()

    private static func visibleImage(_ image: CIImage, orientation: CGImagePropertyOrientation,
                                     mirrored: Bool, viewAspect: CGFloat) throws -> CIImage {
        guard viewAspect.isFinite, viewAspect > 0 else { throw AICompositionError.encoding }
        let upright = image.oriented(orientation)
        let e = upright.extent
        guard !e.isNull, !e.isInfinite, e.minX.isFinite, e.minY.isFinite,
              e.width.isFinite, e.height.isFinite, e.width > 0, e.height > 0 else {
            throw AICompositionError.encoding
        }
        let cropW = min(e.width, e.height * viewAspect)
        let cropH = cropW / viewAspect
        guard cropW.isFinite, cropH.isFinite, cropW > 0, cropH > 0 else { throw AICompositionError.encoding }
        let originZero = upright.transformed(by: CGAffineTransform(translationX: -e.minX, y: -e.minY))
        let crop = CGRect(x: (e.width - cropW) / 2, y: (e.height - cropH) / 2, width: cropW, height: cropH)
        var visible = originZero.cropped(to: crop)
            .transformed(by: CGAffineTransform(translationX: -crop.minX, y: -crop.minY))
        if mirrored {
            visible = visible.transformed(by: CGAffineTransform(a: -1, b: 0, c: 0, d: 1, tx: cropW, ty: 0))
        }
        return visible
    }

    static func encode(_ image: CIImage, orientation: CGImagePropertyOrientation,
                       mirrored: Bool, viewAspect: CGFloat = 3.0 / 4.0) throws -> Data {
        var visible = try visibleImage(image, orientation: orientation, mirrored: mirrored, viewAspect: viewAspect)
        let scale = min(1, 1280 / max(visible.extent.width, visible.extent.height))
        visible = visible.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        // Inward rounding avoids reading transparent pixels outside the transformed image.
        let e = visible.extent
        let bounds = CGRect(x: ceil(e.minX), y: ceil(e.minY),
                            width: floor(e.maxX) - ceil(e.minX), height: floor(e.maxY) - ceil(e.minY))
        guard bounds.width >= 1, bounds.height >= 1,
              let cgImage = context.createCGImage(visible, from: bounds, format: .RGBA8, colorSpace: colorSpace) else {
            throw AICompositionError.encoding
        }
        // New CGImage + new destination: no original properties/EXIF/GPS/thumbnail are copied.
        for quality in [0.82, 0.70, 0.58] {
            let output = NSMutableData()
            guard let destination = CGImageDestinationCreateWithData(output, UTType.jpeg.identifier as CFString, 1, nil) else {
                throw AICompositionError.encoding
            }
            CGImageDestinationAddImage(destination, cgImage,
                [kCGImageDestinationLossyCompressionQuality: quality] as CFDictionary)
            guard CGImageDestinationFinalize(destination) else { throw AICompositionError.encoding }
            if output.length <= 2 * 1024 * 1024 { return output as Data }
        }
        throw AICompositionError.encoding
    }

    static func fingerprint(_ image: CIImage, orientation: CGImagePropertyOrientation,
                            mirrored: Bool) throws -> [Float] {
        let visible = try visibleImage(image, orientation: orientation, mirrored: mirrored, viewAspect: 3.0 / 4.0)
        // Area-average each block before sampling, rather than point-sampling an 8x8 resize.
        let width = visible.extent.width / 8
        let height = visible.extent.height / 8
        var means = [Float]()
        means.reserveCapacity(64)
        for row in 0..<8 {
            for column in 0..<8 {
                let block = CGRect(x: CGFloat(column) * width, y: CGFloat(row) * height, width: width, height: height)
                let average = visible.applyingFilter("CIAreaAverage", parameters: [kCIInputExtentKey: CIVector(cgRect: block)])
                var rgba = [UInt8](repeating: 0, count: 4)
                rgba.withUnsafeMutableBytes {
                    context.render(average, toBitmap: $0.baseAddress!, rowBytes: 4,
                        bounds: CGRect(x: 0, y: 0, width: 1, height: 1), format: .RGBA8, colorSpace: colorSpace)
                }
                means.append((0.2126 * Float(rgba[0]) + 0.7152 * Float(rgba[1]) + 0.0722 * Float(rgba[2])) / 255)
            }
        }
        return means
    }
}
