import Foundation
import Security

protocol AIUsageConsentStoring {
    func isGranted() throws -> Bool
    func grant() throws
}

final class AIUsageConsentStore: AIUsageConsentStoring {
    private var query: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "com.frameguide.deepseek",
         kSecAttrAccount as String: "image-analysis-consent",
         kSecAttrSynchronizable as String: false]
    }

    func isGranted() throws -> Bool {
        let status = SecItemCopyMatching(query as CFDictionary, nil)
        if status == errSecItemNotFound { return false }
        guard status == errSecSuccess else { throw AICompositionError.consentStorage }
        return true
    }

    func grant() throws {
        var attributes = query
        attributes[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        attributes[kSecValueData as String] = Data([1])
        let status = SecItemAdd(attributes as CFDictionary, nil)
        guard status == errSecSuccess || status == errSecDuplicateItem else {
            throw AICompositionError.consentStorage
        }
    }
}
