import Foundation
import Security

protocol AIUsageConsentStoring {
    func isGranted(for provider: AIProvider) throws -> Bool
    func grant(for provider: AIProvider) throws
}

final class AIUsageConsentStore: AIUsageConsentStoring {
    private func query(for provider: AIProvider) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: provider.keychainService,
         kSecAttrAccount as String: "image-analysis-consent",
         kSecAttrSynchronizable as String: false]
    }

    func isGranted(for provider: AIProvider) throws -> Bool {
        let status = SecItemCopyMatching(query(for: provider) as CFDictionary, nil)
        if status == errSecItemNotFound { return false }
        guard status == errSecSuccess else { throw AICompositionError.consentStorage }
        return true
    }

    func grant(for provider: AIProvider) throws {
        var attributes = query(for: provider)
        attributes[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        attributes[kSecValueData as String] = Data([1])
        let status = SecItemAdd(attributes as CFDictionary, nil)
        guard status == errSecSuccess || status == errSecDuplicateItem else {
            throw AICompositionError.consentStorage
        }
    }
}
