import Combine
import Foundation
import ImageIO
import UniformTypeIdentifiers

enum AICompositionPhase: Equatable {
    case idle, awaitingConsent, acquiring, analyzing, guiding
    case failed(AICompositionError), outdated
}

@MainActor
final class AICompositionCoordinator: ObservableObject {
    @Published private(set) var phase: AICompositionPhase = .idle
    @Published private(set) var plans: [AICompositionPlan] = []
    @Published private(set) var selectedIndex: Int?
    @Published private(set) var keyConfigured = false

    var selectedPlan: AICompositionPlan? {
        guard let selectedIndex, plans.indices.contains(selectedIndex) else { return nil }
        return plans[selectedIndex]
    }

    private let client: any AICompositionServing
    private let keyStore: any APIKeyStoring
    private let consentStore: any AIUsageConsentStoring
    private let snapshots: any PreviewSnapshotProviding
    private let now: () -> Double
    private let analysisTimeout: Duration
    private var requestID: UUID?
    private var work: Task<Void, Never>?
    private var deadline: Task<Void, Never>?

    init(client: any AICompositionServing, keyStore: any APIKeyStoring,
         consentStore: any AIUsageConsentStoring, snapshots: any PreviewSnapshotProviding,
         now: @escaping () -> Double, analysisTimeout: Duration = .seconds(40)) {
        self.client = client
        self.keyStore = keyStore
        self.consentStore = consentStore
        self.snapshots = snapshots
        self.now = now
        self.analysisTimeout = analysisTimeout
        refreshKeyStatus()
    }

    deinit {
        work?.cancel()
        deadline?.cancel()
        if let requestID { snapshots.cancel(id: requestID) }
    }

    func refreshKeyStatus() {
        do { keyConfigured = try keyStore.load().map { !$0.isEmpty } ?? false }
        catch { keyConfigured = false; phase = .failed(.keyStorage) }
    }

    func saveKey(_ value: String) throws {
        invalidate()
        try keyStore.save(value)
        refreshKeyStatus()
    }

    func deleteKey() throws {
        invalidate()
        try keyStore.delete()
        refreshKeyStatus()
    }

    func invalidate() {
        let oldID = requestID
        requestID = nil
        work?.cancel()
        work = nil
        deadline?.cancel()
        deadline = nil
        if let oldID { snapshots.cancel(id: oldID) }
        plans = []
        selectedIndex = nil
        phase = .idle
    }

    func begin(isFrontCamera: Bool) {
        invalidate()
        do {
            guard try consentStore.isGranted() else {
                phase = .awaitingConsent
                return
            }
        } catch {
            fail(.consentStorage)
            return
        }

        let id = UUID()
        let notBefore = now()
        let provider = snapshots
        let service = client
        requestID = id
        phase = .acquiring
        scheduleDeadline(for: id, after: .seconds(2), error: .frameUnavailable)
        work = Task { [weak self] in
            guard self?.accepts(id) == true else { return }
            let snapshot: PreviewSnapshot
            do {
                snapshot = try await provider.request(id: id, isFrontCamera: isFrontCamera, after: notBefore)
            } catch {
                guard let self, self.accepts(id) else { return }
                self.fail((error as? AICompositionError) ?? .frameUnavailable)
                return
            }
            guard self?.accepts(id) == true,
                  let key = self?.startAnalysis(snapshot, id: id, front: isFrontCamera, after: notBefore)
            else { return }

            do {
                let response = try await service.analyze(jpeg: snapshot.jpeg, apiKey: key)
                guard let self, self.accepts(id) else { return }
                guard !response.plans.isEmpty else { self.fail(.invalidResponse); return }
                self.deadline?.cancel()
                self.deadline = nil
                self.requestID = nil
                self.work = nil
                self.plans = response.plans
                self.selectedIndex = 0
                self.phase = .guiding
            } catch {
                guard let self, self.accepts(id) else { return }
                self.fail((error as? AICompositionError) ?? .network)
            }
        }
    }

    func grantConsentAndBegin(isFrontCamera: Bool) {
        guard phase == .awaitingConsent else { return }
        do { try consentStore.grant() }
        catch { fail(.consentStorage); return }
        begin(isFrontCamera: isFrontCamera)
    }

    func selectPlan(at index: Int) -> AICompositionPlan? {
        guard phase == .guiding, plans.indices.contains(index) else { return nil }
        selectedIndex = index
        return plans[index]
    }

    private func startAnalysis(_ snapshot: PreviewSnapshot, id: UUID, front: Bool, after timestamp: Double) -> String? {
        guard snapshot.capturedAt.isFinite, snapshot.capturedAt > timestamp, snapshot.isFrontCamera == front else {
            fail(.frameUnavailable)
            return nil
        }
        guard hasValidJPEGDimensions(snapshot.jpeg) else {
            fail(.encoding)
            return nil
        }

        do {
            guard let key = try keyStore.load(), !key.isEmpty else {
                keyConfigured = false
                fail(.keyMissing)
                return nil
            }
            keyConfigured = true
            phase = .analyzing
            scheduleDeadline(for: id, after: analysisTimeout, error: .timeout)
            return key
        } catch {
            keyConfigured = false
            fail(.keyStorage)
            return nil
        }
    }

    private func hasValidJPEGDimensions(_ jpeg: Data) -> Bool {
        guard jpeg.count >= 4, jpeg.count <= 2 * 1024 * 1024,
              jpeg.prefix(2) == Data([0xff, 0xd8]), jpeg.suffix(2) == Data([0xff, 0xd9]),
              let source = CGImageSourceCreateWithData(jpeg as CFData, nil),
              let type = CGImageSourceGetType(source), (type as String) == UTType.jpeg.identifier,
              let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [String: Any],
              let width = properties[kCGImagePropertyPixelWidth as String] as? Int,
              let height = properties[kCGImagePropertyPixelHeight as String] as? Int else { return false }
        return (1...1280).contains(width) && (1...1280).contains(height)
    }

    private func scheduleDeadline(for id: UUID, after duration: Duration, error: AICompositionError) {
        deadline?.cancel()
        deadline = Task { [weak self] in
            do { try await Task.sleep(for: duration) } catch { return }
            guard let self, self.accepts(id) else { return }
            self.fail(error)
        }
    }

    private func accepts(_ id: UUID) -> Bool {
        requestID == id && !Task.isCancelled
    }

    private func fail(_ error: AICompositionError) {
        invalidate()
        phase = .failed(error)
    }
}
