import Combine
import Foundation

enum AICompositionPhase: Equatable {
    case idle, acquiring, awaitingConfirmation, analyzing, suggestions
    case failed(AICompositionError), outdated
}

@MainActor
final class AICompositionCoordinator: ObservableObject {
    @Published private(set) var phase: AICompositionPhase = .idle
    @Published private(set) var confirmationSnapshot: PreviewSnapshot?
    @Published private(set) var plans: [AICompositionPlan] = []
    @Published private(set) var selectedIndex: Int?
    @Published private(set) var keyConfigured = false
    private let client: any AICompositionServing
    private let keyStore: any APIKeyStoring
    private let snapshots: any PreviewSnapshotProviding
    private let now: () -> Double
    private var generation: UInt64 = 0
    private var requestID: UUID?
    private var work: Task<Void, Never>?
    private var deadline: Task<Void, Never>?
    private var expiry: Task<Void, Never>?
    private var capturedAt: Double?
    private var baseline: [Float] = []
    private var lastSample: Double?
    private var differences = 0

    init(client: any AICompositionServing, keyStore: any APIKeyStoring,
         snapshots: any PreviewSnapshotProviding, now: @escaping () -> Double) {
        self.client = client; self.keyStore = keyStore; self.snapshots = snapshots; self.now = now
        refreshKeyStatus()
    }

    deinit {
        work?.cancel(); deadline?.cancel(); expiry?.cancel()
        if let requestID { snapshots.cancel(id: requestID) }
        snapshots.setFingerprintMonitoring(id: nil, handler: nil)
    }

    func refreshKeyStatus() {
        do { keyConfigured = try keyStore.load().map { !$0.isEmpty } ?? false }
        catch { keyConfigured = false; phase = .failed(.keyStorage) }
    }
    func saveKey(_ value: String) throws {
        invalidate()
        try keyStore.save(value)
        refreshKeyStatus()
    }
    func deleteKey() throws {
        invalidate()
        try keyStore.delete()
        refreshKeyStatus()
    }
    func invalidate() {
        generation &+= 1
        let oldID = requestID
        requestID = nil
        work?.cancel(); work = nil
        deadline?.cancel(); deadline = nil
        expiry?.cancel(); expiry = nil
        if let oldID { snapshots.cancel(id: oldID) }
        snapshots.setFingerprintMonitoring(id: nil, handler: nil)
        confirmationSnapshot = nil; plans = []; selectedIndex = nil
        capturedAt = nil; baseline = []; lastSample = nil; differences = 0
        phase = .idle
    }
    private func accepts(_ ticket: UInt64, _ id: UUID) -> Bool {
        generation == ticket && requestID == id && !Task.isCancelled
    }
    private func expireIfNeeded() -> Bool {
        guard let capturedAt else { return false }
        if now() - capturedAt >= 30 { markOutdated(); return true }
        return false
    }
    private func markOutdated() { invalidate(); phase = .outdated }
    private func fail(_ error: AICompositionError) { invalidate(); phase = .failed(error) }

    func begin(isFrontCamera: Bool) {
        invalidate()
        refreshKeyStatus()
        guard keyConfigured else {
            if phase != .failed(.keyStorage) { phase = .failed(.keyMissing) }
            return
        }
        let id = UUID(), ticket = generation, notBefore = now()
        requestID = id; phase = .acquiring
        let provider = snapshots
        work = Task { [weak self] in
            do {
                let snapshot = try await provider.request(id: id, isFrontCamera: isFrontCamera, after: notBefore)
                guard let self, self.accepts(ticket, id) else { return }
                guard snapshot.capturedAt.isFinite, snapshot.capturedAt >= notBefore,
                      snapshot.isFrontCamera == isFrontCamera,
                      snapshot.fingerprint.count == 64,
                      snapshot.fingerprint.allSatisfy({ $0.isFinite && $0 >= 0 && $0 <= 1 }) else {
                    self.fail(.frameUnavailable); return
                }
                self.deadline?.cancel(); self.deadline = nil; self.work = nil
                self.capturedAt = snapshot.capturedAt; self.baseline = snapshot.fingerprint
                guard !self.expireIfNeeded() else { return }
                self.confirmationSnapshot = snapshot; self.phase = .awaitingConfirmation
                provider.setFingerprintMonitoring(id: id) { [weak self] sampleID, values, timestamp in
                    Task { @MainActor [weak self] in
                        self?.observeFingerprint(values, at: timestamp, requestID: sampleID)
                    }
                }
                let remaining = max(0, 30 - (self.now() - snapshot.capturedAt))
                self.expiry = Task { [weak self] in
                    do { try await Task.sleep(for: .seconds(remaining)) }
                    catch { return }
                    guard let self, self.accepts(ticket, id) else { return }
                    _ = self.expireIfNeeded()
                }
            } catch {
                guard let self, self.accepts(ticket, id) else { return }
                self.fail((error as? AICompositionError) ?? .frameUnavailable)
            }
        }
        deadline = Task { [weak self] in
            do { try await Task.sleep(for: .seconds(2)) } catch { return }
            guard let self, self.accepts(ticket, id), self.phase == .acquiring else { return }
            self.fail(.frameUnavailable)
        }
    }

    func confirmSend() {
        guard phase == .awaitingConfirmation, !expireIfNeeded(),
              let snapshot = confirmationSnapshot, let id = requestID else { return }
        let key: String
        do {
            guard let stored = try keyStore.load(), !stored.isEmpty else { keyConfigured = false; fail(.keyMissing); return }
            key = stored
        } catch { keyConfigured = false; fail(.keyStorage); return }
        let ticket = generation, service = client
        confirmationSnapshot = nil
        phase = .analyzing
        work = Task { [weak self] in
            // This is the sole send point. The captured value is exactly the consent preview's JPEG.
            do {
                guard self?.accepts(ticket, id) == true else { return }
                let response = try await service.analyze(jpeg: snapshot.jpeg, apiKey: key)
                guard let self, self.accepts(ticket, id) else { return }
                guard !self.expireIfNeeded() else { return }
                self.deadline?.cancel(); self.deadline = nil; self.work = nil
                self.plans = response.plans; self.phase = .suggestions
            } catch {
                guard let self, self.accepts(ticket, id) else { return }
                guard !self.expireIfNeeded() else { return }
                self.fail((error as? AICompositionError) ?? .network)
            }
        }
        deadline = Task { [weak self] in
            do { try await Task.sleep(for: .seconds(40)) } catch { return }
            guard let self, self.accepts(ticket, id), self.phase == .analyzing else { return }
            if !self.expireIfNeeded() { self.fail(.timeout) }
        }
    }

    func observeFingerprint(_ values: [Float], at timestamp: Double, requestID id: UUID) {
        guard requestID == id, [.awaitingConfirmation, .analyzing, .suggestions].contains(phase),
              !expireIfNeeded(), let capturedAt, timestamp.isFinite, timestamp >= capturedAt,
              values.count == 64, values.allSatisfy({ $0.isFinite && $0 >= 0 && $0 <= 1 }),
              lastSample.map({ timestamp - $0 >= 0.5 }) ?? true else { return }
        lastSample = timestamp
        let difference = zip(values, baseline).reduce(Float(0)) { $0 + abs($1.0 - $1.1) } / 64
        differences = difference > 0.22 ? differences + 1 : 0
        if differences >= 3 { markOutdated() }
    }
    func selectPlan(at index: Int) -> AICompositionPlan? {
        guard phase == .suggestions, !expireIfNeeded(), plans.indices.contains(index) else { return nil }
        selectedIndex = index
        return plans[index]
    }
}
