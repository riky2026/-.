import Combine
import Foundation
import ImageIO
import UniformTypeIdentifiers

enum AICompositionPhase: Equatable {
    case idle, awaitingConsent, acquiring, analyzing, guiding
    case failed(AICompositionError), outdated
}

@MainActor
final class AICompositionCoordinator: ObservableObject {
    @Published private(set) var phase: AICompositionPhase = .idle
    @Published private(set) var plans: [AICompositionPlan] = []
    @Published private(set) var selectedIndex: Int?
    @Published private(set) var keyConfigured = false
    @Published private(set) var provider: AIProvider
    @Published private(set) var qwenRegion: QwenRegion
    @Published private(set) var qwenWorkspaceID: String

    var configurationReady: Bool {
        guard keyConfigured else { return false }
        guard provider == .qwen4Max else { return true }
        return (try? qwenRegion.endpoint(workspaceID: qwenWorkspaceID)) != nil
    }

    var selectedPlan: AICompositionPlan? {
        guard let selectedIndex, plans.indices.contains(selectedIndex) else { return nil }
        return plans[selectedIndex]
    }

    private let client: any AICompositionServing
    private let keyStore: any APIKeyStoring
    private let consentStore: any AIUsageConsentStoring
    private let snapshots: any PreviewSnapshotProviding
    private let now: () -> Double
    private let analysisTimeout: Duration
    private let preferences: UserDefaults
    private var requestID: UUID?
    private var work: Task<Void, Never>?
    private var deadline: Task<Void, Never>?

    init(client: any AICompositionServing, keyStore: any APIKeyStoring,
         consentStore: any AIUsageConsentStoring, snapshots: any PreviewSnapshotProviding,
         now: @escaping () -> Double, analysisTimeout: Duration = .seconds(40),
         preferences: UserDefaults = .standard) {
        self.client = client
        self.keyStore = keyStore
        self.consentStore = consentStore
        self.snapshots = snapshots
        self.now = now
        self.analysisTimeout = analysisTimeout
        self.preferences = preferences
        provider = AIProvider(rawValue: preferences.string(forKey: "ai-composition-provider") ?? "") ?? .deepSeek
        qwenRegion = QwenRegion(rawValue: preferences.string(forKey: "ai-composition-qwen-region") ?? "") ?? .beijing
        qwenWorkspaceID = preferences.string(forKey: "ai-composition-qwen-workspace") ?? ""
        refreshKeyStatus()
    }

    deinit {
        work?.cancel()
        deadline?.cancel()
        if let requestID { snapshots.cancel(id: requestID) }
    }

    func refreshKeyStatus() {
        do { keyConfigured = try keyStore.load(for: provider).map { !$0.isEmpty } ?? false }
        catch { keyConfigured = false; phase = .failed(.keyStorage) }
    }

    func selectProvider(_ value: AIProvider) {
        guard provider != value else { return }
        invalidate()
        provider = value
        preferences.set(value.rawValue, forKey: "ai-composition-provider")
        refreshKeyStatus()
    }

    func setQwenRegion(_ value: QwenRegion) {
        guard qwenRegion != value else { return }
        invalidate()
        qwenRegion = value
        preferences.set(value.rawValue, forKey: "ai-composition-qwen-region")
    }

    func setQwenWorkspaceID(_ value: String) {
        guard qwenWorkspaceID != value else { return }
        invalidate()
        qwenWorkspaceID = value
        preferences.set(value, forKey: "ai-composition-qwen-workspace")
    }

    func saveKey(_ value: String) throws {
        invalidate()
        try keyStore.save(value, for: provider)
        refreshKeyStatus()
    }

    func deleteKey() throws {
        invalidate()
        try keyStore.delete(for: provider)
        refreshKeyStatus()
    }

    func invalidate() {
        let oldID = requestID
        requestID = nil
        work?.cancel()
        work = nil
        deadline?.cancel()
        deadline = nil
        if let oldID { snapshots.cancel(id: oldID) }
        plans = []
        selectedIndex = nil
        phase = .idle
    }

    func begin(isFrontCamera: Bool) {
        invalidate()
        let settings = AICompositionServiceSettings(provider: provider, qwenRegion: qwenRegion,
                                                    qwenWorkspaceID: qwenWorkspaceID)
        if provider == .qwen4Max, (try? qwenRegion.endpoint(workspaceID: qwenWorkspaceID)) == nil {
            do { _ = try qwenRegion.endpoint(workspaceID: qwenWorkspaceID) }
            catch { fail((error as? AICompositionError) ?? .workspaceInvalid) }
            return
        }
        do {
            guard try consentStore.isGranted(for: provider) else {
                phase = .awaitingConsent
                return
            }
        } catch {
            fail(.consentStorage)
            return
        }

        let id = UUID()
        let notBefore = now()
        let provider = snapshots
        let service = client
        requestID = id
        phase = .acquiring
        scheduleDeadline(for: id, after: .seconds(2), error: .frameUnavailable)
        work = Task { [weak self] in
            guard self?.accepts(id) == true else { return }
            let snapshot: PreviewSnapshot
            do {
                snapshot = try await provider.request(id: id, isFrontCamera: isFrontCamera, after: notBefore)
            } catch {
                guard let self, self.accepts(id) else { return }
                self.fail((error as? AICompositionError) ?? .frameUnavailable)
                return
            }
            guard self?.accepts(id) == true,
                  let key = self?.startAnalysis(snapshot, id: id, front: isFrontCamera, after: notBefore,
                                                for: settings.provider)
            else { return }

            do {
                let response = try await service.analyze(jpeg: snapshot.jpeg, apiKey: key, settings: settings)
                guard let self, self.accepts(id) else { return }
                guard !response.plans.isEmpty else { self.fail(.invalidResponse); return }
                self.deadline?.cancel()
                self.deadline = nil
                self.requestID = nil
                self.work = nil
                self.plans = response.plans
                self.selectedIndex = 0
                self.phase = .guiding
            } catch {
                guard let self, self.accepts(id) else { return }
                self.fail((error as? AICompositionError) ?? .network)
            }
        }
    }

    func grantConsentAndBegin(isFrontCamera: Bool) {
        guard phase == .awaitingConsent else { return }
        do { try consentStore.grant(for: provider) }
        catch { fail(.consentStorage); return }
        begin(isFrontCamera: isFrontCamera)
    }

    func selectPlan(at index: Int) -> AICompositionPlan? {
        guard phase == .guiding, plans.indices.contains(index) else { return nil }
        selectedIndex = index
        return plans[index]
    }

    private func startAnalysis(_ snapshot: PreviewSnapshot, id: UUID, front: Bool, after timestamp: Double,
                               for provider: AIProvider) -> String? {
        guard snapshot.capturedAt.isFinite, snapshot.capturedAt > timestamp, snapshot.isFrontCamera == front else {
            fail(.frameUnavailable)
            return nil
        }
        guard hasValidJPEGDimensions(snapshot.jpeg) else {
            fail(.encoding)
            return nil
        }

        do {
            guard let key = try keyStore.load(for: provider), !key.isEmpty else {
                keyConfigured = false
                fail(.keyMissing)
                return nil
            }
            keyConfigured = true
            phase = .analyzing
            scheduleDeadline(for: id, after: analysisTimeout, error: .timeout)
            return key
        } catch {
            keyConfigured = false
            fail(.keyStorage)
            return nil
        }
    }

    private func hasValidJPEGDimensions(_ jpeg: Data) -> Bool {
        guard jpeg.count >= 4, jpeg.count <= 2 * 1024 * 1024,
              jpeg.prefix(2) == Data([0xff, 0xd8]), jpeg.suffix(2) == Data([0xff, 0xd9]),
              let source = CGImageSourceCreateWithData(jpeg as CFData, nil),
              let type = CGImageSourceGetType(source), (type as String) == UTType.jpeg.identifier,
              let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [String: Any],
              let width = properties[kCGImagePropertyPixelWidth as String] as? Int,
              let height = properties[kCGImagePropertyPixelHeight as String] as? Int else { return false }
        return (1...1280).contains(width) && (1...1280).contains(height)
    }

    private func scheduleDeadline(for id: UUID, after duration: Duration, error: AICompositionError) {
        deadline?.cancel()
        deadline = Task { [weak self] in
            do { try await Task.sleep(for: duration) } catch { return }
            guard let self, self.accepts(id) else { return }
            self.fail(error)
        }
    }

    private func accepts(_ id: UUID) -> Bool {
        requestID == id && !Task.isCancelled
    }

    private func fail(_ error: AICompositionError) {
        invalidate()
        phase = .failed(error)
    }
}
