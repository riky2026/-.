import Foundation

enum AIPlacement: String, Codable, Sendable { case center, leftThird, rightThird }
enum AIScene: String, Codable, Sendable { case automatic, portrait, landscape }

struct AICompositionPlan: Codable, Equatable, Sendable {
    let name: String
    let scene: AIScene
    let placement: AIPlacement
    let steps: [String]
}

struct AICompositionResponse: Codable, Equatable, Sendable {
    let plans: [AICompositionPlan]
}

enum AICompositionError: Error, Equatable {
    case keyMissing, keyInvalid, keyStorage, frameUnavailable, encoding
    case unauthorized, insufficientBalance, rateLimited, server, network
    case timeout, cancelled, redirected, responseTooLarge, invalidResponse

    // Local constants only: never expose an underlying Error or provider response.
    var userMessage: String {
        switch self {
        case .keyMissing: return "请先填写你的 API Key。"
        case .keyInvalid: return "API Key 格式无效，请检查。"
        case .keyStorage: return "无法访问本机密钥，请重试。"
        case .frameUnavailable: return "暂时无法获取取景图，请重试。"
        case .encoding: return "取景图无法编码，请重新截取。"
        case .unauthorized: return "API Key 无效或已失效。"
        case .insufficientBalance: return "API 余额不足，请检查账户。"
        case .rateLimited: return "请求过于频繁，请稍后重试。"
        case .server: return "分析服务暂时不可用。"
        case .network: return "网络连接失败，请稍后重试。"
        case .timeout: return "等待分析超时，请稍后重试。"
        case .cancelled: return "已停止等待本次分析。"
        case .redirected: return "服务地址发生跳转，已停止请求。"
        case .responseTooLarge: return "分析结果过大，请重新分析。"
        case .invalidResponse: return "分析结果格式无效，请重试。"
        }
    }
}

protocol AICompositionServing {
    func analyze(jpeg: Data, apiKey: String) async throws -> AICompositionResponse
}

extension AIPlacement {
    var localPlacement: PlacementMode {
        switch self {
        case .center: return .center
        case .leftThird: return .leftThird
        case .rightThird: return .rightThird
        }
    }
}

extension AIScene {
    var localScene: SceneMode {
        switch self {
        case .automatic: return .automatic
        case .portrait: return .portrait
        case .landscape: return .landscape
        }
    }
}
