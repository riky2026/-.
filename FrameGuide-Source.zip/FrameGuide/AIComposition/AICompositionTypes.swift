import Foundation

enum AIProvider: String, CaseIterable, Hashable, Sendable {
    case deepSeek
    case qwen4Max

    var title: String {
        switch self {
        case .deepSeek: return "DeepSeek"
        case .qwen4Max: return "通义千问 Qwen4-Max"
        }
    }

    var keychainService: String {
        switch self {
        case .deepSeek: return "com.frameguide.deepseek"
        case .qwen4Max: return "com.frameguide.qwen4max"
        }
    }
}

enum QwenRegion: String, CaseIterable, Hashable, Sendable {
    case beijing, singapore, virginia, frankfurt, tokyo, hongKong

    var title: String {
        switch self {
        case .beijing: return "中国（北京）"
        case .singapore: return "新加坡"
        case .virginia: return "美国（弗吉尼亚）"
        case .frankfurt: return "德国（法兰克福）"
        case .tokyo: return "日本（东京）"
        case .hongKong: return "中国香港"
        }
    }

    private var hostSuffix: String {
        switch self {
        case .beijing: return "cn-beijing.maas.aliyuncs.com"
        case .singapore: return "ap-southeast-1.maas.aliyuncs.com"
        case .virginia: return "us-east-1.maas.aliyuncs.com"
        case .frankfurt: return "eu-central-1.maas.aliyuncs.com"
        case .tokyo: return "ap-northeast-1.maas.aliyuncs.com"
        case .hongKong: return "cn-hongkong.maas.aliyuncs.com"
        }
    }

    func endpoint(workspaceID: String) throws -> URL {
        let identifier = workspaceID.trimmingCharacters(in: .whitespacesAndNewlines)
        let valid = !identifier.isEmpty && identifier.count <= 64 &&
            identifier.first != "-" && identifier.last != "-" &&
            identifier.unicodeScalars.allSatisfy { scalar in
                (65...90).contains(scalar.value) || (97...122).contains(scalar.value) ||
                (48...57).contains(scalar.value) || scalar.value == 45
            }
        guard valid else { throw identifier.isEmpty ? AICompositionError.workspaceMissing : .workspaceInvalid }
        return URL(string: "https://\(identifier).\(hostSuffix)/compatible-mode/v1/chat/completions")!
    }
}

struct AICompositionServiceSettings: Equatable, Sendable {
    var provider: AIProvider
    var qwenRegion: QwenRegion
    var qwenWorkspaceID: String

    static let deepSeek = AICompositionServiceSettings(provider: .deepSeek, qwenRegion: .beijing, qwenWorkspaceID: "")
}

enum AIPlacement: String, Codable, Sendable { case center, leftThird, rightThird }
enum AIScene: String, Codable, Sendable { case automatic, portrait, landscape }
enum AIFraming: String, Codable, Sendable { case environment, fullBody, halfBody }

struct AICompositionPlan: Codable, Equatable, Sendable {
    let name: String
    let scene: AIScene
    let placement: AIPlacement
    let framing: AIFraming
    let steps: [String]

    var localGoal: CompositionGoal {
        CompositionGoal(scene: scene.localScene, placement: placement.localPlacement, framing: framing.localFraming)
    }
}

struct AICompositionResponse: Codable, Equatable, Sendable {
    let plans: [AICompositionPlan]
}

enum AICompositionError: Error, Equatable {
    case keyMissing, keyInvalid, keyStorage, consentStorage, frameUnavailable, encoding
    case workspaceMissing, workspaceInvalid
    case unauthorized, insufficientBalance, rateLimited, server, network
    case timeout, cancelled, redirected, responseTooLarge, invalidResponse

    // Local constants only: never expose an underlying Error or provider response.
    var userMessage: String {
        switch self {
        case .keyMissing: return "请先填写你的 API Key。"
        case .keyInvalid: return "API Key 格式无效，请检查。"
        case .keyStorage: return "无法访问本机密钥，请重试。"
        case .consentStorage: return "无法保存或读取 AI 构图授权，请重试。"
        case .workspaceMissing: return "请填写阿里云百炼 Workspace ID。"
        case .workspaceInvalid: return "Workspace ID 格式无效，请检查。"
        case .frameUnavailable: return "暂时无法获取取景图，请重试。"
        case .encoding: return "取景图无法编码，请重新截取。"
        case .unauthorized: return "API Key 无效或已失效。"
        case .insufficientBalance: return "API 余额不足，请检查账户。"
        case .rateLimited: return "请求过于频繁，请稍后重试。"
        case .server: return "分析服务暂时不可用。"
        case .network: return "网络连接失败，请稍后重试。"
        case .timeout: return "等待分析超时，请稍后重试。"
        case .cancelled: return "已停止等待本次分析。"
        case .redirected: return "服务地址发生跳转，已停止请求。"
        case .responseTooLarge: return "分析结果过大，请重新分析。"
        case .invalidResponse: return "分析结果格式无效，请重试。"
        }
    }
}

protocol AICompositionServing {
    func analyze(jpeg: Data, apiKey: String, settings: AICompositionServiceSettings) async throws -> AICompositionResponse
}

extension AIPlacement {
    var localPlacement: PlacementMode {
        switch self {
        case .center: return .center
        case .leftThird: return .leftThird
        case .rightThird: return .rightThird
        }
    }
}

extension AIScene {
    var localScene: SceneMode {
        switch self {
        case .automatic: return .automatic
        case .portrait: return .portrait
        case .landscape: return .landscape
        }
    }
}

extension AIFraming {
    var localFraming: FramingScale {
        switch self {
        case .environment: return .environment
        case .fullBody: return .fullBody
        case .halfBody: return .halfBody
        }
    }
}
