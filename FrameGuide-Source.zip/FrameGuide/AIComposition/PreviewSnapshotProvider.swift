import CoreImage
import CoreVideo
import Foundation
import ImageIO

struct PreviewSnapshot: Sendable {
    let jpeg: Data
    let capturedAt: Double
    let isFrontCamera: Bool
}

protocol PreviewSnapshotProviding {
    func request(id: UUID, isFrontCamera: Bool, after timestamp: Double) async throws -> PreviewSnapshot
    func cancel(id: UUID)
}

// submit must run synchronously on the serial video callback, never on the main queue.
// Only request metadata and continuations survive that callback.
final class PreviewSnapshotProvider: PreviewSnapshotProviding, @unchecked Sendable {
    private struct Request {
        let id: UUID
        let isFrontCamera: Bool
        let notBefore: Double
        var continuation: CheckedContinuation<PreviewSnapshot, Error>?
        var timeout: DispatchWorkItem?
    }
    private let lock = NSLock()
    private var pending: Request?
    private var encoding: Request?
    // Cancellation can precede continuation installation. Reservations expire after the admission window.
    // A single cleanup job also releases them if no more frames/requests arrive. IDs are never reused.
    private var cancelledBeforeInstall: [UUID: UInt64] = [:]
    private var cancellationCleanupScheduled = false
    private let encode: (CIImage, CGImagePropertyOrientation, Bool) throws -> Data

    init(encode: @escaping (CIImage, CGImagePropertyOrientation, Bool) throws -> Data = {
        try SnapshotJPEGCodec.encode($0, orientation: $1, mirrored: $2)
    }) {
        self.encode = encode
    }

    func request(id: UUID, isFrontCamera: Bool, after timestamp: Double) async throws -> PreviewSnapshot {
        try await withTaskCancellationHandler(operation: {
            try await withCheckedThrowingContinuation { continuation in
                install(id: id, front: isFrontCamera, timestamp: timestamp,
                        taskCancelled: Task.isCancelled, continuation: continuation)
            }
        }, onCancel: { self.cancel(id: id) })
    }

    private func install(id: UUID, front: Bool, timestamp: Double, taskCancelled: Bool,
                         continuation: CheckedContinuation<PreviewSnapshot, Error>) {
        lock.lock()
        let now = DispatchTime.now().uptimeNanoseconds
        let wasCancelled = cancelledBeforeInstall.removeValue(forKey: id).map { $0 > now } ?? false
        guard !taskCancelled, !wasCancelled else {
            lock.unlock(); continuation.resume(throwing: AICompositionError.cancelled); return
        }
        guard timestamp.isFinite else {
            lock.unlock(); continuation.resume(throwing: AICompositionError.frameUnavailable); return
        }
        let old = pending
        pending = nil
        old?.timeout?.cancel()
        // Cancellation of an in-flight codec cannot release its pixel buffer/busy admission early.
        if var active = encoding {
            let activeContinuation = active.continuation
            active.continuation = nil
            encoding = active
            lock.unlock()
            old?.continuation?.resume(throwing: AICompositionError.cancelled)
            activeContinuation?.resume(throwing: AICompositionError.cancelled)
            continuation.resume(throwing: AICompositionError.frameUnavailable)
            return
        }
        let timeout = DispatchWorkItem { [weak self] in self?.expire(id: id) }
        pending = Request(id: id, isFrontCamera: front, notBefore: timestamp,
                          continuation: continuation, timeout: timeout)
        lock.unlock()
        old?.continuation?.resume(throwing: AICompositionError.cancelled)
        DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + 2, execute: timeout)
    }

    func cancel(id: UUID) {
        lock.lock()
        var continuation: CheckedContinuation<PreviewSnapshot, Error>?
        if let request = pending, request.id == id {
            pending = nil
            request.timeout?.cancel()
            continuation = request.continuation
        } else if var request = encoding, request.id == id {
            continuation = request.continuation
            request.continuation = nil
            encoding = request
        } else {
            // Repeated terminal invalidation cannot prolong a reservation indefinitely.
            if cancelledBeforeInstall[id] == nil {
                cancelledBeforeInstall[id] = DispatchTime.now().uptimeNanoseconds + 2_000_000_000
            }
            scheduleCancellationCleanupIfNeeded()
        }
        lock.unlock()
        continuation?.resume(throwing: AICompositionError.cancelled)
    }

    // Read-only admission state used by the native fixture before submitting a frame.
    var hasPendingRequest: Bool {
        lock.lock(); defer { lock.unlock() }
        return pending != nil
    }

    // Read-only numeric diagnostic used by the native lifecycle fixture; no pruning hides a missed cleanup.
    var cancellationReservationCount: Int {
        lock.lock(); defer { lock.unlock() }
        return cancelledBeforeInstall.count
    }

    // Caller holds lock. At most one expiry job exists, independent of cancellation volume.
    private func scheduleCancellationCleanupIfNeeded() {
        guard !cancellationCleanupScheduled, let deadline = cancelledBeforeInstall.values.min() else { return }
        cancellationCleanupScheduled = true
        DispatchQueue.global(qos: .utility).asyncAfter(deadline: DispatchTime(uptimeNanoseconds: deadline)) { [weak self] in
            guard let self else { return }
            self.lock.lock()
            let now = DispatchTime.now().uptimeNanoseconds
            self.cancelledBeforeInstall = self.cancelledBeforeInstall.filter { $0.value > now }
            self.cancellationCleanupScheduled = false
            self.scheduleCancellationCleanupIfNeeded()
            self.lock.unlock()
        }
    }

    private func expire(id: UUID) {
        lock.lock()
        guard let request = pending, request.id == id else { lock.unlock(); return }
        pending = nil
        lock.unlock()
        request.continuation?.resume(throwing: AICompositionError.frameUnavailable)
    }

    func submit(_ pixels: CVPixelBuffer, size: CGSize,
                orientation: CGImagePropertyOrientation, timestamp: Double, isFrontCamera: Bool) {
        lock.lock()
        guard let request = pending, encoding == nil, request.isFrontCamera == isFrontCamera,
              timestamp.isFinite, timestamp > request.notBefore,
              size.width.isFinite, size.height.isFinite, size.width > 0, size.height > 0,
              size.width == CGFloat(CVPixelBufferGetWidth(pixels)),
              size.height == CGFloat(CVPixelBufferGetHeight(pixels)) else { lock.unlock(); return }
        pending = nil
        request.timeout?.cancel()
        encoding = request
        lock.unlock()

        // No dispatch and no stored CIImage: CVPixelBuffer cannot escape its video callback.
        autoreleasepool {
            let result: Result<PreviewSnapshot, Error>
            do {
                let jpeg = try encode(CIImage(cvPixelBuffer: pixels), orientation, isFrontCamera)
                result = .success(PreviewSnapshot(jpeg: jpeg, capturedAt: timestamp,
                                                 isFrontCamera: isFrontCamera))
            } catch { result = .failure(AICompositionError.encoding) }

            lock.lock()
            let continuation = encoding?.id == request.id ? encoding?.continuation : nil
            encoding = nil
            lock.unlock()
            continuation?.resume(with: result)
        }
    }
}
