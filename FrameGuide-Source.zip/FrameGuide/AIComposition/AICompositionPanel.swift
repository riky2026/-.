import SwiftUI

enum CameraSheet: String, Identifiable {
    case settings, aiPlans
    var id: String { rawValue }
}

@MainActor
struct AICompositionPanel: View {
    @ObservedObject var ai: AICompositionCoordinator
    let onAnalyze: () -> Void
    let onCancel: () -> Void
    let onGrantConsent: () -> Void
    let onEnableLocalGuidance: () -> Void
    let onApplyDefaultPlan: () -> Void
    let onConfigureKey: () -> Void
    @Binding var sheet: CameraSheet?
    @State private var showsConsent = false
    var canAnalyze: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            switch ai.phase {
            case .acquiring, .analyzing:
                HStack {
                    ProgressView(ai.phase == .acquiring ? "正在截取取景图…" : "正在分析构图…")
                    Spacer()
                    Button("取消", action: onCancel).frame(minHeight: 44)
                }
            case .idle, .awaitingConsent:
                analyzeButton("AI 构图")
            case .guiding:
                Button("方案") { sheet = .aiPlans }.frame(minHeight: 44)
                if let plan = ai.selectedPlan {
                    Text("已选：" + plan.name).font(.caption)
                }
            case .failed(let error):
                Text(error.userMessage).font(.caption)
                analyzeButton(error == .keyMissing ? "配置 API Key" : "重新分析")
            case .outdated:
                Text("请重新分析当前取景").font(.caption)
                analyzeButton("重新分析")
            }
        }
        .font(.subheadline).padding(.horizontal, 14)
        .background(Theme.panel, in: RoundedRectangle(cornerRadius: 14))
        .onChange(of: ai.phase) { _, phase in
            showsConsent = phase == .awaitingConsent
            if phase == .guiding { onApplyDefaultPlan() }
            if phase != .guiding, sheet == .aiPlans { sheet = nil }
        }
        .alert("启用 DeepSeek AI 构图", isPresented: $showsConsent) {
            Button("启用并分析", action: onGrantConsent)
            Button("取消", role: .cancel, action: onCancel)
        } message: {
            Text("点按「启用并分析」立即发送一张当前取景图给 DeepSeek。以后每次主动分析只发送一张，并使用你账户的 API 配额和余额。其余预览帧和拍摄的照片在本机处理。DeepSeek 按其现行政策处理请求。")
        }
    }

    private func analyzeButton(_ title: String) -> some View {
        Button {
            if ai.keyConfigured { onAnalyze() }
            else {
                onEnableLocalGuidance()
                onConfigureKey()
            }
        } label: {
            Label(title, systemImage: "sparkles").frame(minHeight: 44)
        }.disabled(ai.keyConfigured && !canAnalyze)
    }
}

@MainActor
struct AICompositionSheet: View {
    @ObservedObject var ai: AICompositionCoordinator
    let onSelect: (Int) -> Void
    let onReanalyze: () -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    if ai.phase == .guiding {
                        ForEach(Array(ai.plans.prefix(3).enumerated()), id: \.offset) { index, plan in
                            VStack(alignment: .leading, spacing: 8) {
                                Button {
                                    onSelect(index)
                                    dismiss()
                                } label: {
                                    Label(plan.name, systemImage: ai.selectedIndex == index ? "checkmark.circle.fill" : "circle")
                                        .frame(minHeight: 44)
                                }
                                .accessibilityLabel("\(plan.name)，\(plan.scene.localScene.title)，\(ai.selectedIndex == index ? "已选" : "未选")")
                                if index == ai.selectedIndex {
                                    ForEach(Array(plan.steps.enumerated()), id: \.offset) { step, text in
                                        Text("\(step + 1). \(text)").font(.callout)
                                    }
                                }
                            }
                        }
                        Button("重新分析", action: onReanalyze).frame(minHeight: 44)
                    }
                }.padding()
            }
            .navigationTitle("构图方案")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) {
                Button("关闭") { dismiss() }.frame(minHeight: 44)
            } }
        }
        .preferredColorScheme(.dark)
    }
}
