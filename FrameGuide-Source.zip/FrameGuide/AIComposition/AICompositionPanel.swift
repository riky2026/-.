import SwiftUI

enum CameraSheet: String, Identifiable {
    case settings, aiPlans
    var id: String { rawValue }
}

@MainActor
struct AICompositionPanel: View {
    @ObservedObject var ai: AICompositionCoordinator
    let onAnalyze: () -> Void
    let onCancel: () -> Void
    let onGrantConsent: () -> Void
    let onDisable: () -> Void
    let onSelectPlan: (Int) -> Void
    let onApplyDefaultPlan: () -> Void
    let onConfigureKey: () -> Void
    @Binding var sheet: CameraSheet?
    @State private var showsConsent = false
    var canAnalyze: Bool
    var isEnabled: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 8) {
                Toggle(isOn: Binding(get: { isEnabled }, set: { enabled in
                    if enabled { onAnalyze() } else { onDisable() }
                })) {
                    VStack(alignment: .leading, spacing: 2) {
                        Label("智能构图", systemImage: "sparkles")
                        if isEnabled { Text(status).font(.caption).foregroundStyle(.secondary) }
                    }
                }
                .disabled(!canAnalyze)
                if isEnabled {
                    if ai.plans.count > 1, ai.phase == .guiding {
                        Button {
                            onSelectPlan(((ai.selectedIndex ?? 0) + 1) % ai.plans.count)
                        } label: { Image(systemName: "arrow.triangle.2.circlepath").frame(width: 44, height: 44) }
                        .accessibilityLabel("换一个构图方案")
                    }
                    Menu {
                        if ai.keyConfigured {
                            Button("重新分析当前画面", action: onAnalyze).disabled(!canAnalyze || isAnalyzing)
                        }
                        if ai.phase == .guiding { Button("查看方案说明") { sheet = .aiPlans } }
                        if isAnalyzing { Button("停止本次分析", action: onCancel) }
                        Button("配置 \(ai.provider.title)", action: onConfigureKey)
                    } label: { Image(systemName: "ellipsis").frame(width: 44, height: 44) }
                    .accessibilityLabel("构图选项")
                }
            }
            if isEnabled, case .failed(let error) = ai.phase {
                Text(error.userMessage).font(.caption).foregroundStyle(.secondary)
            }
        }
        .font(.subheadline).padding(.horizontal, 14).padding(.vertical, 4)
        .background(Theme.panel, in: RoundedRectangle(cornerRadius: 14))
        .onChange(of: ai.phase) { _, phase in
            showsConsent = phase == .awaitingConsent
            if phase == .guiding { onApplyDefaultPlan() }
            if phase != .guiding, sheet == .aiPlans { sheet = nil }
        }
        .alert("启用 \(ai.provider.title) AI 构图", isPresented: $showsConsent) {
            Button("启用并分析", action: onGrantConsent)
            Button("取消", role: .cancel, action: onCancel)
        } message: {
            Text(consentMessage)
        }
    }

    private var isAnalyzing: Bool { ai.phase == .acquiring || ai.phase == .analyzing }

    private var status: String {
        switch ai.phase {
        case .acquiring, .analyzing: return "正在分析当前取景…"
        case .guiding: return ai.selectedPlan?.name ?? "实时引导中"
        case .awaitingConsent: return "等待启用 \(ai.provider.title)"
        default: return "本地取景引导"
        }
    }

    private var consentMessage: String {
        let service = ai.provider == .qwen4Max ? "阿里云百炼" : "DeepSeek"
        return "点按「启用并分析」立即发送一张当前取景图给\(service)。以后每次主动分析只发送一张，并使用所选账户的 API 配额和余额。其余预览帧和拍摄的照片在本机处理。\(service) 按其现行政策处理请求。"
    }
}

@MainActor
struct AICompositionSheet: View {
    @ObservedObject var ai: AICompositionCoordinator
    let onSelect: (Int) -> Void
    let onReanalyze: () -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    if ai.phase == .guiding {
                        ForEach(Array(ai.plans.prefix(3).enumerated()), id: \.offset) { index, plan in
                            VStack(alignment: .leading, spacing: 8) {
                                Button {
                                    onSelect(index)
                                    dismiss()
                                } label: {
                                    Label(plan.name, systemImage: ai.selectedIndex == index ? "checkmark.circle.fill" : "circle")
                                        .frame(minHeight: 44)
                                }
                                .accessibilityLabel("\(plan.name)，\(plan.scene.localScene.title)，\(ai.selectedIndex == index ? "已选" : "未选")")
                                if index == ai.selectedIndex {
                                    ForEach(Array(plan.steps.enumerated()), id: \.offset) { step, text in
                                        Text("\(step + 1). \(text)").font(.callout)
                                    }
                                }
                            }
                        }
                        Button("重新分析", action: onReanalyze).frame(minHeight: 44)
                    }
                }.padding()
            }
            .navigationTitle("构图方案")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) {
                Button("关闭") { dismiss() }.frame(minHeight: 44)
            } }
        }
        .preferredColorScheme(.dark)
    }
}
