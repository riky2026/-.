import SwiftUI
import UIKit

enum CameraSheet: String, Identifiable {
    case settings, aiConfirmation, aiPlans
    var id: String { rawValue }
}

@MainActor
struct AICompositionPanel: View {
    @ObservedObject var ai: AICompositionCoordinator
    let onAnalyze: () -> Void
    let onSelect: (Int) -> Void
    let onConfigureKey: () -> Void
    @Binding var sheet: CameraSheet?
    var canAnalyze: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            switch ai.phase {
            case .acquiring, .analyzing:
                HStack {
                    ProgressView(ai.phase == .acquiring ? "正在截取取景图…" : "正在分析构图…")
                    Spacer()
                    Button("取消") { ai.invalidate() }.frame(minHeight: 44)
                }
            case .awaitingConfirmation:
                Button("查看取景图并确认发送") { sheet = .aiConfirmation }.frame(minHeight: 44)
            case .suggestions:
                Button("查看构图方案") { sheet = .aiPlans }.frame(minHeight: 44)
                if let index = ai.selectedIndex, ai.plans.indices.contains(index) {
                    Text("已选：" + ai.plans[index].name).font(.caption)
                }
            case .idle:
                analyzeButton("AI 构图")
            case .failed(let error):
                Text(error.userMessage).font(.caption)
                analyzeButton(error == .keyMissing ? "配置 API Key" : "重新分析")
            case .outdated:
                Text("画面已明显变化或建议已过期，请重新分析").font(.caption)
                analyzeButton("重新分析")
            }
        }
        .font(.subheadline).padding(.horizontal, 14)
        .background(Theme.panel, in: RoundedRectangle(cornerRadius: 14))
        .onChange(of: ai.phase) { _, phase in
            if phase == .awaitingConfirmation { sheet = .aiConfirmation }
            else if sheet == .aiConfirmation { sheet = nil }
            if phase != .suggestions, sheet == .aiPlans { sheet = nil }
        }
    }
    private func analyzeButton(_ title: String) -> some View {
        Button { if ai.keyConfigured { onAnalyze() } else { onConfigureKey() } } label: {
            Label(title, systemImage: "sparkles").frame(minHeight: 44)
        }.disabled(ai.keyConfigured && !canAnalyze)
    }
}

@MainActor
struct AICompositionSheet: View {
    @ObservedObject var ai: AICompositionCoordinator
    let onSelect: (Int) -> Void
    let onReanalyze: () -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    if ai.phase == .awaitingConfirmation, let snapshot = ai.confirmationSnapshot {
                        if let image = UIImage(data: snapshot.jpeg) {
                            Image(uiImage: image).resizable().scaledToFit().frame(maxHeight: 280)
                                .accessibilityLabel("即将发送的取景快照")
                        }
                        Text("确认后将这张去除位置及原始照片元数据的 JPEG 与构图提示发送给 DeepSeek，以本机 Keychain 中的 API Key 认证，使用你账户的配额和余额。普通预览和拍照不会自动上传。供应商处理依其政策，不承诺零保留或零训练。")
                        Button("发送并分析") { ai.confirmSend() }
                            .buttonStyle(.borderedProminent).frame(minHeight: 44)
                        Button("取消") { ai.invalidate(); dismiss() }.frame(minHeight: 44)
                    } else if ai.phase == .suggestions {
                        Text("文字建议供参考；本地引导重新识别主体。画面变化检测是保守启发式，不代表跟踪。")
                            .font(.caption).foregroundStyle(.secondary)
                        ForEach(Array(ai.plans.prefix(3).enumerated()), id: \.offset) { index, plan in
                            VStack(alignment: .leading, spacing: 8) {
                                Button {
                                    onSelect(index)
                                    dismiss()
                                } label: {
                                    Label(plan.name, systemImage: ai.selectedIndex == index ? "checkmark.circle.fill" : "circle")
                                        .frame(minHeight: 44)
                                }
                                .accessibilityLabel("\(plan.name)，\(plan.scene.localScene.title)，\(ai.selectedIndex == index ? "已选" : "未选")")
                                if index == (ai.selectedIndex ?? 0) {
                                    ForEach(Array(plan.steps.enumerated()), id: \.offset) { step, text in
                                        Text("\(step + 1). \(text)").font(.callout)
                                    }
                                }
                            }
                        }
                        Button("重新分析") { onReanalyze() }.frame(minHeight: 44)
                    }
                }.padding()
            }
            .navigationTitle(ai.phase == .awaitingConfirmation ? "确认发送取景图" : "构图方案")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) {
                Button("关闭") { if ai.phase == .awaitingConfirmation { ai.invalidate() }; dismiss() }.frame(minHeight: 44)
            } }
        }
        .preferredColorScheme(.dark)
    }
}
