import SwiftUI

@MainActor
struct CameraSettingsView: View {
    @ObservedObject var model: CameraViewModel
    @ObservedObject var ai: AICompositionCoordinator
    @State private var keyInput = ""
    @State private var keyMessage: String?
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("构图") {
                    Picker("主体位置", selection: $model.placement) {
                        ForEach(PlacementMode.allCases, id: \.self) { Text($0.title).tag($0) }
                    }
                    Toggle("构图引导", isOn: $model.guidanceEnabled)
                    Toggle("三分辅助线", isOn: $model.showsGrid)
                    Toggle("就绪触感", isOn: $model.hapticsEnabled)
                }
                Section("DeepSeek AI 构图") {
                    Text(ai.keyConfigured ? "已保存到本机" : "未配置")
                    SecureField("API Key", text: $keyInput)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .privacySensitive()
                        .accessibilityLabel("DeepSeek API Key")
                    Button("保存到本机 Keychain") {
                        defer { keyInput = "" }
                        do { try ai.saveKey(keyInput); keyMessage = "已保存到本机" }
                        catch { keyMessage = (error as? AICompositionError)?.userMessage ?? AICompositionError.keyStorage.userMessage }
                    }.disabled(keyInput.isEmpty).frame(minHeight: 44)
                    Button("删除 API Key", role: .destructive) {
                        keyInput = ""
                        do { try ai.deleteKey(); keyMessage = "已删除本机凭据；不会撤回已发送请求" }
                        catch { keyMessage = AICompositionError.keyStorage.userMessage }
                    }.disabled(!ai.keyConfigured).frame(minHeight: 44)
                    if let keyMessage { Text(keyMessage).font(.footnote) }
                    Text("仅存本机 Keychain，不随照片分享。AI 分析使用你账户的 API 配额和余额；删除只清除本机凭据，不撤回已发送请求。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("拍摄") {
                    Picker("闪光灯", selection: $model.flash) {
                        ForEach(FlashSetting.allCases, id: \.self) { Text($0.title).tag($0) }
                    }.disabled(model.isFrontCamera)
                    Text("前置镜头使用镜像预览与镜像照片。构图线仅显示在取景器中。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section {
                    Text("实时引导在设备本地进行，普通预览和拍照不自动上传。确认 AI 构图后，才发送一张去除位置及原始照片元数据的 JPEG 与提示给 DeepSeek，以本机 Keychain 中的 API Key 认证。供应商处理依其政策，不承诺零保留或零训练。会话照片在本机暂存，退出后不保留；删除 Key 仅清除本机凭据，不撤回已发送请求。其他设置仅在本次会话有效。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .tint(Theme.accent)
            .navigationTitle("相机设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() }.frame(minHeight: 44) } }
        }
        .preferredColorScheme(.dark)
        .onAppear { ai.refreshKeyStatus() }
        .onDisappear { keyInput = "" }
    }
}
