import SwiftUI

@MainActor
struct CameraSettingsView: View {
    @ObservedObject var model: CameraViewModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("构图") {
                    Picker("主体位置", selection: $model.placement) {
                        ForEach(PlacementMode.allCases, id: \.self) { Text($0.title).tag($0) }
                    }
                    Toggle("构图引导", isOn: $model.guidanceEnabled)
                    Toggle("三分辅助线", isOn: $model.showsGrid)
                    Toggle("就绪触感", isOn: $model.hapticsEnabled)
                }
                Section("拍摄") {
                    Picker("闪光灯", selection: $model.flash) {
                        ForEach(FlashSetting.allCases, id: \.self) { Text($0.title).tag($0) }
                    }.disabled(model.isFrontCamera)
                    Text("前置镜头使用镜像预览与镜像照片。构图线仅显示在取景器中。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section {
                    Text("画面分析在设备本地进行。照片在本次会话中暂存，退出应用后不会保留。设置仅在本次会话有效。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .tint(Theme.accent)
            .navigationTitle("相机设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() }.frame(minHeight: 44) } }
        }
        .preferredColorScheme(.dark)
    }
}
