import SwiftUI

@MainActor
struct CameraSettingsView: View {
    @ObservedObject var model: CameraViewModel
    @ObservedObject var ai: AICompositionCoordinator
    @State private var keyInput = ""
    @State private var keyMessage: String?
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("构图") {
                    Picker("主体位置", selection: $model.placement) {
                        ForEach(PlacementMode.allCases, id: \.self) { Text($0.title).tag($0) }
                    }
                    Toggle("构图引导", isOn: $model.guidanceEnabled)
                    Toggle("三分辅助线", isOn: $model.showsGrid)
                    Toggle("就绪触感", isOn: $model.hapticsEnabled)
                }
                Section("AI 构图") {
                    Picker("AI 服务", selection: Binding(get: { ai.provider }, set: ai.selectProvider)) {
                        ForEach(AIProvider.allCases, id: \.self) { provider in
                            Text(provider.title).tag(provider)
                        }
                    }
                    Text(ai.keyConfigured ? "已保存到本机" : "未配置")
                    if let configurationError = ai.configurationError {
                        Text(configurationError.userMessage).font(.footnote).foregroundStyle(.red)
                    }
                    if ai.provider == .qwen4Max {
                        Picker("百炼地域", selection: Binding(get: { ai.qwenRegion }, set: ai.setQwenRegion)) {
                            ForEach(QwenRegion.allCases, id: \.self) { region in
                                Text(region.title).tag(region)
                            }
                        }
                        TextField("Workspace ID", text: Binding(get: { ai.qwenWorkspaceID }, set: ai.setQwenWorkspaceID))
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                            .accessibilityLabel("阿里云百炼 Workspace ID")
                        Text("在阿里云百炼控制台的「工作空间详情」查看。地域必须与 API Key 所属地域一致。")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    SecureField("\(ai.provider.title) API Key", text: $keyInput)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .privacySensitive()
                        .accessibilityLabel("\(ai.provider.title) API Key")
                    Button("保存到本机 Keychain") {
                        defer { keyInput = "" }
                        do { try ai.saveKey(keyInput); keyMessage = "已保存到本机" }
                        catch { keyMessage = (error as? AICompositionError)?.userMessage ?? AICompositionError.keyStorage.userMessage }
                    }.disabled(keyInput.isEmpty).frame(minHeight: 44)
                    Button("删除 API Key", role: .destructive) {
                        keyInput = ""
                        do { try ai.deleteKey(); keyMessage = "已删除本机凭据；不会撤回已发送请求" }
                        catch { keyMessage = AICompositionError.keyStorage.userMessage }
                    }.disabled(!ai.keyConfigured).frame(minHeight: 44)
                    if let keyMessage { Text(keyMessage).font(.footnote) }
                    Text("DeepSeek 与 Qwen4-Max 的密钥分别保存在本机 Keychain。AI 分析使用所选服务商账户的 API 配额和余额；删除只清除本机凭据，不撤回已发送请求。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("拍摄") {
                    Picker("闪光灯", selection: $model.flash) {
                        ForEach(FlashSetting.allCases, id: \.self) { Text($0.title).tag($0) }
                    }.disabled(model.isFrontCamera)
                    Text("前置镜头使用镜像预览与镜像照片。构图线仅显示在取景器中。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section {
                    Text("首次同意后立即开始分析。每次主动开启 AI 分析都会向所选服务商发送一张去除位置及原始照片元数据的当前取景 JPEG 和构图提示。其余预览帧和拍摄的照片均在本机处理。没有 API Key 或网络时，仍可使用本地构图和快门。AI 服务选择和百炼连接设置保存在本机 Keychain；取景偏好仅在本次会话有效。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .tint(Theme.accent)
            .navigationTitle("相机设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() }.frame(minHeight: 44) } }
        }
        .preferredColorScheme(.dark)
        .onAppear { ai.refreshKeyStatus() }
        .onDisappear { keyInput = "" }
    }
}
