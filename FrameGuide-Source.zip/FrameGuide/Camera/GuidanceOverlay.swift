import SwiftUI

/// Display-only marks in preview coordinates. They are never captured in a photo.
struct GuidanceOverlay: View {
    let result: GuidanceResult?
    let showsGrid: Bool
    let rollRadians: Double?
    var isFrontCamera = false
    var guidanceEnabled = false
    var analysisMessage: String?
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private var ready: Bool { result?.phase == .ready }
    private var cueColor: Color { ready ? Theme.accent : .yellow }

    var body: some View {
        GeometryReader { geometry in
            let size = geometry.size
            ZStack {
                if showsGrid { grid(size: size) }
                if let result, result.phase != .searching,
                   let bounds = result.subject?.clamped() {
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(.white.opacity(0.65), lineWidth: 1)
                        .frame(width: size.width * bounds.width, height: size.height * bounds.height)
                        .position(x: size.width * bounds.center.x, y: size.height * bounds.center.y)
                    if let target = result.targetBounds?.clamped() {
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(cueColor.opacity(0.6), style: StrokeStyle(lineWidth: 1, dash: [5, 5]))
                            .frame(width: size.width * target.width, height: size.height * target.height)
                            .position(x: size.width * target.center.x, y: size.height * target.center.y)
                    }
                }
                if let aim = result?.cameraAim(isFrontCamera: isFrontCamera) {
                    aimingCue(at: aim, size: size)
                }
                VStack(spacing: 8) {
                    Spacer(minLength: 0)
                    if let roll = rollRadians, roll.isFinite { level(roll: roll) }
                    if result?.subjectLocked == true {
                        Label("主体已锁定", systemImage: "lock.fill")
                            .font(.caption.weight(.semibold))
                            .padding(.horizontal, 10).padding(.vertical, 6)
                            .background(.black.opacity(0.68), in: Capsule())
                    }
                    if guidanceEnabled {
                        Label(instruction, systemImage: instructionSymbol)
                            .font(.subheadline.weight(.semibold))
                            .multilineTextAlignment(.center)
                            .foregroundStyle(ready ? Theme.accent : .white)
                            .padding(.horizontal, 12).padding(.vertical, 9)
                            .background(.black.opacity(0.7), in: RoundedRectangle(cornerRadius: 12))
                    }
                }
                .padding(12)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(guidanceEnabled ? instruction : "构图辅助线")
            .accessibilityAddTraits(.updatesFrequently)
        }
        .clipped()
        .allowsHitTesting(false)
    }

    private func grid(size: CGSize) -> some View {
        Path { path in
            for fraction in [1.0 / 3.0, 2.0 / 3.0] {
                let x = size.width * fraction
                let y = size.height * fraction
                path.move(to: CGPoint(x: x, y: 0))
                path.addLine(to: CGPoint(x: x, y: size.height))
                path.move(to: CGPoint(x: 0, y: y))
                path.addLine(to: CGPoint(x: size.width, y: y))
            }
        }.stroke(.white.opacity(0.23), lineWidth: 0.5)
    }

    private func aimingCue(at aim: NormalizedPoint, size: CGSize) -> some View {
        let center = CGPoint(x: size.width / 2, y: size.height / 2)
        let destination = CGPoint(x: size.width * aim.x, y: size.height * aim.y)
        let aligned = aim.x == 0.5 && aim.y == 0.5
        return ZStack {
            if !aligned {
                Path { path in
                    path.move(to: center)
                    path.addLine(to: destination)
                }.stroke(cueColor.opacity(0.8), style: StrokeStyle(lineWidth: 2, dash: [4, 5]))
            }
            ZStack {
                Circle().fill(.black.opacity(0.18))
                Circle().stroke(cueColor, lineWidth: 3)
                if result?.phase == .steady || ready {
                    Circle().trim(from: 0, to: result?.stabilityProgress ?? 0)
                        .stroke(Theme.accent, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                }
            }
            .frame(width: 54, height: 54)
            .position(destination)
            .animation(reduceMotion ? nil : .linear(duration: 0.16), value: aim)
            Image(systemName: ready ? "checkmark" : "plus")
                .font(.system(size: 22, weight: .medium))
                .foregroundStyle(ready ? Theme.accent : .white)
                .frame(width: 32, height: 32)
                .position(center)
        }
        .shadow(color: .black.opacity(0.65), radius: 3)
    }

    private func level(roll: Double) -> some View {
        ZStack {
            Capsule().fill(.white.opacity(0.4)).frame(width: 60, height: 1)
            Capsule().fill(abs(roll) <= .pi / 60 ? Theme.accent : Theme.ink)
                .frame(width: 40, height: 3)
                .rotationEffect(.radians(-roll))
        }.frame(width: 70, height: 20)
    }

    private var instruction: String {
        if analysisMessage != nil { return "画面分析暂不可用，可继续拍摄" }
        return result?.cameraInstruction(isFrontCamera: isFrontCamera) ?? "对准要拍的主体，也可轻点选择"
    }

    private var instructionSymbol: String {
        switch result?.cameraDirection(isFrontCamera: isFrontCamera) {
        case .left: return "arrow.left"
        case .right: return "arrow.right"
        case .up: return "arrow.up"
        case .down: return "arrow.down"
        case .closer: return "plus.magnifyingglass"
        case .farther: return "minus.magnifyingglass"
        default: return ready ? "checkmark.circle.fill" : "scope"
        }
    }
}
