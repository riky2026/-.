import SwiftUI

/// Display-only geometry; none of these marks enter the photo output.
struct GuidanceOverlay: View {
    let result: GuidanceResult?
    let showsGrid: Bool
    let rollRadians: Double?
    private var tint: Color { result?.phase == .ready ? Theme.accent : Theme.ink }

    var body: some View {
        GeometryReader { geometry in
            let size = geometry.size
            ZStack {
                if showsGrid {
                    Path { path in
                        for fraction in [1.0 / 3.0, 2.0 / 3.0] {
                            let x = size.width * fraction
                            let y = size.height * fraction
                            path.move(to: CGPoint(x: x, y: 0))
                            path.addLine(to: CGPoint(x: x, y: size.height))
                            path.move(to: CGPoint(x: 0, y: y))
                            path.addLine(to: CGPoint(x: size.width, y: y))
                        }
                    }.stroke(.white.opacity(0.28), lineWidth: 0.5)
                }
                if let bounds = result?.subject {
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(tint, style: StrokeStyle(lineWidth: 2, dash: result?.phase == .searching ? [5, 5] : []))
                        .frame(width: size.width * bounds.width, height: size.height * bounds.height)
                        .position(x: size.width * bounds.center.x, y: size.height * bounds.center.y)
                        .shadow(color: .black.opacity(0.5), radius: 2)
                }
                if let target = result?.target {
                    Image(systemName: result?.phase == .ready ? "checkmark.circle.fill" : "plus.circle")
                        .font(.system(size: 26, weight: .light)).foregroundStyle(tint)
                        .shadow(color: .black, radius: 3)
                        .position(x: size.width * target.x, y: size.height * target.y)
                }
                if let roll = rollRadians, roll.isFinite {
                    VStack {
                        Spacer()
                        ZStack {
                            Capsule().fill(.white.opacity(0.4)).frame(width: 60, height: 1)
                            Capsule().fill(abs(roll) < .pi / 60 ? Theme.accent : Theme.ink)
                                .frame(width: 40, height: 3).rotationEffect(.radians(-roll))
                        }.frame(width: 70, height: 24).padding(.bottom, 12)
                    }.frame(maxWidth: .infinity)
                }
            }
        }
        .clipped()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}
