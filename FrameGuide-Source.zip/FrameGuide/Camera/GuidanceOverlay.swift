import SwiftUI

/// Display-only composition marks; they are not part of the captured image.
struct GuidanceOverlay: View {
    let result: GuidanceResult?
    let showsGrid: Bool
    let rollRadians: Double?

    private var tint: Color { result?.phase == .ready ? Theme.accent : Theme.ink }

    var body: some View {
        GeometryReader { geometry in
            let size = geometry.size
            ZStack {
                if showsGrid {
                    Path { path in
                        for fraction in [1.0 / 3.0, 2.0 / 3.0] {
                            let x = size.width * fraction
                            let y = size.height * fraction
                            path.move(to: CGPoint(x: x, y: 0))
                            path.addLine(to: CGPoint(x: x, y: size.height))
                            path.move(to: CGPoint(x: 0, y: y))
                            path.addLine(to: CGPoint(x: size.width, y: y))
                        }
                    }
                    .stroke(.white.opacity(0.28), lineWidth: 0.5)
                    .accessibilityHidden(true)
                }

                if let target = result?.targetBounds?.clamped(), target.width > 0, target.height > 0 {
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(Theme.accent, style: StrokeStyle(lineWidth: 2, dash: [8, 6]))
                        .frame(width: size.width * target.width, height: size.height * target.height)
                        .position(x: size.width * target.center.x, y: size.height * target.center.y)
                        .shadow(color: .black.opacity(0.55), radius: 2)
                        .accessibilityHidden(true)
                    Image(systemName: result?.phase == .ready ? "checkmark.circle.fill" : "scope")
                        .font(.system(size: 20, weight: .medium))
                        .foregroundStyle(Theme.accent)
                        .shadow(color: .black, radius: 3)
                        .position(x: size.width * target.center.x, y: size.height * target.center.y)
                        .accessibilityHidden(true)
                } else if let target = result?.target {
                    Image(systemName: result?.phase == .ready ? "checkmark.circle.fill" : "plus.circle")
                        .font(.system(size: 26, weight: .light))
                        .foregroundStyle(tint)
                        .shadow(color: .black, radius: 3)
                        .position(x: size.width * target.x, y: size.height * target.y)
                        .accessibilityHidden(true)
                }

                if let bounds = result?.subject?.clamped(), bounds.width > 0, bounds.height > 0 {
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(tint, style: StrokeStyle(lineWidth: 2,
                                                       dash: result?.phase == .searching ? [5, 5] : []))
                        .frame(width: size.width * bounds.width, height: size.height * bounds.height)
                        .position(x: size.width * bounds.center.x, y: size.height * bounds.center.y)
                        .shadow(color: .black.opacity(0.5), radius: 2)
                        .accessibilityHidden(true)
                }

                VStack {
                    HStack {
                        Spacer(minLength: 0)
                        if let result {
                            Label(statusText(for: result), systemImage: symbol(for: result))
                                .font(.caption.weight(.semibold))
                                .lineLimit(1)
                                .minimumScaleFactor(0.75)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 7)
                                .foregroundStyle(.white)
                                .background(.black.opacity(0.62), in: Capsule())
                                .accessibilityHidden(true)
                        }
                    }
                    Spacer(minLength: 0)
                    if let roll = rollRadians, roll.isFinite {
                        ZStack {
                            Capsule().fill(.white.opacity(0.4)).frame(width: 60, height: 1)
                            Capsule().fill(abs(roll) < .pi / 60 ? Theme.accent : Theme.ink)
                                .frame(width: 40, height: 3)
                                .rotationEffect(.radians(-roll))
                        }
                        .frame(width: 70, height: 24)
                        .padding(.bottom, 12)
                        .accessibilityHidden(true)
                    }
                }
                .padding(12)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .accessibilityElement(children: .ignore)
                .accessibilityLabel(Text(accessibilityStatus))
                .accessibilityAddTraits(.updatesFrequently)
            }
        }
        .clipped()
        .allowsHitTesting(false)
    }

    private var accessibilityStatus: String {
        guard let result else { return "构图辅助线" }
        let subjectStatus: String
        if result.phase == .searching {
            subjectStatus = "正在寻找主体"
        } else if result.subject == nil {
            subjectStatus = "主体框暂不可用"
        } else {
            subjectStatus = "已检测到主体"
        }
        return "\(subjectStatus)。\(result.message)。\(directionLabel(for: result.direction))"
    }

    private func statusText(for result: GuidanceResult) -> String {
        if result.subject == nil && result.phase == .searching { return "寻找主体中" }
        return result.message
    }

    private func symbol(for result: GuidanceResult) -> String {
        switch result.direction {
        case .left: return "arrow.left"
        case .right: return "arrow.right"
        case .up: return "arrow.up"
        case .down: return "arrow.down"
        case .closer: return "plus.magnifyingglass"
        case .farther: return "minus.magnifyingglass"
        case .none: return result.phase == .ready ? "checkmark.circle.fill" : "scope"
        }
    }

    private func directionLabel(for direction: GuidanceDirection) -> String {
        switch direction {
        case .left: return "目标在主体左侧"
        case .right: return "目标在主体右侧"
        case .up: return "目标在主体上方"
        case .down: return "目标在主体下方"
        case .closer: return "建议靠近主体"
        case .farther: return "建议远离主体"
        case .none: return "无额外方向提示"
        }
    }
}
