import AVFoundation
import Combine
import QuartzCore
import UIKit

/// Shared only by the video/analysis queues. No UI state is read by a frame callback.
private final class AnalysisAdmission {
    private let lock = NSLock()
    private var enabled = false
    private var generation: UInt64 = 0
    func reset(enabled: Bool) -> UInt64 {
        lock.lock(); defer { lock.unlock() }
        generation &+= 1
        self.enabled = enabled
        return generation
    }
    func ticket() -> UInt64? {
        lock.lock(); defer { lock.unlock() }
        return enabled ? generation : nil
    }
}

@MainActor
final class CameraViewModel: ObservableObject {
    @Published private(set) var state: CameraState = .idle
    @Published private(set) var guidance: GuidanceResult?
    @Published private(set) var capturedPhotoData: CapturedPhoto?
    @Published private(set) var recentPhotoData: CapturedPhoto?
    @Published private(set) var recentPhotoThumbnail: UIImage?
    @Published private(set) var rollRadians: Double?
    @Published private(set) var isFrontCamera = false
    @Published private(set) var isCapturing = false
    @Published private(set) var errorMessage: String?
    @Published private(set) var analysisMessage: String?
    @Published var scene: SceneMode = .automatic { didSet { if scene != oldValue { resetGuidance() } } }
    @Published var placement: PlacementMode = .smart { didSet { if placement != oldValue { resetGuidance() } } }
    @Published var flash: FlashSetting = .off
    @Published var showsGrid = true
    @Published var guidanceEnabled = false { didSet { if guidanceEnabled != oldValue { resetGuidance() } } }
    @Published var hapticsEnabled = true

    let viewfinderReader = ViewfinderReader()
    private let camera = CameraSession()
    private let analyzer = VisionAnalyzer()
    private let motion = MotionService()
    private let admission = AnalysisAdmission()
    private let thumbnailProcessor = PhotoProcessor()
    private var thumbnailGeneration: UInt64 = 0
    private var engine = CompositionEngine()
    private var watchdog: Task<Void, Never>?
    private var active = false
    private var switching = false
    private var generation: UInt64 = 0
    private var motionGeneration: UInt64 = 0
    private var minimumTimestamp = CACurrentMediaTime()
    private var lifecycleTimestamp = CACurrentMediaTime()
    private var lastStateTimestamp = 0.0
    private var lastPositionTimestamp = 0.0
    var captureSession: AVCaptureSession { camera.captureSession }
    var canCapture: Bool { active && state == .running && !switching && !isCapturing }

    init() {
        // Callbacks stay installed for the lifetime of the stream.
        let analyzer = self.analyzer
        let admission = self.admission
        camera.onFrame = { pixels, size, orientation, timestamp in
            guard let ticket = admission.ticket() else { return }
            analyzer.submit(pixelBuffer: pixels, size: size, orientation: orientation,
                            timestamp: timestamp, admissionGeneration: ticket)
        }
        analyzer.onAnalysis = { [weak self] snapshot, aspect, ticket in
            Task { @MainActor [weak self] in
                guard let self, self.accepts(ticket, timestamp: snapshot.timestamp) else { return }
                self.analysisMessage = nil
                let subjects = snapshot.subjects.map { candidate in
                    var candidate = candidate
                    let filled = PreviewGeometry.aspectFill(candidate.bounds, sourceAspect: aspect, viewAspect: 3.0 / 4.0)
                    candidate.bounds = self.isFrontCamera ? PreviewGeometry.mirror(filled) : filled
                    return candidate
                }
                let mapped = AnalysisSnapshot(timestamp: snapshot.timestamp, subjects: subjects,
                                              horizonRadians: snapshot.horizonRadians)
                self.publish(self.engine.update(snapshot: mapped, rollRadians: self.rollRadians,
                    preferences: GuidancePreferences(scene: self.scene, placement: self.placement)))
            }
        }
        analyzer.onFailure = { [weak self] message, timestamp, ticket in
            Task { @MainActor [weak self] in
                guard let self, self.accepts(ticket, timestamp: timestamp) else { return }
                self.analysisMessage = message
                self.engine.reset()
                self.guidance = nil
            }
        }
        camera.onState = { [weak self] state in
            let timestamp = CACurrentMediaTime()
            Task { @MainActor [weak self] in
                guard let self, self.active, timestamp >= self.lifecycleTimestamp,
                      timestamp >= self.lastStateTimestamp else { return }
                self.lastStateTimestamp = timestamp
                self.state = state
                if state != .running { self.pauseAnalysis() }
                else { self.resumeAnalysis() }
            }
        }
        camera.onPositionChanged = { [weak self] front in
            let timestamp = CACurrentMediaTime()
            Task { @MainActor [weak self] in
                // Physical lens state survives pauses. An acknowledgment queued
                // before stop/restart is still useful unless a newer one won.
                guard let self, timestamp >= self.lastPositionTimestamp else { return }
                self.lastPositionTimestamp = timestamp
                self.isFrontCamera = front
                if front { self.flash = .off }
                // An old physical snapshot can update mirroring, but must not
                // acknowledge a newer switch request that is still pending.
                if timestamp >= self.lifecycleTimestamp { self.switching = false }
                if self.active { self.resetGuidance() }
            }
        }
        camera.onPhoto = { [weak self] result in
            Task { @MainActor [weak self] in
                guard let self else { return }
                self.isCapturing = false
                switch result {
                case .success(let data):
                    self.recentPhotoData = data
                    self.updateRecentThumbnail(data)
                    self.capturedPhotoData = data
                    self.stop()
                case .failure(let error): self.errorMessage = error.localizedDescription
                }
            }
        }
    }

    func start() {
        guard !active, capturedPhotoData == nil else { return }
        active = true
        switching = false
        lifecycleTimestamp = CACurrentMediaTime()
        state = .configuring
        resetGuidance()
        camera.start()
    }
    func continuePermission() {
        guard active, state == .needsPermission else { return }
        state = .configuring
        camera.start(requestIfNeeded: true)
    }
    func retryPermission() {
        guard active, state == .denied else { return }
        camera.start()
    }
    func stop() {
        active = false
        lifecycleTimestamp = CACurrentMediaTime()
        pauseAnalysis()
        state = .idle
        camera.stop()
    }
    func switchCamera() {
        guard canCapture else { return }
        lifecycleTimestamp = CACurrentMediaTime()
        switching = true
        resetGuidance()
        camera.switchCamera()
    }
    func capture() {
        guard canCapture else { return }
        errorMessage = nil
        isCapturing = true
        camera.capture(flash: isFrontCamera ? .off : flash, viewport: viewfinderReader.snapshot())
    }
    func selectSubject(at point: NormalizedPoint, focusPoint: CGPoint) {
        guard active, state == .running, !switching else { return }
        camera.focus(at: focusPoint)
        if guidanceEnabled, engine.selectSubject(at: point) { guidance = nil }
    }
    func clearCapturedPhoto() { capturedPhotoData = nil }
    func openRecentPhoto() {
        guard !isCapturing, let data = recentPhotoData else { return }
        capturedPhotoData = data
        stop()
    }
    func dismissError() { errorMessage = nil }

    private func updateRecentThumbnail(_ data: CapturedPhoto) {
        thumbnailGeneration &+= 1
        let ticket = thumbnailGeneration
        recentPhotoThumbnail = nil
        let processor = thumbnailProcessor
        Task { [weak self] in
            let thumbnail = try? await processor.thumbnail(data: data)
            guard let self, self.thumbnailGeneration == ticket else { return }
            self.recentPhotoThumbnail = thumbnail.flatMap { UIImage(data: $0) }
        }
    }

    private func accepts(_ ticket: UInt64, timestamp: Double) -> Bool {
        active && state == .running && guidanceEnabled && !switching &&
            ticket == generation && timestamp >= minimumTimestamp && CACurrentMediaTime() - timestamp <= 0.8
    }
    private func resetGuidance() {
        // Close admission before waiting for any in-progress analyzer callback.
        // Both result paths retain the source timestamp and admission ticket,
        // even if a frame is delayed between admission and analyzer.submit.
        generation = admission.reset(enabled: false)
        analyzer.reset()
        minimumTimestamp = CACurrentMediaTime()
        generation = admission.reset(enabled: active && state == .running && guidanceEnabled && !switching)
        engine.reset()
        guidance = nil
        analysisMessage = nil
    }
    private func pauseAnalysis() {
        watchdog?.cancel()
        watchdog = nil
        motionGeneration &+= 1
        motion.stop()
        rollRadians = nil
        resetGuidance()
    }
    private func resumeAnalysis() {
        // A rejected camera switch restores running without a position event.
        switching = false
        resetGuidance()
        guard watchdog == nil else { return }
        motionGeneration &+= 1
        let motionTicket = motionGeneration
        motion.start { [weak self] roll in
            Task { @MainActor [weak self] in
                guard let self, self.active, self.state == .running,
                      self.motionGeneration == motionTicket else { return }
                self.rollRadians = roll
            }
        }
        watchdog = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(for: .milliseconds(200)) } catch { return }
                guard !Task.isCancelled, let self, self.active, self.state == .running else { return }
                if self.guidanceEnabled, let expired = self.engine.expire(at: CACurrentMediaTime()) {
                    self.publish(expired)
                }
            }
        }
    }
    private func publish(_ result: GuidanceResult) {
        let enteredReady = guidance?.phase != .ready && result.phase == .ready
        guidance = result
        if enteredReady && hapticsEnabled { UINotificationFeedbackGenerator().notificationOccurred(.success) }
    }
}
