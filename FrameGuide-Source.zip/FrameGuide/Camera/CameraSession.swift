import AVFoundation
import CoreVideo
import ImageIO
import QuartzCore
import UIKit

/// Install callbacks before start(). State, photo and position callbacks run on
/// sessionQueue; frames run on frameQueue. UI consumers must hop to main.
/// Session configuration, device locks and start/stop never execute on main.
final class CameraSession: NSObject {
    let captureSession = AVCaptureSession()
    var onState: ((CameraState) -> Void)?
    /// Physically portrait, UNMIRRORED pixels, .up orientation, CACurrentMediaTime seconds.
    /// Front-camera reflection belongs to display geometry, never to Vision.
    var onFrame: ((CVPixelBuffer, CGSize, CGImagePropertyOrientation, Double) -> Void)?
    var onPhoto: ((Result<Data, Error>) -> Void)?
    var onPositionChanged: ((Bool) -> Void)?

    private let sessionQueue = DispatchQueue(label: "app.frameguide.camera.session")
    private let frameQueue = DispatchQueue(label: "app.frameguide.camera.frames", qos: .userInitiated)
    private let photoOutput = AVCapturePhotoOutput()
    private let videoOutput = AVCaptureVideoDataOutput()
    private var input: AVCaptureDeviceInput?
    private var configured = false
    private var wantsRunning = false
    private var backgrounded = false
    private var observers: [NSObjectProtocol] = []
    private var photoResult: Result<Data, Error>?
    // Retain the delegate explicitly until didFinishCaptureFor, including errors.
    private var captureRetainer: CameraSession?

    override init() {
        super.init()
        observe(UIApplication.didEnterBackgroundNotification) { camera, _ in
            camera.backgrounded = true
            camera.stopRunning()
        }
        observe(UIApplication.willEnterForegroundNotification) { camera, _ in
            camera.backgrounded = false
            camera.resumeIfNeeded()
        }
        observe(AVCaptureSession.wasInterruptedNotification, object: captureSession) { camera, _ in
            camera.onState?(.interrupted)
        }
        observe(AVCaptureSession.interruptionEndedNotification, object: captureSession) { camera, _ in
            camera.resumeIfNeeded()
        }
        observe(AVCaptureSession.runtimeErrorNotification, object: captureSession) { camera, note in
            if let error = note.userInfo?[AVCaptureSessionErrorKey] as? AVError,
               error.code == .mediaServicesWereReset {
                camera.resumeIfNeeded()
            } else {
                camera.onState?(.unavailable("相机会话发生错误，请重新打开相机。"))
            }
        }
    }

    deinit { observers.forEach(NotificationCenter.default.removeObserver) }

    private func observe(_ name: Notification.Name, object: Any? = nil,
                         action: @escaping (CameraSession, Notification) -> Void) {
        observers.append(NotificationCenter.default.addObserver(forName: name, object: object, queue: nil) {
            [weak self] notification in
            self?.sessionQueue.async { [weak self] in
                guard let self else { return }
                action(self, notification)
            }
        })
    }

    func start() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.wantsRunning = true
            switch AVCaptureDevice.authorizationStatus(for: .video) {
            case .authorized: self.resumeIfNeeded()
            case .notDetermined:
                self.onState?(.configuring)
                AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                    self?.sessionQueue.async { [weak self] in
                        guard let self else { return }
                        if granted { self.resumeIfNeeded() }
                        else { self.onState?(.denied) }
                    }
                }
            default: self.onState?(.denied)
            }
        }
    }

    func stop() {
        sessionQueue.async { [weak self] in
            self?.wantsRunning = false
            self?.stopRunning()
        }
    }

    private func stopRunning() {
        if captureSession.isRunning { captureSession.stopRunning() }
        onState?(.idle)
    }

    private func resumeIfNeeded() {
        guard wantsRunning, !backgrounded,
              AVCaptureDevice.authorizationStatus(for: .video) == .authorized else { return }
        do {
            if !configured { try configure() }
            if !captureSession.isRunning { captureSession.startRunning() }
            // Re-publish the retained physical input after every resume. A
            // switch may have completed while the presentation was paused.
            if captureSession.isRunning, let input {
                onPositionChanged?(input.device.position == .front)
            }
            onState?(captureSession.isRunning ? .running : .unavailable("相机暂时无法启动。"))
        } catch { onState?(.unavailable(error.localizedDescription)) }
    }

    private func makeInput(position: AVCaptureDevice.Position) throws -> AVCaptureDeviceInput {
        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: position) else {
            throw CameraError.unavailable("找不到可用的相机。")
        }
        return try AVCaptureDeviceInput(device: device)
    }

    private func configure() throws {
        onState?(.configuring)
        let newInput = try makeInput(position: .back)
        captureSession.beginConfiguration()
        defer { captureSession.commitConfiguration() }
        do {
            guard captureSession.canSetSessionPreset(.photo) else {
                throw CameraError.unavailable("此设备不支持原生照片采集。")
            }
            captureSession.sessionPreset = .photo
            guard captureSession.canAddInput(newInput) else {
                throw CameraError.unavailable("无法连接相机输入。")
            }
            captureSession.addInput(newInput)
            guard captureSession.canAddOutput(photoOutput) else {
                throw CameraError.unavailable("无法连接照片输出。")
            }
            captureSession.addOutput(photoOutput)
            videoOutput.alwaysDiscardsLateVideoFrames = true
            videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
            videoOutput.setSampleBufferDelegate(self, queue: frameQueue)
            guard captureSession.canAddOutput(videoOutput) else {
                throw CameraError.unavailable("无法连接分析画面输出。")
            }
            captureSession.addOutput(videoOutput)
            try orientOutputs(front: false)
            setNativePhotoDimensions(device: newInput.device)
            input = newInput
            configured = true
            onPositionChanged?(false)
        } catch {
            captureSession.inputs.forEach { captureSession.removeInput($0) }
            captureSession.outputs.forEach { captureSession.removeOutput($0) }
            throw error
        }
    }

    private func setNativePhotoDimensions(device: AVCaptureDevice) {
        if let largest = device.activeFormat.supportedMaxPhotoDimensions.max(by: {
            Int64($0.width) * Int64($0.height) < Int64($1.width) * Int64($1.height)
        }) { photoOutput.maxPhotoDimensions = largest }
    }

    private func orientOutputs(front: Bool) throws {
        for (output, mirrored) in [(videoOutput as AVCaptureOutput, false), (photoOutput as AVCaptureOutput, front)] {
            guard let connection = output.connection(with: .video), connection.isVideoRotationAngleSupported(90) else {
                throw CameraError.unavailable("相机不支持竖屏采集。")
            }
            // Video buffers rotate physically. JPEG orientation is represented by
            // EXIF. Consumers honor EXIF and must not rotate either output again.
            connection.videoRotationAngle = 90
            if connection.isVideoMirroringSupported {
                connection.automaticallyAdjustsVideoMirroring = false
                connection.isVideoMirrored = mirrored
            } else if mirrored {
                throw CameraError.unavailable("前置相机不支持镜像照片。")
            }
        }
    }

    func switchCamera() {
        sessionQueue.async { [weak self] in
            guard let self, let previous = self.input, self.configured,
                  self.captureRetainer == nil else { return }
            do {
                let front = previous.device.position != .front
                let replacement = try self.makeInput(position: front ? .front : .back)
                self.captureSession.beginConfiguration()
                defer { self.captureSession.commitConfiguration() }
                self.captureSession.removeInput(previous)
                do {
                    guard self.captureSession.canAddInput(replacement) else {
                        throw CameraError.unavailable("无法切换相机。")
                    }
                    self.captureSession.addInput(replacement)
                    try self.orientOutputs(front: front)
                    self.setNativePhotoDimensions(device: replacement.device)
                    self.input = replacement
                    self.onPositionChanged?(front)
                } catch {
                    if self.captureSession.inputs.contains(replacement) { self.captureSession.removeInput(replacement) }
                    // Restore the previously accepted input within the same transaction.
                    self.captureSession.addInput(previous)
                    try self.orientOutputs(front: previous.device.position == .front)
                    self.setNativePhotoDimensions(device: previous.device)
                    throw error
                }
            } catch {
                self.onState?(.unavailable(error.localizedDescription))
                // A rejected switch keeps the prior camera usable. Restore the
                // running state so the starter UI does not permanently disable it.
                if self.captureSession.isRunning { self.onState?(.running) }
            }
        }
    }

    func capture(flash: FlashSetting) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            guard self.captureRetainer == nil else {
                self.onPhoto?(.failure(CameraError.busy)); return
            }
            guard self.captureSession.isRunning, !self.backgrounded, !self.captureSession.isInterrupted else {
                self.onPhoto?(.failure(CameraError.unavailable("相机尚未就绪。"))); return
            }
            let settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
            let requestedMode: AVCaptureDevice.FlashMode
            switch flash { case .off: requestedMode = .off; case .auto: requestedMode = .auto; case .on: requestedMode = .on }
            if self.photoOutput.supportedFlashModes.contains(NSNumber(value: requestedMode.rawValue)) {
                settings.flashMode = requestedMode
            }
            settings.maxPhotoDimensions = self.photoOutput.maxPhotoDimensions
            self.photoResult = nil
            self.captureRetainer = self
            self.photoOutput.capturePhoto(with: settings, delegate: self)
        }
    }

    /// Device point comes from AVCaptureVideoPreviewLayer conversion, which
    /// accounts for aspect fill, portrait orientation and selfie mirroring.
    func focus(at point: CGPoint) {
        sessionQueue.async { [weak self] in
            guard let self, let device = self.input?.device,
                  point.x.isFinite, point.y.isFinite else { return }
            do {
                try device.lockForConfiguration()
                defer { device.unlockForConfiguration() }
                let clamped = CGPoint(x: min(1, max(0, point.x)), y: min(1, max(0, point.y)))
                if device.isFocusPointOfInterestSupported, device.isFocusModeSupported(.autoFocus) {
                    device.focusPointOfInterest = clamped; device.focusMode = .autoFocus
                }
                if device.isExposurePointOfInterestSupported, device.isExposureModeSupported(.continuousAutoExposure) {
                    device.exposurePointOfInterest = clamped; device.exposureMode = .continuousAutoExposure
                }
            } catch {
                self.onState?(.unavailable(error.localizedDescription))
                if self.captureSession.isRunning { self.onState?(.running) }
            }
        }
    }
}

extension CameraSession: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixels = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        onFrame?(pixels, CGSize(width: CVPixelBufferGetWidth(pixels), height: CVPixelBufferGetHeight(pixels)),
                 .up, CACurrentMediaTime())
    }
}

extension CameraSession: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        let result: Result<Data, Error>
        if let error { result = .failure(error) }
        else if let data = photo.fileDataRepresentation() { result = .success(data) }
        else { result = .failure(CameraError.missingPhoto) }
        sessionQueue.async { self.photoResult = result }
    }

    func photoOutput(_ output: AVCapturePhotoOutput, didFinishCaptureFor resolvedSettings: AVCaptureResolvedPhotoSettings, error: Error?) {
        sessionQueue.async {
            let result = error.map { Result<Data, Error>.failure($0) } ?? self.photoResult ?? .failure(CameraError.missingPhoto)
            self.photoResult = nil
            self.captureRetainer = nil
            self.onPhoto?(result)
        }
    }
}
