import AVFoundation
import CoreMedia
import CoreVideo
import ImageIO
import UIKit

/// Install callbacks before start(). State, photo and position callbacks run on
/// sessionQueue; frames run on frameQueue. UI consumers must hop to main.
/// Session configuration, device locks and start/stop never execute on main.
final class CameraSession: NSObject {
    static func hostTime() -> Double { CMClockGetTime(CMClockGetHostTimeClock()).seconds }

    let captureSession = AVCaptureSession()
    var onState: ((CameraState) -> Void)?
    /// Portrait, unmirrored pixels, source lens, and presentation time on the host clock.
    /// Front-camera reflection belongs to display geometry, never to Vision.
    var onFrame: ((CVPixelBuffer, CGSize, CGImagePropertyOrientation, Double, Bool) -> Void)?
    var onPhoto: ((Result<CapturedPhoto, Error>) -> Void)?
    var onPositionChanged: ((Bool) -> Void)?

    private let sessionQueue = DispatchQueue(label: "app.frameguide.camera.session")
    private let frameQueue = DispatchQueue(label: "app.frameguide.camera.frames", qos: .userInitiated)
    private let photoOutput = AVCapturePhotoOutput()
    private let videoOutput = AVCaptureVideoDataOutput()
    private var input: AVCaptureDeviceInput?
    private var configured = false
    private var wantsRunning = false
    private var backgrounded = false
    private var observers: [NSObjectProtocol] = []
    private var framing: (captureID: Int64, plan: ShutterFraming)?
    private var photoResult: Result<Data, Error>?
    // Retain the delegate explicitly until didFinishCaptureFor, including errors.
    private var captureRetainer: CameraSession?

    override init() {
        super.init()
        observe(UIApplication.didEnterBackgroundNotification) { camera, _ in
            camera.backgrounded = true
            camera.stopRunning()
        }
        observe(UIApplication.willEnterForegroundNotification) { camera, _ in
            camera.backgrounded = false
            camera.resumeIfNeeded()
        }
        observe(AVCaptureSession.wasInterruptedNotification, object: captureSession) { camera, _ in
            camera.onState?(.interrupted)
        }
        observe(AVCaptureSession.interruptionEndedNotification, object: captureSession) { camera, _ in
            camera.resumeIfNeeded()
        }
        observe(AVCaptureSession.runtimeErrorNotification, object: captureSession) { camera, note in
            if let error = note.userInfo?[AVCaptureSessionErrorKey] as? AVError,
               error.code == .mediaServicesWereReset {
                camera.resumeIfNeeded()
            } else {
                camera.onState?(.unavailable("相机会话发生错误，请重新打开相机。"))
            }
        }
    }

    deinit { observers.forEach(NotificationCenter.default.removeObserver) }

    private func observe(_ name: Notification.Name, object: Any? = nil,
                         action: @escaping (CameraSession, Notification) -> Void) {
        observers.append(NotificationCenter.default.addObserver(forName: name, object: object, queue: nil) {
            [weak self] notification in
            self?.sessionQueue.async { [weak self] in
                guard let self else { return }
                action(self, notification)
            }
        })
    }

    func start(requestIfNeeded: Bool = false) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.wantsRunning = true
            switch AVCaptureDevice.authorizationStatus(for: .video) {
            case .authorized: self.resumeIfNeeded()
            case .notDetermined where requestIfNeeded:
                self.onState?(.configuring)
                AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                    self?.sessionQueue.async { [weak self] in
                        guard let self else { return }
                        if granted { self.resumeIfNeeded() }
                        else { self.onState?(.denied) }
                    }
                }
            case .notDetermined: self.onState?(.needsPermission)
            default: self.onState?(.denied)
            }
        }
    }

    func stop() {
        sessionQueue.async { [weak self] in
            self?.wantsRunning = false
            self?.stopRunning()
        }
    }

    private func stopRunning() {
        if captureSession.isRunning { captureSession.stopRunning() }
        onState?(.idle)
    }

    private func resumeIfNeeded() {
        guard wantsRunning, !backgrounded,
              AVCaptureDevice.authorizationStatus(for: .video) == .authorized else { return }
        do {
            if !configured { try configure() }
            if !captureSession.isRunning { captureSession.startRunning() }
            // Re-publish the retained physical input after every resume. A
            // switch may have completed while the presentation was paused.
            if captureSession.isRunning, let input {
                onPositionChanged?(input.device.position == .front)
            }
            onState?(captureSession.isRunning ? .running : .unavailable("相机暂时无法启动。"))
        } catch { onState?(.unavailable(error.localizedDescription)) }
    }

    private func makeInput(position: AVCaptureDevice.Position) throws -> AVCaptureDeviceInput {
        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: position) else {
            throw CameraError.unavailable("找不到可用的相机。")
        }
        return try AVCaptureDeviceInput(device: device)
    }

    private func configure() throws {
        onState?(.configuring)
        let newInput = try makeInput(position: .back)
        captureSession.beginConfiguration()
        defer { captureSession.commitConfiguration() }
        do {
            guard captureSession.canSetSessionPreset(.photo) else {
                throw CameraError.unavailable("此设备不支持原生照片采集。")
            }
            captureSession.sessionPreset = .photo
            guard captureSession.canAddInput(newInput) else {
                throw CameraError.unavailable("无法连接相机输入。")
            }
            captureSession.addInput(newInput)
            guard captureSession.canAddOutput(photoOutput) else {
                throw CameraError.unavailable("无法连接照片输出。")
            }
            captureSession.addOutput(photoOutput)
            videoOutput.alwaysDiscardsLateVideoFrames = true
            videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
            videoOutput.setSampleBufferDelegate(self, queue: frameQueue)
            guard captureSession.canAddOutput(videoOutput) else {
                throw CameraError.unavailable("无法连接分析画面输出。")
            }
            captureSession.addOutput(videoOutput)
            try orientOutputs(front: false)
            setNativePhotoDimensions(device: newInput.device)
            input = newInput
            configured = true
            onPositionChanged?(false)
        } catch {
            captureSession.inputs.forEach { captureSession.removeInput($0) }
            captureSession.outputs.forEach { captureSession.removeOutput($0) }
            throw error
        }
    }

    private func setNativePhotoDimensions(device: AVCaptureDevice) {
        if let largest = device.activeFormat.supportedMaxPhotoDimensions.max(by: {
            Int64($0.width) * Int64($0.height) < Int64($1.width) * Int64($1.height)
        }) { photoOutput.maxPhotoDimensions = largest }
    }

    private func orientOutputs(front: Bool) throws {
        guard let video = videoOutput.connection(with: .video), video.isVideoOrientationSupported,
              let photo = photoOutput.connection(with: .video), photo.isVideoRotationAngleSupported(90)
        else { throw CameraError.unavailable("相机不支持竖屏采集。") }
        // Semantic portrait rotates video buffers for this input's mounting. Unlike
        // horizon-level rotation, it stays fixed if the user tilts the phone.
        video.videoOrientation = .portrait
        // Processed JPEG uses Apple's default sensor orientation compensation.
        // Preserve its legacy portrait rotation, separately from video. CI reads EXIF once.
        photo.videoRotationAngle = 90
        for (connection, mirrored) in [(video, false), (photo, front)] {
            if connection.isVideoMirroringSupported {
                connection.automaticallyAdjustsVideoMirroring = false
                connection.isVideoMirrored = mirrored
            } else if mirrored {
                throw CameraError.unavailable("前置相机不支持镜像照片。")
            }
        }
    }

    func switchCamera() {
        sessionQueue.async { [weak self] in
            guard let self, let previous = self.input, self.configured,
                  self.captureRetainer == nil else { return }
            do {
                let front = previous.device.position != .front
                let replacement = try self.makeInput(position: front ? .front : .back)
                self.captureSession.beginConfiguration()
                var switchedPosition: Bool? = nil
                defer {
                    self.captureSession.commitConfiguration()
                    if let switchedPosition { self.onPositionChanged?(switchedPosition) }
                }
                self.captureSession.removeInput(previous)
                do {
                    guard self.captureSession.canAddInput(replacement) else {
                        throw CameraError.unavailable("无法切换相机。")
                    }
                    self.captureSession.addInput(replacement)
                    try self.orientOutputs(front: front)
                    self.setNativePhotoDimensions(device: replacement.device)
                    self.input = replacement
                    switchedPosition = front
                } catch {
                    if self.captureSession.inputs.contains(replacement) { self.captureSession.removeInput(replacement) }
                    // Restore the previously accepted input within the same transaction.
                    self.captureSession.addInput(previous)
                    try self.orientOutputs(front: previous.device.position == .front)
                    self.setNativePhotoDimensions(device: previous.device)
                    throw error
                }
            } catch {
                self.onState?(.unavailable(error.localizedDescription))
                // A rejected switch keeps the prior camera usable. Restore the
                // running state so the starter UI does not permanently disable it.
                if self.captureSession.isRunning { self.onState?(.running) }
            }
        }
    }

    func capture(flash: FlashSetting, viewport: ShutterViewport?) {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            guard self.captureRetainer == nil else {
                self.onPhoto?(.failure(CameraError.busy)); return
            }
            guard self.captureSession.isRunning, !self.backgrounded, !self.captureSession.isInterrupted else {
                self.onPhoto?(.failure(CameraError.unavailable("相机尚未就绪。"))); return
            }
            let settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
            let requestedMode: AVCaptureDevice.FlashMode
            switch flash { case .off: requestedMode = .off; case .auto: requestedMode = .auto; case .on: requestedMode = .on }
            if self.photoOutput.supportedFlashModes.contains(requestedMode) {
                settings.flashMode = requestedMode
            }
            settings.maxPhotoDimensions = self.photoOutput.maxPhotoDimensions
            self.framing = (settings.uniqueID, self.shutterPlan(viewport: viewport))
            self.photoResult = nil
            self.captureRetainer = self
            self.photoOutput.capturePhoto(with: settings, delegate: self)
        }
    }

    private func shutterPlan(viewport: ShutterViewport?) -> ShutterFraming {
        let device = input?.device
        let conn = photoOutput.connection(with: .video)
        let clean = device.map { CMVideoFormatDescriptionGetCleanAperture($0.activeFormat.formatDescription, originIsAtTopLeft: true) } ?? .zero
        let video = device.map { CMVideoFormatDescriptionGetDimensions($0.activeFormat.formatDescription) }
        let front = device?.position == .front
        var reason: String?
        var reference = CGRect.zero, visible = CGRect.zero
        if viewport == nil { reason = "未取得取景器范围" }
        else if viewport?.deviceID != device?.uniqueID { reason = "取景镜头已变更" }
        else if conn?.isActive != true || conn?.videoRotationAngle != 90 || conn?.isVideoMirrored != front {
            reason = "照片连接方向未确认"
        } else if device?.videoZoomFactor != 1 { reason = "缩放范围未确认" }
        else if let video, clean == CGRect(x: 0, y: 0, width: Int(video.width), height: Int(video.height)), let viewport {
            reference = photoOutput.outputRectConverted(fromMetadataOutputRect: CGRect(x: 0, y: 0, width: 1, height: 1))
            visible = photoOutput.outputRectConverted(fromMetadataOutputRect: viewport.metadataRect)
        } else { reason = "有效像素区域未确认" }
        let side = front ? "front" : "back"
        let diagnostic = "build2 \(side) viewAspect=\(viewport?.aspect ?? 0) metadata=\(viewport?.metadataRect ?? .zero) video=\(video?.width ?? 0)x\(video?.height ?? 0) angle=\(conn?.videoRotationAngle ?? -1) mirror=\(conn?.isVideoMirrored ?? false)"
        return ShutterFraming(reference: reference, visible: visible, viewportAspect: viewport?.aspect ?? 0,
                              cleanSize: CGSize(width: min(clean.width, clean.height), height: max(clean.width, clean.height)),
                              maximum: Self.upright(photoOutput.maxPhotoDimensions), unavailable: reason, diagnostic: diagnostic)
    }

    private static func upright(_ size: CMVideoDimensions) -> CGSize {
        CGSize(width: CGFloat(min(size.width, size.height)), height: CGFloat(max(size.width, size.height)))
    }

    /// Device point comes from AVCaptureVideoPreviewLayer conversion, which
    /// accounts for aspect fill, portrait orientation and selfie mirroring.
    func focus(at point: CGPoint) {
        sessionQueue.async { [weak self] in
            guard let self, let device = self.input?.device,
                  point.x.isFinite, point.y.isFinite else { return }
            do {
                try device.lockForConfiguration()
                defer { device.unlockForConfiguration() }
                let clamped = CGPoint(x: min(1, max(0, point.x)), y: min(1, max(0, point.y)))
                if device.isFocusPointOfInterestSupported, device.isFocusModeSupported(.autoFocus) {
                    device.focusPointOfInterest = clamped; device.focusMode = .autoFocus
                }
                if device.isExposurePointOfInterestSupported, device.isExposureModeSupported(.continuousAutoExposure) {
                    device.exposurePointOfInterest = clamped; device.exposureMode = .continuousAutoExposure
                }
            } catch {
                self.onState?(.unavailable(error.localizedDescription))
                if self.captureSession.isRunning { self.onState?(.running) }
            }
        }
    }
}

extension CameraSession: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // The callback's connection identifies the source of this sample, including queued frames.
        guard output === videoOutput,
              connection === videoOutput.connection(with: .video),
              let port = connection.inputPorts.first(where: { $0.mediaType == .video }),
              port.sourceDevicePosition == .front || port.sourceDevicePosition == .back,
              let sessionClock = captureSession.synchronizationClock,
              let pixels = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let timestamp = CMSyncConvertTime(sampleBuffer.presentationTimeStamp,
                                         from: sessionClock, to: CMClockGetHostTimeClock()).seconds
        guard timestamp.isFinite else { return }
        onFrame?(pixels, CGSize(width: CVPixelBufferGetWidth(pixels), height: CVPixelBufferGetHeight(pixels)),
                 .up, timestamp, port.sourceDevicePosition == .front)
    }
}

extension CameraSession: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        let result: Result<Data, Error>
        if let error { result = .failure(error) }
        else if let data = photo.fileDataRepresentation() { result = .success(data) }
        else { result = .failure(CameraError.missingPhoto) }
        sessionQueue.async { self.photoResult = result }
    }

    func photoOutput(_ output: AVCapturePhotoOutput, didFinishCaptureFor resolvedSettings: AVCaptureResolvedPhotoSettings, error: Error?) {
        sessionQueue.async {
            let result = error.map { Result<Data, Error>.failure($0) } ?? self.photoResult ?? .failure(CameraError.missingPhoto)
            self.photoResult = nil
            self.captureRetainer = nil
            let captured = result.flatMap { data -> Result<CapturedPhoto, Error> in
                guard let framing = self.framing, framing.captureID == resolvedSettings.uniqueID else {
                    return .failure(CameraError.missingPhoto)
                }
                let resolved = Self.upright(resolvedSettings.photoDimensions)
                return Result { try CapturedPhoto(bytes: data, plan: framing.plan, resolved: resolved) }
            }
            self.framing = nil
            self.onPhoto?(captured)
        }
    }
}
