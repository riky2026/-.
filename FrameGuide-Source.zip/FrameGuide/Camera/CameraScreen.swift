import SwiftUI
import UIKit

@MainActor
struct CameraScreen: View {
    @StateObject private var model = CameraViewModel()
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var showsSettings = false

    var body: some View {
        GeometryReader { geometry in
            let previewWidth = min(geometry.size.width - 32, max(180, (geometry.size.height - 410) * 3 / 4))
            ScrollView {
                VStack(spacing: 18) {
                    header
                    if model.state == .running || model.state == .configuring {
                        viewfinder
                            .frame(width: previewWidth, height: previewWidth * 4 / 3)
                    } else {
                        // Permission/error copy grows freely with Dynamic Type;
                        // settings and retry remain reachable on small screens.
                        cameraStatus.frame(maxWidth: .infinity).padding(24)
                            .background(Theme.panel, in: RoundedRectangle(cornerRadius: 20))
                    }
                    controls
                }
                .padding(.horizontal, 16).padding(.vertical, 8)
                .frame(minHeight: geometry.size.height, alignment: .top)
            }
        }
        .background(Theme.background).foregroundStyle(Theme.ink)
        .tint(Theme.accent)
        .sheet(isPresented: $showsSettings) { CameraSettingsView(model: model) }
        .fullScreenCover(isPresented: Binding(
            get: { model.capturedPhotoData != nil },
            set: { if !$0 { model.clearCapturedPhoto() } }
        ), onDismiss: { if scenePhase == .active { model.start() } }) {
            if let data = model.capturedPhotoData {
                PhotoReviewScreen(originalData: data) { model.clearCapturedPhoto() }
            }
        }
        .alert("拍摄未完成", isPresented: Binding(
            get: { model.errorMessage != nil }, set: { if !$0 { model.dismissError() } }
        )) { Button("好") { model.dismissError() } } message: { Text(model.errorMessage ?? "请重试。") }
        .onAppear { if scenePhase == .active { model.start() } }
        .onDisappear { model.stop() }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { model.start() } else { model.stop() }
        }
    }

    private var header: some View {
        HStack(spacing: 6) {
            VStack(alignment: .leading, spacing: 2) {
                Text("取景").font(.title2.weight(.semibold))
                Text("FRAMEGUIDE").font(.caption2.weight(.medium)).tracking(2).foregroundStyle(Theme.accent)
            }.accessibilityElement(children: .combine)
            Spacer(minLength: 4)
            Menu {
                ForEach(FlashSetting.allCases, id: \.self) { setting in
                    Button { model.flash = setting } label: {
                        Label(setting.title, systemImage: model.flash == setting ? "checkmark" : setting.symbol)
                    }
                }
            } label: { icon(model.flash.symbol) }
                .disabled(model.isFrontCamera || model.isCapturing)
                .accessibilityLabel("闪光灯，\(model.flash.title)")
            Button { model.showsGrid.toggle() } label: {
                icon("grid").foregroundStyle(model.showsGrid ? Theme.accent : Theme.ink)
            }.accessibilityLabel("三分辅助线")
                .accessibilityValue(model.showsGrid ? "开启" : "关闭")
            Button { showsSettings = true } label: { icon("slider.horizontal.3") }
                .accessibilityLabel("相机设置")
        }
    }

    private func icon(_ name: String) -> some View {
        Image(systemName: name).font(.system(size: 19, weight: .medium))
            .frame(minWidth: 44, minHeight: 44).contentShape(Rectangle())
    }

    private var viewfinder: some View {
        ZStack {
            Color.black
            CameraPreview(session: model.captureSession, reader: model.viewfinderReader, isFrontCamera: model.isFrontCamera) { point, devicePoint in
                model.selectSubject(at: point, focusPoint: devicePoint)
            }
            .accessibilityLabel("相机取景器")
            .accessibilityHint("轻点画面可对焦并选择构图主体")
            if model.state == .running {
                GuidanceOverlay(result: model.guidanceEnabled ? model.guidance : nil,
                                showsGrid: model.showsGrid, rollRadians: model.rollRadians)
            } else {
                Color.black.opacity(0.85)
                cameraStatus.padding(24)
            }
            VStack {
                HStack {
                    Label("3:4", systemImage: "viewfinder")
                        .font(.caption.weight(.medium)).padding(8)
                        .background(.black.opacity(0.45), in: Capsule())
                    Spacer()
                }
                Spacer()
            }.padding(12).accessibilityHidden(true)
        }
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Theme.ink.opacity(0.12), lineWidth: 1))
    }

    @ViewBuilder private var cameraStatus: some View {
        VStack(spacing: 14) {
            switch model.state {
            case .needsPermission:
                Text("用相机取景").font(.headline)
                Text("取景需要使用相机拍摄照片，并在设备上分析构图。轻点继续后，可在系统提示中选择是否允许。").font(.callout)
                Button { model.continuePermission() } label: {
                    Text("继续").frame(minWidth: 44, minHeight: 44)
                }.buttonStyle(.borderedProminent).accessibilityLabel("继续申请相机权限")
            case .denied:
                Image(systemName: "camera.fill").font(.largeTitle)
                Text("允许相机，开始取景").font(.headline)
                Text("请在系统设置中允许“取景”访问相机。").font(.callout)
                Button {
                    if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
                } label: {
                    Text("打开系统设置").frame(minWidth: 44, minHeight: 44).contentShape(Rectangle())
                }.buttonStyle(.borderedProminent)
                Button { model.retryPermission() } label: {
                    Text("重试").frame(minWidth: 44, minHeight: 44)
                }.accessibilityLabel("重新检查相机权限")
            case .unavailable(let reason):
                Image(systemName: "camera.fill").font(.largeTitle)
                Text("当前设备无法使用相机").font(.headline)
                Text(reason).font(.callout)
                Button { model.stop(); model.start() } label: {
                    Text("重试").frame(minWidth: 44, minHeight: 44).contentShape(Rectangle())
                }
            case .interrupted:
                Image(systemName: "pause.circle").font(.largeTitle)
                Text("相机暂时中断").font(.headline)
                Text("中断结束后会自动恢复。").font(.callout)
            case .idle: Text("相机已暂停").font(.headline)
            case .configuring: ProgressView("正在准备相机…")
            case .running: EmptyView()
            }
        }.multilineTextAlignment(.center)
    }

    private var controls: some View {
        VStack(spacing: 18) {
            Picker("拍摄场景", selection: $model.scene) {
                ForEach(SceneMode.allCases, id: \.self) { Text($0.title).tag($0) }
            }.pickerStyle(.segmented).frame(minHeight: 44)
            VStack(spacing: 8) {
                Label(guidanceTitle, systemImage: guidanceSymbol)
                    .font(.headline).foregroundStyle(model.guidance?.phase == .ready ? Theme.accent : Theme.ink)
                    .multilineTextAlignment(.center)
                    .contentTransition(.identity)
                Text(model.analysisMessage ?? (model.guidanceEnabled ? "轻点主体 · 缓慢移动 · 保持水平" : "轻点画面对焦，按下快门拍摄"))
                    .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
            }.frame(minHeight: 58)
            Toggle(isOn: $model.guidanceEnabled) {
                Label("构图引导", systemImage: "scope").font(.subheadline.weight(.medium))
            }
            .frame(minHeight: 44).padding(.horizontal, 14).padding(.vertical, 4)
            .background(Theme.panel, in: RoundedRectangle(cornerRadius: 14))
            HStack {
                Button { model.openRecentPhoto() } label: {
                    ZStack {
                        RoundedRectangle(cornerRadius: 12).fill(Theme.panel)
                        if let image = model.recentPhotoThumbnail {
                            Image(uiImage: image).resizable().scaledToFit()
                        } else { Image(systemName: "photo").font(.title3) }
                    }.frame(width: 52, height: 64).clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .disabled(model.recentPhotoData == nil || model.isCapturing)
                .accessibilityLabel("查看最近拍摄的照片")
                Spacer()
                Button { model.capture() } label: {
                    ZStack {
                        Circle().stroke(Theme.ink, lineWidth: 3).frame(width: 78, height: 78)
                        Circle().fill(model.canCapture ? Theme.ink : Theme.ink.opacity(0.3)).frame(width: 64, height: 64)
                        if model.isCapturing { ProgressView().tint(Theme.background) }
                    }
                }.disabled(!model.canCapture).accessibilityLabel(model.isCapturing ? "正在拍摄" : "拍摄照片")
                Spacer()
                Button { model.switchCamera() } label: { icon("arrow.triangle.2.circlepath.camera").frame(width: 52, height: 64) }
                    .disabled(!model.canCapture).accessibilityLabel("切换前后镜头")
            }
            Text("本地分析 · 自由拍摄").font(.caption2).foregroundStyle(.secondary)
        }
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.18), value: model.guidance?.phase)
    }

    private var guidanceTitle: String {
        if model.state != .running { return "相机就绪后即可拍摄" }
        if !model.guidanceEnabled { return "发现值得留下的一刻" }
        if model.analysisMessage != nil { return "仍可拍摄，分析暂不可用" }
        return model.guidance?.message ?? "换个角度，或点选主体"
    }
    private var guidanceSymbol: String {
        if !model.guidanceEnabled { return "camera" }
        switch model.guidance?.direction {
        case .left: return "arrow.left"
        case .right: return "arrow.right"
        case .up: return "arrow.up"
        case .down: return "arrow.down"
        default: return model.guidance?.phase == .ready ? "checkmark.circle.fill" : "scope"
        }
    }

}
