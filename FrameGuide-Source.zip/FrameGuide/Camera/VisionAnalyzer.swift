import Foundation
import CoreVideo
import ImageIO
import Vision

/// Callbacks execute on analysisQueue. Consumers must return promptly and hop
/// to main for UI updates. No buffers or observations leave the device.
final class VisionAnalyzer {
    private let analysisQueue = DispatchQueue(label: "app.frameguide.vision", qos: .userInitiated)
    // Recursive so a callback can safely reset the analyzer. Delivery and reset
    // share the lock: after reset returns, an older generation cannot call back.
    private let lock = NSRecursiveLock()
    private var inFlight = false
    private var generation: UInt64 = 0
    private var lastTimestamp: Double?
    private var analysisCallback: ((AnalysisSnapshot, Double, UInt64) -> Void)?
    private var failureCallback: ((String, Double, UInt64) -> Void)?

    // Created once and touched only by the serial analysis queue.
    private let humanRequest = VNDetectHumanRectanglesRequest()
    private let faceRequest = VNDetectFaceRectanglesRequest()
    private let saliencyRequest = VNGenerateObjectnessBasedSaliencyImageRequest()
    private let horizonRequest = VNDetectHorizonRequest()

    /// The admission ticket belongs to the submitted frame, never delivery time.
    var onAnalysis: ((AnalysisSnapshot, Double, UInt64) -> Void)? {
        get { lock.lock(); defer { lock.unlock() }; return analysisCallback }
        set { lock.lock(); defer { lock.unlock() }; analysisCallback = newValue }
    }

    /// Failure includes the original frame timestamp and admission ticket too.
    var onFailure: ((String, Double, UInt64) -> Void)? {
        get { lock.lock(); defer { lock.unlock() }; return failureCallback }
        set { lock.lock(); defer { lock.unlock() }; failureCallback = newValue }
    }

    func submit(pixelBuffer: CVPixelBuffer, size: CGSize,
                orientation: CGImagePropertyOrientation, timestamp: Double,
                admissionGeneration: UInt64) {
        guard timestamp.isFinite, size.width.isFinite, size.height.isFinite,
              size.width > 0, size.height > 0 else { return }
        lock.lock()
        guard !inFlight, lastTimestamp.map({ timestamp - $0 >= 0.2 }) ?? true else {
            lock.unlock()
            return
        }
        inFlight = true
        lastTimestamp = timestamp
        let submittedGeneration = generation
        lock.unlock()

        // Strong capture retains the CVPixelBuffer through perform and delivery.
        // Admission occurs before dispatch, so there is at most one queued task.
        analysisQueue.async { [self, pixelBuffer] in
            defer {
                lock.lock()
                inFlight = false
                lock.unlock()
            }
            lock.lock()
            let current = submittedGeneration == generation
            lock.unlock()
            guard current else { return }
            do {
                let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: orientation)
                try handler.perform([humanRequest, faceRequest, saliencyRequest, horizonRequest])
                // Always rebuild from this perform; an empty result clears old subjects.
                var subjects = (humanRequest.results ?? []).map { candidate($0, kind: .person) }
                subjects += (faceRequest.results ?? []).map { candidate($0, kind: .face) }
                for observation in saliencyRequest.results ?? [] {
                    subjects += (observation.salientObjects ?? []).map { candidate($0, kind: .salient) }
                }
                let horizon = horizonRequest.results?.first
                let angle: Double? = horizon.flatMap {
                    $0.confidence >= 0.6 && $0.angle.isFinite ? Double($0.angle) : nil
                }
                let snapshot = AnalysisSnapshot(timestamp: timestamp, subjects: subjects, horizonRadians: angle)
                // The camera already physically rotates portrait buffers and passes
                // .up. Honor that once; only sideways EXIF changes the aspect ratio.
                let sideways: Bool
                switch orientation {
                case .left, .leftMirrored, .right, .rightMirrored: sideways = true
                default: sideways = false
                }
                let aspect = Double(sideways ? size.height / size.width : size.width / size.height)
                lock.lock()
                defer { lock.unlock() }
                guard submittedGeneration == generation else { return }
                analysisCallback?(snapshot, aspect, admissionGeneration)
            } catch {
                lock.lock()
                defer { lock.unlock() }
                guard submittedGeneration == generation else { return }
                failureCallback?("画面分析暂时不可用：\(error.localizedDescription)", timestamp, admissionGeneration)
            }
        }
    }

    func reset() {
        lock.lock()
        defer { lock.unlock() }
        generation &+= 1
        lastTimestamp = nil
        // Never clear inFlight here: an old perform still owns the requests.
    }

    private func candidate(_ observation: VNDetectedObjectObservation, kind: SubjectKind) -> SubjectCandidate {
        let box = observation.boundingBox
        let bounds = PreviewGeometry.fromVision(NormalizedRect(
            x: Double(box.origin.x), y: Double(box.origin.y),
            width: Double(box.width), height: Double(box.height)))
        // Canonical upright, top-left, UNMIRRORED. Display mirroring belongs to UI.
        return SubjectCandidate(id: observation.uuid.uuidString, kind: kind,
                                bounds: bounds, confidence: Double(observation.confidence))
    }
}
