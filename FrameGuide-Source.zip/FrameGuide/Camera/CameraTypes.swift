import Foundation

enum FlashSetting: String, CaseIterable { case off, auto, on }

enum CameraState: Equatable {
    case idle, configuring, running, interrupted, needsPermission, denied
    case unavailable(String)
}

enum CameraError: LocalizedError {
    case unavailable(String)
    case busy
    case missingPhoto

    var errorDescription: String? {
        switch self {
        case .unavailable(let reason): return reason
        case .busy: return "正在处理上一张照片，请稍候。"
        case .missingPhoto: return "未能取得照片数据。"
        }
    }
}
