import Foundation
import CoreMotion

/// Device-motion callbacks run on a private serial OperationQueue; the initial
/// unavailable callback runs on the caller. Return promptly; hop to main for UI.
final class MotionService {
    private let manager = CMMotionManager()
    private let queue: OperationQueue = {
        let queue = OperationQueue()
        queue.name = "app.frameguide.motion"
        queue.maxConcurrentOperationCount = 1
        queue.qualityOfService = .userInitiated
        return queue
    }()
    private let lock = NSRecursiveLock()
    private var generation: UInt64 = 0
    private var callback: ((Double?, Double?) -> Void)?
    private var smoothedRotationRate: Double?

    func start(onMotion: @escaping (Double?, Double?) -> Void) {
        lock.lock()
        defer { lock.unlock() }
        manager.stopDeviceMotionUpdates()
        generation &+= 1
        let startedGeneration = generation
        callback = onMotion
        smoothedRotationRate = nil
        guard manager.isDeviceMotionAvailable else {
            onMotion(nil, nil)
            return
        }
        manager.deviceMotionUpdateInterval = 1.0 / 15.0
        manager.startDeviceMotionUpdates(to: queue) { [weak self] motion, error in
            guard let self else { return }
            self.lock.lock()
            defer { self.lock.unlock() }
            guard startedGeneration == self.generation else { return }
            guard error == nil, let gravity = motion?.gravity,
                  gravity.x.isFinite, gravity.y.isFinite,
                  hypot(gravity.x, gravity.y) >= 0.15 else {
                self.smoothedRotationRate = nil
                self.callback?(nil, nil)
                return
            }
            let rate = motion?.rotationRate
            let magnitude: Double? = rate.flatMap {
                let value = hypot(hypot($0.x, $0.y), $0.z)
                return value.isFinite ? value : nil
            }
            if let magnitude {
                self.smoothedRotationRate = self.smoothedRotationRate.map { $0 * 0.65 + magnitude * 0.35 } ?? magnitude
            } else {
                self.smoothedRotationRate = nil
            }
            self.callback?(atan2(gravity.x, -gravity.y), self.smoothedRotationRate)
        }
    }

    func stop() {
        lock.lock()
        defer { lock.unlock() }
        generation &+= 1
        callback = nil
        smoothedRotationRate = nil
        manager.stopDeviceMotionUpdates()
    }

    deinit { manager.stopDeviceMotionUpdates() }
}
