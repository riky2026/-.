import AVFoundation
import SwiftUI
import UIKit

/// Tap callback runs on main; normalized coordinates describe the displayed view.
struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession
    let isFrontCamera: Bool
    let onTap: (NormalizedPoint, CGPoint) -> Void

    func makeUIView(context: Context) -> PreviewView {
        let view = PreviewView()
        view.previewLayer.session = session
        view.previewLayer.videoGravity = .resizeAspectFill
        view.onTap = onTap
        view.front = isFrontCamera
        return view
    }

    func updateUIView(_ view: PreviewView, context: Context) {
        view.front = isFrontCamera
        view.onTap = onTap
        view.updateConnection()
    }

    final class PreviewView: UIView {
        override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
        var previewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
        var front = false
        var onTap: ((NormalizedPoint, CGPoint) -> Void)?

        override init(frame: CGRect) {
            super.init(frame: frame)
            addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tapped(_:))))
        }
        required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
        override func layoutSubviews() { super.layoutSubviews(); updateConnection() }

        func updateConnection() {
            guard let connection = previewLayer.connection else { return }
            if connection.isVideoRotationAngleSupported(90) { connection.videoRotationAngle = 90 }
            if connection.isVideoMirroringSupported {
                connection.automaticallyAdjustsVideoMirroring = false
                connection.isVideoMirrored = front
            }
        }

        @objc private func tapped(_ recognizer: UITapGestureRecognizer) {
            guard bounds.width > 0, bounds.height > 0 else { return }
            let point = recognizer.location(in: self)
            let normalized = NormalizedPoint(x: Double(min(1, max(0, point.x / bounds.width))),
                                             y: Double(min(1, max(0, point.y / bounds.height))))
            onTap?(normalized, previewLayer.captureDevicePointConverted(fromLayerPoint: point))
        }
    }
}
