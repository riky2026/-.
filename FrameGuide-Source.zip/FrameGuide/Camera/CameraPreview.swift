import AVFoundation
import SwiftUI
import UIKit

struct ShutterViewport {
    let metadataRect: CGRect
    let aspect: CGFloat
    let deviceID: String
}

/// Only main reads UIView/CALayer geometry. Snapshot the actual displayed layer at the tap.
@MainActor final class ViewfinderReader {
    weak var layer: AVCaptureVideoPreviewLayer?
    func snapshot() -> ShutterViewport? {
        guard let layer, layer.bounds.width > 0, layer.bounds.height > 0,
              let connection = layer.connection, connection.isActive,
              let input = connection.inputPorts.first?.input as? AVCaptureDeviceInput,
              connection.videoOrientation == .portrait,
              connection.isVideoMirrored == (input.device.position == .front) else { return nil }
        return ShutterViewport(metadataRect: layer.metadataOutputRectConverted(fromLayerRect: layer.bounds),
                               aspect: layer.bounds.width / layer.bounds.height, deviceID: input.device.uniqueID)
    }
}

/// Tap callback runs on main; normalized coordinates describe the displayed view.
struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession
    let reader: ViewfinderReader
    let isFrontCamera: Bool
    let onTap: (NormalizedPoint, CGPoint) -> Void

    func makeUIView(context: Context) -> PreviewView {
        let view = PreviewView()
        view.previewLayer.session = session
        view.previewLayer.videoGravity = .resizeAspectFill
        reader.layer = view.previewLayer
        view.onTap = onTap
        view.front = isFrontCamera
        return view
    }

    func updateUIView(_ view: PreviewView, context: Context) {
        view.front = isFrontCamera
        view.onTap = onTap
        view.updateConnection()
    }

    final class PreviewView: UIView {
        override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
        var previewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
        var front = false
        var onTap: ((NormalizedPoint, CGPoint) -> Void)?

        override init(frame: CGRect) {
            super.init(frame: frame)
            addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tapped(_:))))
        }
        required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
        override func layoutSubviews() { super.layoutSubviews(); updateConnection() }

        func updateConnection() {
            guard let connection = previewLayer.connection else { return }
            // Deliberately request a fixed interface orientation independent of gravity.
            if connection.isVideoOrientationSupported { connection.videoOrientation = .portrait }
            if connection.isVideoMirroringSupported {
                connection.automaticallyAdjustsVideoMirroring = false
                connection.isVideoMirrored = front
            }
        }

        @objc private func tapped(_ recognizer: UITapGestureRecognizer) {
            guard bounds.width > 0, bounds.height > 0 else { return }
            let point = recognizer.location(in: self)
            let normalized = NormalizedPoint(x: Double(min(1, max(0, point.x / bounds.width))),
                                             y: Double(min(1, max(0, point.y / bounds.height))))
            onTap?(normalized, previewLayer.captureDevicePointConverted(fromLayerPoint: point))
        }
    }
}
